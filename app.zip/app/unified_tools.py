"""Unified Tools：六类工具源的内建工具实现（MCP 之外全部在此）。

类别对齐架构图 Unified Tools 分支：
- skill     Agent Skills（skill_list / skill_load）
- workspace Workspace Tools（read / write / list，路径遍历防护）
- doc       Document Parsing（doc_parse：PDF/Word/Excel/PPT/扫描件/图片 → 文本/表格/结构）
- job       Scheduled Tasks（create / list / cancel）
- page      Page Tools（create / list / get）
- memory    Memory Manager 工具面（save / search）
- meta      Meta Tools（tools_list / status）
MCP Servers 类别由 tool_registry 从 mcp_manager 动态注入。
"""
from __future__ import annotations

import json
import logging
import os
from pathlib import Path
from typing import Any

from .config import WORKSPACE_DIR, load_config
from . import doc_parser
from .job_scheduler import job_scheduler
from .memory_manager import memory_manager
from .page_manager import page_manager
from .skill_manager import get_skill, list_skills

logger = logging.getLogger(__name__)

_READ_CAP = 20000
_LIST_CAP = 200


# --- workspace 安全护栏 ---

def _ws_resolve(rel: str) -> Path:
    root = WORKSPACE_DIR.resolve()
    target = (root / str(rel or "").lstrip("/")).resolve()
    if not target.is_relative_to(root):
        raise ValueError("路径越界：仅允许 data/workspace 内相对路径")
    return target


async def ws_read(args: dict[str, Any]) -> str:
    target = _ws_resolve(args.get("path", ""))
    if not target.exists() or not target.is_file():
        return f"Error: 文件不存在 workspace/{args.get('path', '')}"
    if target.stat().st_size > 512 * 1024:
        return "Error: 文件超过 512KB，禁止整读"
    text = target.read_text(encoding="utf-8", errors="replace")
    if len(text) > _READ_CAP:
        text = text[:_READ_CAP] + f"\n…（截断，原文 {len(text)} 字符）"
    return text


async def ws_write(args: dict[str, Any]) -> str:
    target = _ws_resolve(args.get("path", ""))
    content = str(args.get("content", ""))
    append = bool(args.get("append", False))
    target.parent.mkdir(parents=True, exist_ok=True)
    mode = "a" if append else "w"
    with target.open(mode, encoding="utf-8") as f:
        f.write(content)
    rel = target.relative_to(WORKSPACE_DIR.resolve()).as_posix()
    _archive_to_library(rel, target)
    return f"已{'追加' if append else '写入'} {len(content)} 字符 → workspace/{rel}"


def _archive_to_library(rel: str, target: Path) -> None:
    """输出结果文件自动归档：workspace 写入成功后镜像一份到资料库（pages）。

    按 source=workspace:<rel> 去重（同路径文件更新而非新建）；失败不影响写入本身。
    """
    try:
        if not load_config().get("pages", {}).get("enabled", True):
            return
        text = target.read_text(encoding="utf-8", errors="replace")
        page_manager.upsert_source(f"workspace:{rel}", target.stem or rel, text)
    except Exception:
        logger.warning("输出文件归档资料库失败: workspace/%s", rel, exc_info=True)


async def ws_list(args: dict[str, Any]) -> str:
    target = _ws_resolve(args.get("path", ""))
    if not target.exists():
        return "（空目录）"
    if not target.is_dir():
        return target.name
    lines = []
    for i, p in enumerate(sorted(target.iterdir())):
        if i >= _LIST_CAP:
            lines.append(f"…（仅显示前 {_LIST_CAP} 项）")
            break
        lines.append(f"{'[dir] ' if p.is_dir() else '[file]'} {p.name}")
    return "\n".join(lines) or "（空目录）"


async def ws_delete(args: dict[str, Any]) -> str:
    """删除 workspace 内的文件或目录（高危操作，需确认）。"""
    rel = str(args.get("path") or "").strip()
    if not rel:
        return "Error: 缺少 path 参数（workspace 内相对路径）"
    if rel.startswith("/") or rel.startswith("..") or ":" in rel:
        return "Error: 仅允许 workspace 内相对路径"
    target = _ws_resolve(rel)
    if not target.exists():
        return f"Error: 路径不存在 workspace/{rel}"
    # 安全检查：禁止删除 workspace 根目录
    if target == WORKSPACE_DIR.resolve():
        return "Error: 禁止删除 workspace 根目录"
    try:
        if target.is_dir():
            import shutil
            shutil.rmtree(str(target))
            return f"已删除目录 workspace/{rel}"
        else:
            target.unlink()
            return f"已删除文件 workspace/{rel}"
    except Exception as e:
        return f"Error: 删除失败：{e}"


async def bash_execute(args: dict[str, Any]) -> str:
    """执行 bash 命令（高危操作，需确认）。支持脚本、构建、测试等命令。"""
    command = str(args.get("command") or "").strip()
    if not command:
        return "Error: 缺少 command 参数"
    # 安全检查：禁止某些危险命令
    blocked_patterns = ["rm -rf /", "mkfs", "dd if=", "> /dev/sd", "> /dev/nvme"]
    for pattern in blocked_patterns:
        if pattern in command.lower():
            return f"Error: 命令包含危险操作（{pattern}），已拦截"
    timeout = float(args.get("timeout") or 30)
    if timeout > 300:
        timeout = 300  # 最大 5 分钟
    cwd = str(args.get("cwd") or WORKSPACE_DIR)
    try:
        import subprocess
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=cwd,
            env={**os.environ, "PYTHONIOENCODING": "utf-8"},
        )
        output = ""
        if result.stdout:
            output += result.stdout
        if result.stderr:
            output += f"\n[STDERR]\n{result.stderr}"
        if result.returncode != 0:
            output = f"[退出码 {result.returncode}]\n{output}"
        # 截断过长输出
        max_output = 10000
        if len(output) > max_output:
            output = output[:max_output] + f"\n…（输出截断，原文 {len(output)} 字符）"
        return output or "（无输出）"
    except subprocess.TimeoutExpired:
        return f"Error: 命令执行超时（{timeout:.0f}s），已中止"
    except Exception as e:
        return f"Error: 执行失败：{e}"


# --- document parsing ---

_DOC_PARSE_CAP = 8000


async def doc_parse(args: dict[str, Any]) -> str:
    """解析 workspace 内文档/图片：文本、表格、布局结构（扫描件走 OCR）。"""
    rel = str(args.get("path") or "").strip()
    if not rel:
        return "Error: 缺少 path 参数（workspace 内相对路径，如 docs/report.pdf）"
    if rel.startswith("/") or rel.startswith("..") or ":" in rel:
        return "Error: 仅允许 workspace 内相对路径（禁止绝对路径与 .. 越界）"
    target = _ws_resolve(rel)
    if not target.is_file():
        return f"Error: 文件不存在 workspace/{rel}"
    if target.stat().st_size > 15 * 1024 * 1024:
        return "Error: 文件超过 15MB 解析上限"
    mode = str(args.get("mode") or "auto")
    try:
        res = doc_parser.parse_bytes(target.read_bytes(), target.suffix.lower())
    except ValueError as e:
        return f"Error: {e}"
    except Exception as e:  # noqa: BLE001 — 工具结果恒为文本，不抛
        return f"Error: 解析失败：{e}"
    head = (f"[doc_parse workspace/{rel} engine={res['engine']} chars={len(res['text'])}"
            f" tables={res['tables']} ocr_pages={res['ocr_pages']}]\n")
    warn = ("警告：" + "；".join(res["warnings"]) + "\n") if res["warnings"] else ""
    if mode == "structure":
        slim = {
            "format": res["structured"]["format"], "engine": res["engine"],
            "chars": res["structured"]["chars"], "tables": res["tables"],
            "ocr_pages": res["ocr_pages"],
            "pages": [
                {
                    "index": p["index"],
                    "chars": len(p.get("text") or ""),
                    "tables": [{"rows": len(t), "cols": len(t[0]) if t else 0}
                               for t in (p.get("tables") or [])],
                    "blocks": [
                        {"type": b["type"], "text": (b.get("text") or "")[:60],
                         **({"level": b["level"]} if b.get("level") else {})}
                        for b in (p.get("blocks") or [])[:30]
                    ],
                }
                for p in res["structured"]["pages"]
            ],
        }
        return warn + json.dumps(slim, ensure_ascii=False)[:_DOC_PARSE_CAP * 2]
    if mode == "tables":
        parts = []
        for p in res["structured"]["pages"]:
            for ti, t in enumerate(p.get("tables") or [], 1):
                parts.append(
                    f"### 第{p['index']}页 · 表{ti}（{len(t)} 行）\n" + doc_parser.md_table(t))
        if not parts:
            return warn + "未提取到表格。"
        out = "\n\n".join(parts)
        if len(out) > _DOC_PARSE_CAP:
            out = out[:_DOC_PARSE_CAP] + f"\n…（截断，共 {len(out)} 字符）"
        return warn + head + out
    out = res["text"] or "未提取到文本（可能为扫描件且 OCR 未识别到文字）。"
    if len(out) > _DOC_PARSE_CAP:
        out = (out[:_DOC_PARSE_CAP]
               + f"\n…（截断，原文 {len(out)} 字符；可用 mode=structure 看结构）")
    return warn + head + out


# --- document generation ---

async def doc_generate_excel(args: dict[str, Any]) -> str:
    """生成 Excel 文件：支持多 sheet、表格数据、样式。"""
    rel = str(args.get("path") or "").strip()
    if not rel:
        return "Error: 缺少 path 参数（workspace 内相对路径，如 output/report.xlsx）"
    if rel.startswith("/") or rel.startswith("..") or ":" in rel:
        return "Error: 仅允许 workspace 内相对路径"
    if not rel.lower().endswith(".xlsx"):
        return "Error: 文件扩展名必须是 .xlsx"
    target = _ws_resolve(rel)
    sheets = args.get("sheets")
    if not sheets or not isinstance(sheets, list):
        return "Error: 缺少 sheets 参数（数组，每项含 name 和 rows）"
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Font, Alignment, PatternFill

        wb = Workbook()
        wb.remove(wb.active)  # 移除默认空 sheet
        for si, sheet_data in enumerate(sheets):
            name = str(sheet_data.get("name") or f"Sheet{si+1}")
            rows = sheet_data.get("rows") or []
            if not rows:
                continue
            ws = wb.create_sheet(title=name)
            # 表头样式
            header_font = Font(bold=True, color="FFFFFF")
            header_fill = PatternFill(start_color="4472C4", end_color="4472C4", fill_type="solid")
            header_align = Alignment(horizontal="center", vertical="center")
            for ri, row in enumerate(rows, 1):
                for ci, cell_val in enumerate(row, 1):
                    cell = ws.cell(row=ri, column=ci, value=cell_val)
                    if ri == 1:
                        cell.font = header_font
                        cell.fill = header_fill
                        cell.alignment = header_align
            # 自动列宽
            for col in ws.columns:
                max_len = max(len(str(c.value or "")) for c in col)
                ws.column_dimensions[col[0].column_letter].width = min(max_len + 2, 50)
        target.parent.mkdir(parents=True, exist_ok=True)
        wb.save(str(target))
        return f"已生成 Excel 文件 → workspace/{rel}（{len(sheets)} 个 sheet）"
    except Exception as e:
        return f"Error: 生成 Excel 失败：{e}"


async def doc_generate_word(args: dict[str, Any]) -> str:
    """生成 Word 文档：支持标题、段落、列表、表格。"""
    rel = str(args.get("path") or "").strip()
    if not rel:
        return "Error: 缺少 path 参数（workspace 内相对路径，如 output/report.docx）"
    if rel.startswith("/") or rel.startswith("..") or ":" in rel:
        return "Error: 仅允许 workspace 内相对路径"
    if not rel.lower().endswith(".docx"):
        return "Error: 文件扩展名必须是 .docx"
    target = _ws_resolve(rel)
    content = args.get("content")
    if not content or not isinstance(content, list):
        return "Error: 缺少 content 参数（数组，每项含 type 和 text/data）"
    try:
        from docx import Document
        from docx.shared import Pt, Inches
        from docx.enum.text import WD_ALIGN_PARAGRAPH

        doc = Document()
        for item in content:
            item_type = str(item.get("type") or "paragraph")
            text = item.get("text") or ""
            if item_type == "heading":
                level = int(item.get("level") or 1)
                doc.add_heading(text, level=level)
            elif item_type == "paragraph":
                p = doc.add_paragraph(text)
                if item.get("align") == "center":
                    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
                elif item.get("align") == "right":
                    p.alignment = WD_ALIGN_PARAGRAPH.RIGHT
            elif item_type == "list":
                items = item.get("items") or []
                for li in items:
                    doc.add_paragraph(str(li), style="List Bullet")
            elif item_type == "table":
                rows = item.get("rows") or []
                if rows:
                    table = doc.add_table(rows=len(rows), cols=len(rows[0]))
                    table.style = "Table Grid"
                    for ri, row in enumerate(rows):
                        for ci, val in enumerate(row):
                            table.cell(ri, ci).text = str(val)
        target.parent.mkdir(parents=True, exist_ok=True)
        doc.save(str(target))
        return f"已生成 Word 文档 → workspace/{rel}（{len(content)} 个元素）"
    except Exception as e:
        return f"Error: 生成 Word 失败：{e}"


async def doc_generate_ppt(args: dict[str, Any]) -> str:
    """生成 PPT 演示文稿：支持多幻灯片、标题、内容、布局。"""
    rel = str(args.get("path") or "").strip()
    if not rel:
        return "Error: 缺少 path 参数（workspace 内相对路径，如 output/presentation.pptx）"
    if rel.startswith("/") or rel.startswith("..") or ":" in rel:
        return "Error: 仅允许 workspace 内相对路径"
    if not rel.lower().endswith(".pptx"):
        return "Error: 文件扩展名必须是 .pptx"
    target = _ws_resolve(rel)
    slides = args.get("slides")
    if not slides or not isinstance(slides, list):
        return "Error: 缺少 slides 参数（数组，每项含 title 和 content）"
    try:
        from pptx import Presentation
        from pptx.util import Inches, Pt

        prs = Presentation()
        prs.slide_width = Inches(10)
        prs.slide_height = Inches(7.5)
        for slide_data in slides:
            title = str(slide_data.get("title") or "")
            content = slide_data.get("content") or ""
            layout = slide_data.get("layout") or "title_content"
            if layout == "title_only":
                slide_layout = prs.slide_layouts[5]
            else:
                slide_layout = prs.slide_layouts[1]
            slide = prs.slides.add_slide(slide_layout)
            if slide.shapes.title:
                slide.shapes.title.text = title
            if content and len(slide.placeholders) > 1:
                slide.placeholders[1].text = str(content)
        target.parent.mkdir(parents=True, exist_ok=True)
        prs.save(str(target))
        return f"已生成 PPT 演示文稿 → workspace/{rel}（{len(slides)} 张幻灯片）"
    except Exception as e:
        return f"Error: 生成 PPT 失败：{e}"


async def doc_generate_pdf(args: dict[str, Any]) -> str:
    """生成 PDF 文档：支持文本、标题、列表、表格（使用 fpdf2）。"""
    rel = str(args.get("path") or "").strip()
    if not rel:
        return "Error: 缺少 path 参数（workspace 内相对路径，如 output/report.pdf）"
    if rel.startswith("/") or rel.startswith("..") or ":" in rel:
        return "Error: 仅允许 workspace 内相对路径"
    if not rel.lower().endswith(".pdf"):
        return "Error: 文件扩展名必须是 .pdf"
    target = _ws_resolve(rel)
    content = args.get("content")
    if not content or not isinstance(content, list):
        return "Error: 缺少 content 参数（数组，每项含 type 和 text/data）"
    try:
        from fpdf import FPDF

        class PDF(FPDF):
            def header(self):
                self.set_font("Helvetica", "B", 12)
                self.cell(0, 10, "", new_x="LMARGIN", new_y="NEXT")

            def footer(self):
                self.set_y(-15)
                self.set_font("Helvetica", "I", 8)
                self.cell(0, 10, f"Page {self.page_no()}/{{nb}}", align="C")

        pdf = PDF()
        pdf.alias_nb_pages()
        pdf.add_page()
        pdf.set_auto_page_break(auto=True, margin=15)
        for item in content:
            item_type = str(item.get("type") or "paragraph")
            text = item.get("text") or ""
            if item_type == "heading":
                level = int(item.get("level") or 1)
                size = [16, 14, 12, 11, 10, 9][min(level - 1, 5)]
                pdf.set_font("Helvetica", "B", size)
                pdf.multi_cell(0, 10, text)
                pdf.ln(2)
            elif item_type == "paragraph":
                pdf.set_font("Helvetica", "", 10)
                pdf.multi_cell(0, 6, text)
                pdf.ln(2)
            elif item_type == "list":
                items = item.get("items") or []
                pdf.set_font("Helvetica", "", 10)
                for li in items:
                    pdf.cell(5)
                    pdf.multi_cell(0, 6, f"• {li}")
                pdf.ln(2)
            elif item_type == "table":
                rows = item.get("rows") or []
                if rows:
                    pdf.set_font("Helvetica", "B", 9)
                    col_width = 190 / len(rows[0])
                    for ri, row in enumerate(rows):
                        for ci, val in enumerate(row):
                            pdf.cell(col_width, 7, str(val), border=1, align="C")
                        pdf.ln()
                    pdf.ln(3)
        target.parent.mkdir(parents=True, exist_ok=True)
        pdf.output(str(target))
        return f"已生成 PDF 文档 → workspace/{rel}（{len(content)} 个元素）"
    except ImportError:
        return "Error: PDF 生成组件未安装（fpdf2），请运行 pip install fpdf2"
    except Exception as e:
        return f"Error: 生成 PDF 失败：{e}"


# --- document import ---

async def doc_import(args: dict[str, Any]) -> str:
    """从外部路径导入文档到 workspace 并解析成 Markdown。"""
    source_path = str(args.get("source") or "").strip()
    if not source_path:
        return "Error: 缺少 source 参数（外部文件绝对路径）"
    source = Path(source_path)
    if not source.exists() or not source.is_file():
        return f"Error: 源文件不存在：{source_path}"
    if source.stat().st_size > 50 * 1024 * 1024:
        return "Error: 文件超过 50MB 导入上限"
    # 目标路径：默认放到 workspace/imports/ 下，保持原文件名
    rel = str(args.get("path") or "").strip()
    if not rel:
        rel = f"imports/{source.name}"
    if rel.startswith("/") or rel.startswith("..") or ":" in rel:
        return "Error: 仅允许 workspace 内相对路径"
    target = _ws_resolve(rel)
    # 复制文件到 workspace
    try:
        import shutil
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(str(source), str(target))
    except Exception as e:
        return f"Error: 文件复制失败：{e}"
    # 自动解析
    parse_mode = str(args.get("mode") or "auto")
    try:
        res = doc_parser.parse_bytes(target.read_bytes(), target.suffix.lower())
    except ValueError as e:
        return f"Error: 解析失败：{e}"
    except Exception as e:
        return f"Error: 解析异常：{e}"
    head = f"[已导入并解析 {source.name} → workspace/{rel} engine={res['engine']} chars={len(res['text'])}]\n"
    if parse_mode == "tables":
        parts = []
        for p in res["structured"]["pages"]:
            for ti, t in enumerate(p.get("tables") or [], 1):
                parts.append(f"### 第{p['index']}页 · 表{ti}（{len(t)} 行）\n{doc_parser.md_table(t)}")
        out = "\n\n".join(parts) if parts else "未提取到表格。"
    elif parse_mode == "structure":
        slim = {
            "format": res["structured"]["format"], "engine": res["engine"],
            "chars": res["structured"]["chars"], "tables": res["tables"],
            "pages": [
                {"index": p["index"], "chars": len(p.get("text") or ""),
                 "tables": [{"rows": len(t), "cols": len(t[0]) if t else 0} for t in (p.get("tables") or [])]}
                for p in res["structured"]["pages"]
            ],
        }
        out = json.dumps(slim, ensure_ascii=False)
    else:
        out = res["text"] or "未提取到文本。"
    if len(out) > _DOC_PARSE_CAP:
        out = out[:_DOC_PARSE_CAP] + f"\n…（截断，原文 {len(out)} 字符）"
    return head + out


async def file_export(args: dict[str, Any]) -> str:
    """将 workspace 内的文件导出到指定外部路径。"""
    rel = str(args.get("path") or "").strip()
    if not rel:
        return "Error: 缺少 path 参数（workspace 内相对路径）"
    if rel.startswith("/") or rel.startswith("..") or ":" in rel:
        return "Error: 仅允许 workspace 内相对路径"
    source = _ws_resolve(rel)
    if not source.exists() or not source.is_file():
        return f"Error: 文件不存在 workspace/{rel}"
    dest_path = str(args.get("dest") or "").strip()
    if not dest_path:
        return "Error: 缺少 dest 参数（外部目标绝对路径）"
    dest = Path(dest_path)
    # 安全检查：防止覆盖系统关键文件
    blocked_prefixes = ["/etc/", "/usr/", "/bin/", "/sbin/", "C:\\Windows\\", "C:\\Program Files\\"]
    dest_str = str(dest).lower()
    for prefix in blocked_prefixes:
        if dest_str.startswith(prefix.lower()):
            return f"Error: 禁止导出到系统目录（{prefix}）"
    try:
        import shutil
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(str(source), str(dest))
        return f"已导出 workspace/{rel} → {dest_path}"
    except Exception as e:
        return f"Error: 导出失败：{e}"


async def web_search(args: dict[str, Any]) -> str:
    """联网搜索网页内容：使用搜索引擎 API 或抓取网页。"""
    query = str(args.get("query") or "").strip()
    if not query:
        return "Error: 缺少 query 参数（搜索关键词）"
    max_results = int(args.get("max_results") or 5)
    if max_results > 20:
        max_results = 20
    try:
        import httpx
        # 使用 DuckDuckGo HTML 版本（无需 API key）
        url = f"https://html.duckduckgo.com/html/?q={httpx.get('https://duckduckgo.com').request.url.split('?')[0] if False else ''}{query}"
        # 简化：直接搜索并返回摘要
        async with httpx.AsyncClient(timeout=30, follow_redirects=True) as client:
            response = await client.get(
                "https://html.duckduckgo.com/html/",
                params={"q": query},
                headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"},
            )
            if response.status_code != 200:
                return f"Error: 搜索请求失败（HTTP {response.status_code}）"
            # 解析结果
            from html.parser import HTMLParser

            class DDGParser(HTMLParser):
                def __init__(self):
                    super().__init__()
                    self.results = []
                    self.current = {}
                    self.in_result = False
                    self.in_title = False
                    self.in_snippet = False
                    self.capture = ""

                def handle_starttag(self, tag, attrs):
                    attrs_dict = dict(attrs)
                    if tag == "div" and "result" in attrs_dict.get("class", ""):
                        self.in_result = True
                        self.current = {}
                    elif tag == "a" and self.in_result and "result__a" in attrs_dict.get("class", ""):
                        self.in_title = True
                        self.capture = ""
                        self.current["url"] = attrs_dict.get("href", "")
                    elif tag == "a" and self.in_result and "result__snippet" in attrs_dict.get("class", ""):
                        self.in_snippet = True
                        self.capture = ""

                def handle_endtag(self, tag):
                    if tag == "a" and self.in_title:
                        self.in_title = False
                        self.current["title"] = self.capture.strip()
                    elif tag == "a" and self.in_snippet:
                        self.in_snippet = False
                        self.current["snippet"] = self.capture.strip()
                        if self.current.get("title") and self.current.get("url"):
                            self.results.append(self.current)
                        self.current = {}
                    elif tag == "div" and self.in_result:
                        self.in_result = False

                def handle_data(self, data):
                    if self.in_title or self.in_snippet:
                        self.capture += data

            parser = DDGParser()
            parser.feed(response.text)
            results = parser.results[:max_results]
            if not results:
                return "（未找到相关结果）"
            out = []
            for i, r in enumerate(results, 1):
                out.append(f"{i}. {r.get('title', '无标题')}\n   链接：{r.get('url', '')}\n   摘要：{r.get('snippet', '')[:200]}")
            return "\n\n".join(out)
    except ImportError:
        return "Error: 网络搜索依赖未安装（httpx）"
    except Exception as e:
        return f"Error: 搜索失败：{e}"


# --- skill development ---

async def skill_create(args: dict[str, Any]) -> str:
    """创建新技能卡。"""
    name = str(args.get("name") or "").strip()
    description = str(args.get("description") or "").strip()
    body = str(args.get("body") or "")
    triggers = args.get("triggers")
    if isinstance(triggers, list):
        triggers = ",".join(triggers)
    else:
        triggers = str(triggers or "")
    try:
        from .skill_manager import create_skill
        result = create_skill(name, description, body)
        # 如果有触发词，需要手动写入 frontmatter
        if triggers:
            from .config import SKILLS_DIR
            path = SKILLS_DIR / f"{name}.md"
            if path.exists():
                text = path.read_text(encoding="utf-8")
                if text.startswith("---"):
                    parts = text.split("---", 2)
                    if len(parts) >= 3:
                        lines = [ln for ln in parts[1].splitlines() if ln.strip() and not ln.strip().startswith("triggers:")]
                        front = "\n".join(lines + [f"triggers: {triggers}"]).strip("\n")
                        path.write_text(f"---\n{front}\n---\n{parts[2]}", encoding="utf-8")
        return f"技能已创建：{result['name']}\n{result['description']}"
    except ValueError as e:
        return f"Error: {e}"
    except Exception as e:
        return f"Error: 创建失败：{e}"


async def skill_update(args: dict[str, Any]) -> str:
    """更新现有技能卡。"""
    name = str(args.get("name") or "").strip()
    if not name:
        return "Error: 缺少 name 参数"
    description = args.get("description")
    body = args.get("body")
    triggers = args.get("triggers")
    enabled = args.get("enabled")
    try:
        from .skill_manager import get_skill
        from .config import SKILLS_DIR
        skill = get_skill(name, include_disabled=True)
        if not skill:
            return f"Error: 技能 '{name}' 不存在"
        path = SKILLS_DIR / f"{name}.md"
        text = path.read_text(encoding="utf-8")
        # 更新 frontmatter
        if text.startswith("---"):
            parts = text.split("---", 2)
            if len(parts) >= 3:
                lines = []
                for ln in parts[1].splitlines():
                    ln_stripped = ln.strip()
                    if not ln_stripped:
                        continue
                    key = ln_stripped.split(":", 1)[0].strip() if ":" in ln_stripped else ""
                    if key == "description" and description is not None:
                        lines.append(f"description: {description}")
                    elif key == "triggers" and triggers is not None:
                        if isinstance(triggers, list):
                            triggers = ",".join(triggers)
                        lines.append(f"triggers: {triggers}")
                    elif key == "enabled" and enabled is not None:
                        lines.append(f"enabled: {'true' if enabled else 'false'}")
                    else:
                        lines.append(ln_stripped)
                # 添加缺失字段
                if description is not None and not any(l.startswith("description:") for l in lines):
                    lines.append(f"description: {description}")
                if triggers is not None and not any(l.startswith("triggers:") for l in lines):
                    if isinstance(triggers, list):
                        triggers = ",".join(triggers)
                    lines.append(f"triggers: {triggers}")
                if enabled is not None and not any(l.startswith("enabled:") for l in lines):
                    lines.append(f"enabled: {'true' if enabled else 'false'}")
                front = "\n".join(lines).strip("\n")
                new_body = body if body is not None else parts[2]
                path.write_text(f"---\n{front}\n---\n{new_body}", encoding="utf-8")
        return f"技能已更新：{name}"
    except Exception as e:
        return f"Error: 更新失败：{e}"


async def skill_validate(args: dict[str, Any]) -> str:
    """验证技能卡格式与内容。"""
    name = str(args.get("name") or "").strip()
    if not name:
        return "Error: 缺少 name 参数"
    try:
        from .skill_manager import get_skill
        skill = get_skill(name, include_disabled=True)
        if not skill:
            return f"Error: 技能 '{name}' 不存在"
        issues = []
        # 检查必填字段
        if not skill.get("description"):
            issues.append("缺少 description 字段")
        if not skill.get("body") or len(skill["body"].strip()) < 10:
            issues.append("body 内容过短（至少 10 字符）")
        # 检查触发词
        triggers = skill.get("triggers") or []
        if len(triggers) > 12:
            issues.append(f"触发词过多（{len(triggers)} > 12）")
        for t in triggers:
            if len(t) > 32:
                issues.append(f"触发词过长：{t[:20]}...")
        # 检查 body 质量
        body = skill.get("body", "")
        if body and not any(kw in body.lower() for kw in ["当", "如果", "步骤", "输出", "返回"]):
            issues.append("body 可能缺少指令关键词（建议包含'当...时'、'步骤'、'输出'等）")
        if issues:
            return f"技能 '{name}' 存在以下问题：\n" + "\n".join(f"- {i}" for i in issues)
        return f"技能 '{name}' 验证通过（描述：{skill['description'][:50]}...）"
    except Exception as e:
        return f"Error: 验证失败：{e}"


# --- skills ---

async def sk_list(_: dict[str, Any]) -> str:
    items = list_skills(enabled_only=True)
    if not items:
        return "（无可用技能）"
    return "\n".join(f"- {it['name']}: {it['description']}" for it in items)


async def sk_load(args: dict[str, Any]) -> str:
    name = str(args.get("name", "")).strip()
    skill = get_skill(name)
    if not skill:
        return f"Error: 技能 '{name}' 不存在或已禁用（用 skill_list 查看可用技能）"
    return f"# 技能 {skill['name']}\n{skill['description']}\n\n{skill['body']}"


# --- jobs ---

async def job_create(args: dict[str, Any]) -> str:
    job, err = job_scheduler.create(
        title=str(args.get("title", "")),
        note=str(args.get("note", "")),
        delay_seconds=args.get("delay_seconds"),
        interval_seconds=args.get("interval_seconds"),
        prompt=str(args.get("prompt", "")),
    )
    if err:
        return f"Error: {err}"
    suffix = "（到期后由 AI 真实执行）" if job.get("prompt") else ""
    return json.dumps(job, ensure_ascii=False) + suffix


async def job_list(_: dict[str, Any]) -> str:
    jobs = job_scheduler.list()
    if not jobs:
        return "（无定时任务）"
    return json.dumps(jobs, ensure_ascii=False)


async def job_cancel(args: dict[str, Any]) -> str:
    ok = job_scheduler.cancel(str(args.get("id", "")))
    return "已取消" if ok else f"Error: 任务 '{args.get('id', '')}' 不存在或已结束"


# --- pages ---

async def page_create(args: dict[str, Any]) -> str:
    page = page_manager.create(str(args.get("title", "")), str(args.get("content", "")))
    return f"页面已创建 id={page['id']} title={page['title']}（GET /api/pages/{page['id']}）"


async def page_list(_: dict[str, Any]) -> str:
    pages = page_manager.list()
    if not pages:
        return "（无页面）"
    return json.dumps(pages, ensure_ascii=False)


async def page_get(args: dict[str, Any]) -> str:
    page = page_manager.get(str(args.get("id", "")))
    if not page:
        return f"Error: 页面 '{args.get('id', '')}' 不存在"
    return json.dumps(page, ensure_ascii=False)


# --- memory ---

async def mem_save(args: dict[str, Any]) -> str:
    tags = args.get("tags")
    if isinstance(tags, str):
        tags = [t for t in tags.split(",") if t.strip()]
    try:
        item = memory_manager.add(str(args.get("content", "")), tags=tags, source="tool")
    except ValueError as e:
        return f"Error: {e}"
    return f"记忆已保存 id={item['id']}: {item['content']}"


async def mem_search(args: dict[str, Any]) -> str:
    k = int(args.get("k", 5) or 5)
    mems = await memory_manager.retrieve_hybrid(str(args.get("query", "")), k=k)
    if not mems:
        return "（无相关记忆）"
    return json.dumps(mems, ensure_ascii=False)


# --- rag（知识库） ---

async def kb_search(args: dict[str, Any]) -> str:
    from .rag import rag_engine

    res = await rag_engine.search(str(args.get("query", "")), k=int(args.get("k", 0) or 0))
    if not res["chunks"]:
        return "（知识库无相关内容）"
    return json.dumps(
        {"confidence": res["confidence"], "chunks": res["chunks"]}, ensure_ascii=False
    )


async def kb_answer(args: dict[str, Any]) -> str:
    from .rag import rag_engine

    res = await rag_engine.answer(str(args.get("query", "")))
    if res["refused"]:
        return f"Error: {res['reason']}"
    sources = "；".join(f"[{s['index']}]{s['title']}" for s in res["sources"])
    return f"{res['answer']}\n\n（来源：{sources}；置信度 {res['confidence']:.2f}）"


# --- meta ---

async def meta_tools_list(_: dict[str, Any]) -> str:
    from .tool_registry import tool_registry

    return json.dumps(tool_registry.describe(), ensure_ascii=False)


async def meta_status(_: dict[str, Any]) -> str:
    from .mcp_manager import mcp_manager
    from .model_router import describe as role_describe

    cfg = load_config()
    return json.dumps(
        {
            "roles": role_describe(),
            "workflow_mode": cfg["workflow"].get("mode", "auto"),
            "mcp_servers": [
                {"name": s["name"], "status": s["status"]}
                for s in mcp_manager.get_all_server_statuses()
            ],
            "counts": {
                "skills": len(list_skills(enabled_only=True)),
                "memories": len(memory_manager.list()),
                "pages": len(page_manager.list()),
                "jobs": len(job_scheduler.list()),
            },
        },
        ensure_ascii=False,
    )


# --- 工具声明表 ---

def builtins() -> list[dict[str, Any]]:
    """内建工具声明。timeout：执行网关超时上限（s）；danger：高危确认门标记。

    超时分层约定（M6）：读列 10-15s、写档 15s、轻查询 5-10s；danger 仅删除/
    外发类工具（当前内建无，MCP destructiveHint 自动标注）。
    """
    return [
        {"name": "workspace_read", "category": "workspace", "handler": ws_read, "timeout": 15, "danger": False,
         "description": "读取 data/workspace 内的文本文件（≤512KB，超出截断）",
         "parameters": {"type": "object", "properties": {"path": {"type": "string", "description": "workspace 内相对路径，如 notes/a.txt"}}, "required": ["path"]}},
        {"name": "workspace_write", "category": "workspace", "handler": ws_write, "timeout": 15, "danger": False,
         "description": "写入/追加 data/workspace 内文件（自动建目录，路径遍历防护）",
         "parameters": {"type": "object", "properties": {"path": {"type": "string"}, "content": {"type": "string"}, "append": {"type": "boolean", "description": "true=追加，默认覆盖"}}, "required": ["path", "content"]}},
        {"name": "workspace_list", "category": "workspace", "handler": ws_list, "timeout": 10, "danger": False,
         "description": "列出 data/workspace 目录内容",
         "parameters": {"type": "object", "properties": {"path": {"type": "string", "description": "相对路径，默认根"}}}},
        {"name": "workspace_delete", "category": "workspace", "handler": ws_delete, "timeout": 10, "danger": True,
         "description": "删除 workspace 内的文件或目录（高危操作，需人工确认）",
         "parameters": {"type": "object", "properties": {"path": {"type": "string", "description": "workspace 内相对路径"}}, "required": ["path"]}},
        {"name": "bash_execute", "category": "workspace", "handler": bash_execute, "timeout": 60, "danger": True,
         "description": "执行 bash 命令（高危操作，需人工确认）：支持脚本、构建、测试等，最大超时 300s",
         "parameters": {"type": "object", "properties": {
             "command": {"type": "string", "description": "要执行的命令，如 python test.py 或 npm run build"},
             "cwd": {"type": "string", "description": "工作目录（可选，默认 workspace）"},
             "timeout": {"type": "number", "description": "超时秒数（可选，默认 30，最大 300）"}},
             "required": ["command"]}},
        {"name": "doc_parse", "category": "doc", "handler": doc_parse, "timeout": 120, "danger": False,
         "description": "解析 workspace 内文档/图片（PDF/Word/Excel/PPT/扫描件）：提取文本、表格、布局结构；扫描件与图片走 OCR",
         "parameters": {"type": "object", "properties": {
             "path": {"type": "string", "description": "workspace 内相对路径，如 docs/report.pdf"},
             "mode": {"type": "string", "enum": ["auto", "text", "tables", "structure"],
                      "description": "auto/text=全文，tables=仅表格，structure=页/块/表结构 JSON"}},
             "required": ["path"]}},
        {"name": "doc_generate_excel", "category": "doc", "handler": doc_generate_excel, "timeout": 30, "danger": False,
         "description": "生成 Excel 文件（.xlsx）：支持多 sheet、表格数据、表头样式",
         "parameters": {"type": "object", "properties": {
             "path": {"type": "string", "description": "workspace 内相对路径，如 output/report.xlsx"},
             "sheets": {"type": "array", "description": "sheet 数组，每项含 name 和 rows（二维数组）"}},
             "required": ["path", "sheets"]}},
        {"name": "doc_generate_word", "category": "doc", "handler": doc_generate_word, "timeout": 30, "danger": False,
         "description": "生成 Word 文档（.docx）：支持标题、段落、列表、表格",
         "parameters": {"type": "object", "properties": {
             "path": {"type": "string", "description": "workspace 内相对路径，如 output/report.docx"},
             "content": {"type": "array", "description": "内容数组，每项含 type(heading/paragraph/list/table) 和 text/data"}},
             "required": ["path", "content"]}},
        {"name": "doc_generate_ppt", "category": "doc", "handler": doc_generate_ppt, "timeout": 30, "danger": False,
         "description": "生成 PPT 演示文稿（.pptx）：支持多幻灯片、标题、内容",
         "parameters": {"type": "object", "properties": {
             "path": {"type": "string", "description": "workspace 内相对路径，如 output/presentation.pptx"},
             "slides": {"type": "array", "description": "幻灯片数组，每项含 title 和 content"}},
             "required": ["path", "slides"]}},
        {"name": "doc_generate_pdf", "category": "doc", "handler": doc_generate_pdf, "timeout": 30, "danger": False,
         "description": "生成 PDF 文档：支持文本、标题、列表、表格（需安装 fpdf2）",
         "parameters": {"type": "object", "properties": {
             "path": {"type": "string", "description": "workspace 内相对路径，如 output/report.pdf"},
             "content": {"type": "array", "description": "内容数组，每项含 type(heading/paragraph/list/table) 和 text/data"}},
             "required": ["path", "content"]}},
        {"name": "doc_import", "category": "doc", "handler": doc_import, "timeout": 120, "danger": False,
         "description": "从外部路径导入文档到 workspace 并解析成 Markdown（支持 PDF/Word/Excel/PPT/图片）",
         "parameters": {"type": "object", "properties": {
             "source": {"type": "string", "description": "外部文件绝对路径，如 C:/Users/xxx/Documents/report.pdf"},
             "path": {"type": "string", "description": "workspace 内目标相对路径（可选，默认 imports/原文件名）"},
             "mode": {"type": "string", "enum": ["auto", "text", "tables", "structure"],
                      "description": "解析模式：auto/text=全文，tables=仅表格，structure=结构 JSON"}},
             "required": ["source"]}},
        {"name": "file_export", "category": "workspace", "handler": file_export, "timeout": 30, "danger": False,
         "description": "将 workspace 内的文件导出到指定外部路径",
         "parameters": {"type": "object", "properties": {
             "path": {"type": "string", "description": "workspace 内相对路径"},
             "dest": {"type": "string", "description": "外部目标绝对路径，如 C:/Users/xxx/Desktop/export.pdf"}},
             "required": ["path", "dest"]}},
        {"name": "web_search", "category": "rag", "handler": web_search, "timeout": 30, "danger": False,
         "description": "联网搜索网页内容（使用 DuckDuckGo，无需 API key）",
         "parameters": {"type": "object", "properties": {
             "query": {"type": "string", "description": "搜索关键词"},
             "max_results": {"type": "integer", "description": "最大结果数（可选，默认 5，最大 20）"}},
             "required": ["query"]}},
        {"name": "skill_list", "category": "skill", "handler": sk_list, "timeout": 5, "danger": False,
         "description": "列出可用 Agent Skills（name + 描述）",
         "parameters": {"type": "object", "properties": {}}},
        {"name": "skill_load", "category": "skill", "handler": sk_load, "timeout": 5, "danger": False,
         "description": "加载指定技能的完整指令",
         "parameters": {"type": "object", "properties": {"name": {"type": "string"}}, "required": ["name"]}},
        {"name": "skill_create", "category": "skill", "handler": skill_create, "timeout": 10, "danger": False,
         "description": "创建新技能卡（name/description/body/triggers）",
         "parameters": {"type": "object", "properties": {
             "name": {"type": "string", "description": "技能名称（字母/数字/连字符/下划线）"},
             "description": {"type": "string", "description": "一句话描述"},
             "body": {"type": "string", "description": "技能指令正文"},
             "triggers": {"type": "string", "description": "触发词（逗号分隔）"}},
             "required": ["name", "description"]}},
        {"name": "skill_update", "category": "skill", "handler": skill_update, "timeout": 10, "danger": False,
         "description": "更新现有技能卡（可更新 description/body/triggers/enabled）",
         "parameters": {"type": "object", "properties": {
             "name": {"type": "string", "description": "技能名称"},
             "description": {"type": "string"},
             "body": {"type": "string"},
             "triggers": {"type": "string", "description": "触发词（逗号分隔）"},
             "enabled": {"type": "boolean"}},
             "required": ["name"]}},
        {"name": "skill_validate", "category": "skill", "handler": skill_validate, "timeout": 5, "danger": False,
         "description": "验证技能卡格式与内容质量",
         "parameters": {"type": "object", "properties": {"name": {"type": "string"}}, "required": ["name"]}},
        {"name": "job_create", "category": "job", "handler": job_create, "timeout": 5, "danger": False,
         "description": "创建定时任务：delay_seconds（一次性）或 interval_seconds（周期）二选一；prompt 可选，填了则到期后由 AI 真实执行该任务",
         "parameters": {"type": "object", "properties": {"title": {"type": "string"}, "note": {"type": "string"}, "prompt": {"type": "string", "description": "可选：到期后交给 AI 执行的任务指令"}, "delay_seconds": {"type": "number"}, "interval_seconds": {"type": "number"}}, "required": ["title"]}},
        {"name": "job_list", "category": "job", "handler": job_list, "timeout": 5, "danger": False,
         "description": "列出定时任务及状态（pending/active/done/cancelled）",
         "parameters": {"type": "object", "properties": {}}},
        {"name": "job_cancel", "category": "job", "handler": job_cancel, "timeout": 5, "danger": False,
         "description": "取消未完成的定时任务",
         "parameters": {"type": "object", "properties": {"id": {"type": "string"}}, "required": ["id"]}},
        {"name": "page_create", "category": "page", "handler": page_create, "timeout": 10, "danger": False,
         "description": "创建页面/笔记（markdown），返回 id",
         "parameters": {"type": "object", "properties": {"title": {"type": "string"}, "content": {"type": "string"}}, "required": ["title", "content"]}},
        {"name": "page_list", "category": "page", "handler": page_list, "timeout": 10, "danger": False,
         "description": "列出页面（含内容预览）",
         "parameters": {"type": "object", "properties": {}}},
        {"name": "page_get", "category": "page", "handler": page_get, "timeout": 10, "danger": False,
         "description": "按 id 读取页面全文",
         "parameters": {"type": "object", "properties": {"id": {"type": "string"}}, "required": ["id"]}},
        {"name": "memory_save", "category": "memory", "handler": mem_save, "timeout": 5, "danger": False,
         "description": "保存一条长期记忆",
         "parameters": {"type": "object", "properties": {"content": {"type": "string"}, "tags": {"type": "string", "description": "逗号分隔标签"}}, "required": ["content"]}},
        {"name": "memory_search", "category": "memory", "handler": mem_search, "timeout": 5, "danger": False,
         "description": "按关键词检索长期记忆",
         "parameters": {"type": "object", "properties": {"query": {"type": "string"}, "k": {"type": "integer"}}, "required": ["query"]}},
        {"name": "kb_search", "category": "rag", "handler": kb_search, "timeout": 30, "danger": False,
         "description": "知识库混合检索（BM25+向量）：返回资料库中最相关的知识片段",
         "parameters": {"type": "object", "properties": {"query": {"type": "string"}, "k": {"type": "integer", "description": "召回条数，默认取配置 top_k"}}, "required": ["query"]}},
        {"name": "kb_answer", "category": "rag", "handler": kb_answer, "timeout": 120, "danger": False,
         "description": "知识库问答：检索资料库并生成带引用标注的回答，内容不足时拒答",
         "parameters": {"type": "object", "properties": {"query": {"type": "string"}}, "required": ["query"]}},
        {"name": "meta_tools_list", "category": "meta", "handler": meta_tools_list, "timeout": 5, "danger": False,
         "description": "列出当前全部可用工具（按类别分组）",
         "parameters": {"type": "object", "properties": {}}},
        {"name": "meta_status", "category": "meta", "handler": meta_status, "timeout": 5, "danger": False,
         "description": "查看系统状态：角色模型映射/工作流模式/MCP/各类资源计数",
         "parameters": {"type": "object", "properties": {}}},
    ]