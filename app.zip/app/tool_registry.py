"""Tool Registry：统一工具注册表（MCP + 内建六类），OpenAI function 格式统一注入。

- rebuild()：每回合开始刷新（内建按配置开关门控 + MCP 动态目录）
- schemas()：注入 LLM tools 参数；digest()：规划器摘要（仅名称+描述，防 schema 灌爆）
- call(name, args, confirm_cb)：统一执行网关——参数校验 → danger 确认门 →
  超时控制 → 审计留痕；未知工具/执行异常一律返回 "Error: ..." 文本（不抛）
- info(name)：UI 事件用的 (server_label, tool_label)
"""
from __future__ import annotations

import asyncio
import logging
import time
from typing import Any, Awaitable, Callable

from . import audit
from .config import load_config
from .mcp_manager import mcp_manager
from . import unified_tools

logger = logging.getLogger(__name__)

# 类别 → config 开关节（None = 恒启用）
_CATEGORY_GATE = {
    "mcp": None,
    "meta": None,
    "skill": "skills",
    "workspace": "workspace",
    "doc": "doc",
    "job": "jobs",
    "page": "pages",
    "memory": "memory",
    "rag": "rag",
}

ConfirmCB = Callable[[str, dict[str, Any]], Awaitable[bool]]


def _check_required(parameters: dict[str, Any] | None, arguments: dict[str, Any]) -> list[str]:
    """调用前拦截坏参数：校验 required 必填字段存在且非空（M3 调用前校验）。"""
    required = ((parameters or {}).get("required")) or []
    missing = []
    for key in required:
        val = arguments.get(key)
        if val is None or (isinstance(val, str) and not val.strip()):
            missing.append(key)
    return missing


class ToolRegistry:
    def __init__(self) -> None:
        self._defs: dict[str, dict[str, Any]] = {}

    async def rebuild(self) -> None:
        cfg = load_config()
        defs: dict[str, dict[str, Any]] = {}

        for d in unified_tools.builtins():
            gate = _CATEGORY_GATE.get(d["category"])
            if gate and not cfg.get(gate, {}).get("enabled", True):
                continue
            defs[d["name"]] = d
            # 历史回放别名：prepare_thread 会把 tool_trace 展开成
            # "{server}__{tool}" 形式的 tool_calls，内置工具需可解析
            defs[f"{d['category']}__{d['name']}"] = {**d, "hidden": True}

        try:
            mcp_tools = await mcp_manager.get_all_tools()
        except Exception as e:  # noqa: BLE001 — MCP 目录失败不阻断内建工具
            logger.warning("MCP 工具目录获取失败: %s", e)
            mcp_tools = []
        for t in mcp_tools:
            fn = t.get("function") or {}
            name = fn.get("name") or ""
            if not name:
                continue
            server, _, tool = name.partition("__")
            # 高危标注：MCP annotations.destructiveHint → danger 确认门
            destructive = bool(((t.get("annotations") or {}).get("destructiveHint")))

            async def _mcp_call(args: dict[str, Any], _s: str = server, _t: str = tool) -> str:
                return await mcp_manager.call_tool(_s, _t, args)

            defs[name] = {
                "name": name,
                "category": "mcp",
                "description": fn.get("description") or "",
                "parameters": fn.get("parameters") or {"type": "object", "properties": {}},
                "handler": _mcp_call,
                "server": server,
                "tool": tool,
                "timeout": 60,
                "danger": destructive,
            }
        self._defs = defs
        logger.info("工具注册表刷新：%d 个工具", len(defs))

    def schemas(self) -> list[dict[str, Any]]:
        return [
            {
                "type": "function",
                "function": {
                    "name": d["name"],
                    "description": d.get("description") or "",
                    "parameters": d.get("parameters") or {"type": "object", "properties": {}},
                },
            }
            for d in self._defs.values()
            if not d.get("hidden")
        ]

    def digest(self, cap: int = 40) -> str:
        """规划器用的注册表摘要：仅名称+一句话描述（M2 只注入摘要）。"""
        lines = []
        for name, d in sorted(self._defs.items()):
            if d.get("hidden"):
                continue
            danger_mark = "（高危需确认）" if d.get("danger") else ""
            desc = (d.get("description") or "").split("（")[0][:60]
            lines.append(f"- {name}: {desc}{danger_mark}")
            if len(lines) >= cap:
                lines.append(f"…（其余 {max(0, sum(1 for x in self._defs.values() if not x.get('hidden')) - cap)} 个略）")
                break
        return "\n".join(lines)

    def has(self, name: str) -> bool:
        return name in self._defs and not self._defs[name].get("hidden")

    def is_danger(self, name: str) -> bool:
        """高危工具判定（danger 标志 → 编排器确认门挂起等人工放行）。"""
        d = self._defs.get(name)
        return bool(d and d.get("danger"))

    def info(self, name: str) -> tuple[str, str]:
        d = self._defs.get(name)
        if not d:
            return ("unknown", name)
        if d["category"] == "mcp":
            return (d.get("server", ""), d.get("tool", name))
        return (d["category"], name)

    def describe(self) -> dict[str, list[str]]:
        out: dict[str, list[str]] = {}
        for name, d in sorted(self._defs.items()):
            if d.get("hidden"):  # 历史回放别名不进清单，与 schemas()/digest() 一致
                continue
            out.setdefault(d["category"], []).append(name)
        return out

    async def call(
        self, name: str, arguments: dict[str, Any], confirm_cb: ConfirmCB | None = None
    ) -> str:
        """统一执行网关：校验 → 确认门 → 超时 → 审计。结果恒为文本。"""
        d = self._defs.get(name)
        if not d:
            return f"Error: 未知工具 '{name}'"

        # 1. 调用前参数校验（错误越早拦截成本越低）
        missing = _check_required(d.get("parameters"), arguments or {})
        if missing:
            return f"Error: 参数不合法：缺少必填参数 {', '.join(missing)}"

        # 2. 高危确认门：danger 工具必须人工放行（超时/拒绝由 confirm_cb 裁决）
        if d.get("danger") and confirm_cb is not None:
            try:
                approved = await confirm_cb(name, arguments or {})
            except Exception as e:  # noqa: BLE001 — 确认通道故障按拒绝处理
                logger.warning("工具 %s 确认通道异常，按拒绝处理: %s", name, e)
                approved = False
            if not approved:
                audit.append("tool_call", tool=name, server=d["category"],
                             params=audit.digest(arguments), result="用户拒绝执行（确认门未放行）",
                             is_error=False, duration_ms=0, denied=True)
                return f"Error: 用户拒绝执行工具 '{name}'（danger 高危操作需人工确认）"

        # 3. 带超时调用
        handler: Callable[[dict[str, Any]], Awaitable[str]] = d["handler"]
        timeout = float(d.get("timeout") or 30)
        start = time.perf_counter()
        try:
            result = await asyncio.wait_for(handler(arguments or {}), timeout=timeout)
        except asyncio.TimeoutError:
            result = f"Error: 工具 '{name}' 执行超时（{timeout:.0f}s），已中止"
        except ValueError as e:
            result = f"Error: {e}"
        except Exception as e:  # noqa: BLE001 — 工具异常转文本，循环继续
            logger.exception("工具 %s 执行异常", name)
            result = f"Error: 工具执行异常: {e}"

        # 4. 审计留痕（M10：可完整回放任务过程）
        audit.append(
            "tool_call", tool=name, server=d["category"],
            params=audit.digest(arguments), result=audit.digest(result),
            is_error=result.startswith("Error:"),
            duration_ms=round((time.perf_counter() - start) * 1000),
        )
        return result


tool_registry = ToolRegistry()
