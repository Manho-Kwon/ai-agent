"""Fixed Flows：固定工作流注册表（M5 第一层——规则命中的确定性请求零模型调用）。

- 每个 flow 是一个 async 函数：query → 结果文本（不调 LLM）
- 注册表 _FLOWS 键与 data/workflow_rules.json 中 rule.flow 对应
- 新增固定流程：实现函数 → 登记入 _FLOWS → 规则文件加一条 pattern 映射
"""
from __future__ import annotations

import json
import logging
from typing import Any, Awaitable, Callable

logger = logging.getLogger(__name__)

Flow = Callable[[str], Awaitable[str]]

_MAX_LIST = 30


async def _flow_tools(query: str) -> str:
    from .tool_registry import tool_registry

    await tool_registry.rebuild()  # 冷启动后注册表为空，先刷新再列（也带上配置开关与 MCP 变化）
    desc = tool_registry.describe()
    lines: list[str] = ["当前可用工具（按类别）："]
    for cat, tools in sorted(desc.items()):
        lines.append(f"- {cat}: {', '.join(tools)}")
    from .skill_manager import list_skills

    skills = list_skills(enabled_only=True)
    if skills:
        lines.append("可用技能：" + "、".join(s["name"] for s in skills))
    return "\n".join(lines)


async def _flow_jobs(query: str) -> str:
    from .job_scheduler import job_scheduler

    jobs = job_scheduler.list()[:_MAX_LIST]
    if not jobs:
        return "当前没有定时任务。"
    lines = [f"定时任务共 {len(jobs)} 个："]
    for j in jobs:
        lines.append(
            f"- [{j.get('status')}] {j.get('title')}（run_at={j.get('run_at')}，"
            f"已跑 {j.get('run_count', 0)} 次）"
        )
    return "\n".join(lines)


async def _flow_memories(query: str) -> str:
    from .memory_manager import memory_manager

    mems = memory_manager.list()[:_MAX_LIST]
    if not mems:
        return "长期记忆为空。"
    lines = [f"长期记忆共 {len(mems)} 条（最近优先）："]
    for m in mems:
        lines.append(f"- [{m.get('created_at', '')}] {m.get('content', '')}")
    return "\n".join(lines)


async def _flow_status(query: str) -> str:
    from .config import load_config
    from .mcp_manager import mcp_manager
    from .memory_manager import memory_manager
    from .job_scheduler import job_scheduler
    from .page_manager import page_manager
    from .skill_manager import list_skills

    cfg_lines = [f"工作流模式：{load_config().get('workflow', {}).get('mode', 'auto')}"]
    servers = mcp_manager.get_all_server_statuses()
    if servers:
        cfg_lines.append(
            "MCP 服务器：" + "、".join(f"{s['name']}({s['status']})" for s in servers)
        )
    cfg_lines.append(
        f"资源计数：技能 {len(list_skills(enabled_only=True))}｜记忆 {len(memory_manager.list())}"
        f"｜页面 {len(page_manager.list())}｜定时任务 {len(job_scheduler.list())}"
    )
    return "\n".join(cfg_lines)


_FLOWS: dict[str, Flow] = {
    "flow_tools": _flow_tools,
    "flow_jobs": _flow_jobs,
    "flow_memories": _flow_memories,
    "flow_status": _flow_status,
}


def flows() -> list[str]:
    return sorted(_FLOWS)


async def run_flow(flow: str, query: str) -> str | None:
    """执行固定流程；未注册的 flow 返回 None（调用方回退常规管道）。"""
    fn = _FLOWS.get(flow)
    if fn is None:
        return None
    try:
        return await fn(query)
    except Exception as e:  # noqa: BLE001 — 固定流程失败不崩管道
        logger.warning("固定流程 %s 执行失败: %s", flow, e)
        return None


def _dump_default_rules() -> dict[str, Any]:
    return {
        "rules": [
            {"name": "tools_list", "pattern": "你有哪些工具|有哪些工具|工具列表|列出.{0,6}工具", "flow": "flow_tools"},
            {"name": "jobs_list", "pattern": "^(?!.*(创建|新建|添加|新增|删除|取消|修改)).{0,6}(我的|当前|全部)?定时任务(列表|有哪些)?$", "flow": "flow_jobs"},
            {"name": "memories_list", "pattern": "记住了什么|记忆列表|有哪些记忆", "flow": "flow_memories"},
            {"name": "sys_status", "pattern": "^系统状态$|^系统状态(如何|怎么样)$", "flow": "flow_status"},
        ],
        "_说明": "固定工作流规则（M5 第一层）：pattern 为正则，命中即走 flow 零模型调用；改完即生效（每次路由检查 mtime 热重载）。可用 flow：" + ", ".join(sorted(_FLOWS)),
    }
