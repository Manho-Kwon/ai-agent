"""Evaluator — 独立质量门禁（对齐方案 M4 两层评估）。

两层评估：
1. 规则层（零成本先行）：空回答、计划声明工具未被调用或全报错等硬指标程序判定；
2. 语义层（仅模型产出内容）：对照步骤 success 验收标准逐项判定，温度 0 保证可复现。

输出 verdict：{passed, score, failures: [{step, type: rule|semantic, detail}], feedback, fallback}。
fail-open 原则：评估者不可用/输出不可解析时默认 PASS，绝不阻断主链路。
但放行必须在 verdict.fallback 标明原因（disabled / llm_unavailable / exception / parse_failed），
让调用方与 UI 能区分「真通过」与「未实际评估」——静默放行会让质量门形同虚设，
也会让未经验收的回答获得沉淀进长期记忆的资格（见 orchestrator 的记忆门禁）。
"""
from __future__ import annotations

import json
import logging
from typing import Any

from . import audit
from .config import load_config
from .llm import LLMError, complete_chat
from .model_router import resolve_role

logger = logging.getLogger(__name__)


def _parse(raw: str) -> dict[str, Any] | None:
    raw = (raw or "").strip()
    start = raw.find("{")
    end = raw.rfind("}")
    if start < 0 or end <= start:
        return None
    try:
        data = json.loads(raw[start : end + 1])
    except json.JSONDecodeError:
        return None
    return data if isinstance(data, dict) else None


def _trace_names(t: dict[str, Any]) -> set[str]:
    """一条工具痕迹对应的全部名字写法：全名、短名、server 拼接名。

    计划侧写注册表全名，而 trace 的 tool 来自 tool_registry.info()，
    MCP 工具在此被剥掉 server 前缀、执行者还可能用短别名调用；
    只比对单一写法会把成功调用判成「未被成功调用」，白烧返工预算。
    """
    tool = (t.get("tool") or "").strip()
    if not tool:
        return set()
    names = {tool, tool.rsplit("__", 1)[-1]}
    server = (t.get("server") or "").strip()
    if server:
        names.add(f"{server}__{tool}")
    return names


def _rule_check(
    plan: dict[str, Any] | None, answer: str, tool_trace: list[dict[str, Any]] | None
) -> list[dict[str, str]]:
    """规则层：程序判定硬指标，返回 failures 明细（空列表 = 全过）。"""
    failures: list[dict[str, str]] = []
    if not (answer or "").strip():
        failures.append({"step": "final", "type": "rule", "detail": "最终回答为空"})
        return failures

    trace = tool_trace or []
    err_tools: set[str] = set()
    ok_tools: set[str] = set()
    for t in trace:
        (err_tools if t.get("is_error") else ok_tools).update(_trace_names(t))
    # 全部工具调用报错 → 直接判失败
    if trace and not ok_tools:
        names = sorted({(t.get("tool") or "?") for t in trace})
        failures.append({
            "step": "tools",
            "type": "rule",
            "detail": f"本轮全部 {len(trace)} 次工具调用均失败（{', '.join(names)[:120]}）",
        })
    # 计划声明了注册表内真实工具但从未成功调用 → 硬指标失败
    if plan and not plan.get("_fallback"):
        from .tool_registry import tool_registry

        for s in plan.get("steps") or []:
            tool = (s or {}).get("tool") if isinstance(s, dict) else ""
            if not tool or not tool_registry.has(tool):
                continue
            if tool in ok_tools:
                continue
            err_hint = ""
            if tool in err_tools:
                first_err = next(
                    (t.get("content", "") for t in trace
                     if t.get("is_error") and tool in _trace_names(t)),
                    "",
                )
                err_hint = f"（调用报错：{first_err[:120]}）"
            failures.append({
                "step": str((s or {}).get("id") or "?"),
                "type": "rule",
                "detail": f"计划步骤声明的工具 {tool} 未被成功调用{err_hint}",
            })
    return failures


def _verdict(
    passed: bool,
    failures: list[dict[str, str]],
    feedback: str,
    score: int | None = None,
    fallback: str | None = None,
) -> dict[str, Any]:
    return {
        "passed": bool(passed),
        "score": score,
        "failures": failures,
        "feedback": (feedback or "").strip(),
        "fallback": fallback,
    }


async def evaluate(
    query: str,
    plan: dict[str, Any] | None,
    answer: str,
    tool_trace: list[dict[str, Any]] | None = None,
    session_id: str = "",
) -> dict[str, Any]:
    """两层评估，返回 verdict dict（调用方读取 passed/feedback/failures/score/fallback）。

    fallback 非空 = 本次「通过」并非真实评估结论，而是 fail-open 放行。
    """
    cfg = load_config()["evaluator"]
    if not cfg.get("enabled", True):
        audit.append("eval", layer="disabled", passed=True, session_id=session_id)
        return _verdict(True, [], "评估者已关闭（本轮未评估）", fallback="disabled")

    # —— 规则层：零成本先行，挡住八成明显失败 ——
    rule_failures = _rule_check(plan, answer, tool_trace)
    if rule_failures:
        feedback = "；".join(f["detail"] for f in rule_failures[:3])
        audit.append(
            "eval", layer="rule", passed=False, session_id=session_id,
            failures_count=len(rule_failures),
            detail=feedback[:300],
        )
        return _verdict(False, rule_failures, f"规则层判定未通过：{feedback}", score=0)

    # 规则层通过也留痕
    audit.append("eval", layer="rule", passed=True, session_id=session_id)

    # —— 语义层：对照验收标准判定模型产出内容 ——
    acceptance = ""
    if plan:
        acc = plan.get("acceptance") or []
        lines = [f"- {a}" for a in acc]
        for s in plan.get("steps") or []:
            if isinstance(s, dict) and s.get("success"):
                lines.append(f"- [{s.get('id')}] {s['success']}")
        if lines:
            acceptance = "\n".join(lines[:12])
    system = (
        "你是独立质量评估器（未参与执行）。对照用户请求与验收标准，判断助手回答是否合格。\n"
        "合格标准：直接回应请求、事实与工具结果一致、无明显遗漏与编造。\n"
        "输出严格 JSON："
        '{"pass": true|false, "score": 0-100, '
        '"failures": [{"step": "s2", "detail": "具体未达标点"}], '
        '"feedback": "不合格时必须指明改哪一步、怎么改，禁止模糊结论"}。只输出 JSON。'
    )
    user = (
        f"用户请求：{query[:800]}\n"
        + (f"验收标准：\n{acceptance}\n" if acceptance else "")
        + f"助手回答：{answer[:3000]}"
    )
    try:
        raw = await complete_chat(
            [{"role": "system", "content": system}, {"role": "user", "content": user}],
            cfg={**resolve_role("evaluator"), "temperature": 0.0},
            role="evaluator",
        )
    except LLMError as e:
        logger.warning("Evaluator 不可用，默认通过: %s", e)
        audit.append(
            "eval", layer="semantic", passed=True, session_id=session_id,
            fallback="llm_unavailable", detail=str(e)[:200],
        )
        return _verdict(
            True, [], f"评估者不可用，本轮未评估（fail-open 放行）: {e}",
            fallback="llm_unavailable",
        )
    except Exception as e:  # noqa: BLE001
        logger.warning("Evaluator 异常，默认通过: %s", e)
        audit.append(
            "eval", layer="semantic", passed=True, session_id=session_id,
            fallback="exception", detail=str(e)[:200],
        )
        return _verdict(
            True, [], f"评估者异常，本轮未评估（fail-open 放行）: {e}",
            fallback="exception",
        )

    parsed = _parse(raw)
    if parsed is None:
        audit.append(
            "eval", layer="semantic", passed=True, session_id=session_id,
            fallback="parse_failed",
        )
        return _verdict(
            True, [], "评估输出不可解析，本轮未评估（fail-open 放行）",
            fallback="parse_failed",
        )
    passed = bool(parsed.get("pass", parsed.get("passed", True)))
    score = parsed.get("score")
    score = int(score) if isinstance(score, (int, float)) and 0 <= score <= 100 else None
    failures = [
        {"step": str(f.get("step") or "?")[:16], "type": "semantic", "detail": str(f.get("detail") or "")[:300]}
        for f in (parsed.get("failures") or [])[:5]
        if isinstance(f, dict)
    ]
    feedback = str(parsed.get("feedback") or "").strip()
    if not passed and not feedback:
        feedback = "回答未满足验收标准，请补充完整后重新回答"
    if not passed and not failures:
        failures = [{"step": "final", "type": "semantic", "detail": feedback[:200]}]
    audit.append(
        "eval", layer="semantic", passed=passed, session_id=session_id,
        score=score, failures_count=len(failures),
    )
    return _verdict(passed, failures, feedback, score)
