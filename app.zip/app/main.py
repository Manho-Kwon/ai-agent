"""FastAPI 应用装配（对齐原版 server.py 裁剪版 + 编排管道装配）。

lifespan 顺序：tls → data/config → sessions → skills 示例 → mcp(load + 后台
connect_all) → job scheduler。静态托管 web/dist（SPA fallback + 路径遍历防护）。
认证中间件：auth.enabled 时 /api/* 校验 Bearer token（/api/health 与
/api/auth/* 除外，auth 开关本身仅本机可调）。
"""
from __future__ import annotations

import asyncio
import contextlib
import hmac
import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from . import skill_manager, tls
from .automation_manager import automation_manager
from .config import LIBRARY_DIR, WEB_DIST_DIR, init_data_dir, load_config
from .job_scheduler import job_scheduler
from .mcp_manager import mcp_manager
from .routes import (
    auth,
    automations,
    chat,
    connections,
    extras,
    mcp,
    rag,
    retrieval,
    sessions,
    settings,
    storage,
    workspaces,
)
from .session_manager import session_manager
from .workspace_manager import workspace_manager

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)-7s %(name)s: %(message)s",
)
logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(_: FastAPI):
    init_data_dir()
    tls.setup_os_trust()
    session_manager.load()
    skill_manager.init_samples()
    mcp_manager.load_config()
    connect_task = asyncio.create_task(
        mcp_manager.connect_all(), name="mcp-connect-all"
    )
    workspace_manager.start_daily_loop()
    await job_scheduler.start()
    await automation_manager.start()
    logger.info("Arche Agent 工作台就绪: http://127.0.0.1:4830")
    yield
    await automation_manager.stop()
    await job_scheduler.stop()
    await workspace_manager.stop_daily_loop()
    with contextlib.suppress(asyncio.CancelledError):
        connect_task.cancel()
        await connect_task
    await mcp_manager.disconnect_all()


app = FastAPI(title="Arche Agent Platform", lifespan=lifespan)

# --- 认证中间件（auth.enabled 时 /api/* 统一校验 Bearer token） ---

_AUTH_EXEMPT = ("/api/health",)  # 无需认证的 /api 端点（/api/auth/* 整段豁免）
_AUTH_EXEMPT_PREFIX = ("/api/auth",)


@app.middleware("http")
async def auth_middleware(request: Request, call_next):
    path = request.url.path
    if path.startswith("/api") and path not in _AUTH_EXEMPT and not path.startswith(_AUTH_EXEMPT_PREFIX):
        cfg = load_config().get("auth") or {}
        if cfg.get("enabled") and cfg.get("token"):
            header = request.headers.get("authorization") or ""
            provided = header[7:].strip() if header.lower().startswith("bearer ") else ""
            if not provided or not hmac.compare_digest(provided, str(cfg["token"])):
                return JSONResponse({"detail": "未认证：请携带 Authorization: Bearer <token>"}, status_code=401)
    return await call_next(request)


app.include_router(sessions.router)
app.include_router(chat.router)
app.include_router(auth.router)
app.include_router(mcp.router)
app.include_router(connections.router)
app.include_router(settings.router)
app.include_router(storage.router)
app.include_router(retrieval.router)
app.include_router(extras.router)
app.include_router(workspaces.router)
app.include_router(automations.router)
app.include_router(rag.router)


@app.get("/api/health")
async def health():
    return {"status": "ok", "service": "arche-agent"}


# --- 资料库文件托管（上传/导入的网页、图片、zip 解压产物） ---
# 必须在 SPA 兜底路由之前挂载；目录需在构造 StaticFiles 前存在
LIBRARY_DIR.mkdir(parents=True, exist_ok=True)
app.mount("/library", StaticFiles(directory=LIBRARY_DIR), name="library")

# --- 静态托管（web/dist 存在时启用；启动后新增前端需重启生效） ---
if WEB_DIST_DIR.exists():
    app.mount(
        "/assets",
        StaticFiles(directory=WEB_DIST_DIR / "assets"),
        name="assets",
    )

    @app.get("/{full_path:path}", include_in_schema=False)
    async def spa(full_path: str):
        candidate = (WEB_DIST_DIR / full_path).resolve()
        # 路径遍历防护：仅允许 dist 内的真实文件
        if (
            full_path
            and candidate.is_file()
            and candidate.is_relative_to(WEB_DIST_DIR.resolve())
        ):
            return FileResponse(candidate)
        return FileResponse(WEB_DIST_DIR / "index.html")