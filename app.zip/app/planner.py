"""Planner — 规划者：请求分析 → 结构化执行计划（对齐方案 M2 plan.json）。

输出 JSON：{intent, goal, steps: [{id, tool, params, success}], tool_hints[], acceptance[]}。
- steps 为结构化步骤：绑定注册表内真实工具（摘要注入防 schema 灌爆）、
  写明 success 验收标准（规划器与评估器之间的契约）、≤8 步
- revise()：携评估反馈重新生成整份计划（修订是重生，不做局部补丁）
- bind_skills()：请求命中技能触发词时把 skill_load 写成首步，由评估器规则层强制执行
- LLM 不可用/输出不可解析时回退启发式计划（fail-open，管道不中断）
"""
from __future__ import annotations

import json
import logging
from typing import Any

from .config import load_config
from .llm import LLMError, complete_chat
from .model_router import resolve_role
from .skill_manager import index_text, match_skills

logger = logging.getLogger(__name__)

MAX_STEPS = 8  # 超长计划说明目标太大，防失控的第一道闸


def _fallback_plan(query: str, note: str) -> dict[str, Any]:
    return {
        "intent": query[:120],
        "goal": query[:200],
        "steps": [
            {"id": "s1", "tool": "", "params": {}, "success": "回答与请求直接相关"},
        ],
        "tool_hints": [],
        "acceptance": ["回答与请求直接相关"],
        "_fallback": note,
    }


def _extract_json(raw: str) -> dict[str, Any] | None:
    raw = (raw or "").strip()
    start = raw.find("{")
    end = raw.rfind("}")
    if start < 0 or end <= start:
        return None
    try:
        data = json.loads(raw[start : end + 1])
        return data if isinstance(data, dict) else None
    except json.JSONDecodeError:
        return None


def _as_str_list(v: Any, cap: int) -> list[str]:
    if not isinstance(v, list):
        return []
    return [str(x).strip() for x in v if str(x or "").strip()][:cap]


def _normalize_steps(v: Any) -> list[dict[str, Any]]:
    """规范化步骤列表：字符串步骤 → 结构化步骤；裁到 MAX_STEPS。"""
    if not isinstance(v, list):
        return []
    steps: list[dict[str, Any]] = []
    for i, s in enumerate(v[:MAX_STEPS]):
        sid = f"s{i + 1}"
        if isinstance(s, dict):
            params = s.get("params")
            steps.append({
                "id": str(s.get("id") or sid)[:16],
                "tool": str(s.get("tool") or "")[:64],
                "params": params if isinstance(params, dict) else {},
                "success": str(s.get("success") or "").strip()[:300],
            })
        elif str(s or "").strip():
            steps.append({"id": sid, "tool": "", "params": {}, "success": str(s).strip()[:300]})
    return steps


def _normalize_plan(plan: dict[str, Any] | None, query: str) -> dict[str, Any] | None:
    if not isinstance(plan, dict):
        return None
    steps = _normalize_steps(plan.get("steps"))
    if not steps:
        return None
    return {
        "intent": str(plan.get("intent") or query[:120])[:200],
        "goal": str(plan.get("goal") or plan.get("intent") or query[:200])[:300],
        "steps": steps,
        "tool_hints": _as_str_list(plan.get("tool_hints"), 8),
        "acceptance": _as_str_list(plan.get("acceptance"), 3) or ["回答与请求直接相关"],
    }


def _system_prompt(tier: str, tool_digest: str, skills: str) -> str:
    tool_part = ""
    if tool_digest:
        tool_part = (
            "\n可用工具清单（仅名称与描述，完整参数 schema 由执行阶段提供）：\n"
            f"{tool_digest}\n"
            "步骤若需工具，必须绑定清单内已注册工具名，禁止虚构；"
            "纯回答类任务 tool 留空。params 只写关键参数提示，禁止复制大段内容。\n"
        )
    skill_part = f"\n可用技能索引：\n{skills}" if skills else ""
    return (
        "你是 Planner（规划者）。分析用户请求，产出结构化执行计划。\n"
        "输出严格 JSON：\n"
        '{"intent": str, "goal": str, '
        '"steps": [{"id": "s1", "tool": "工具名或空", "params": {}, "success": "该步验收标准"}], '
        '"tool_hints": [str, ≤8], "acceptance": [str, ≤3]}。\n'
        "要求：\n"
        "1. 每个步骤写清 success 验收标准（可客观检验优先）——这是评估者的唯一判定依据；\n"
        f"2. 步骤数不超过 {MAX_STEPS}，超出说明目标太大，应向上反馈建议拆分子任务；\n"
        f"3. deep 层给出更细的 steps；standard 层保持 2-4 步。只输出 JSON。"
        + tool_part + skill_part
    )


async def _call_planner(system: str, user: str, note_prefix: str) -> dict[str, Any] | None:
    try:
        raw = await complete_chat(
            [{"role": "system", "content": system}, {"role": "user", "content": user}],
            cfg=resolve_role("planner"),
            role="planner",
        )
    except LLMError as e:
        logger.warning("Planner 不可用（%s）", e)
        return None
    except Exception as e:  # noqa: BLE001
        logger.warning("Planner 异常: %s", e)
        return None
    return _extract_json(raw)


async def make_plan(
    query: str, tier: str, tool_digest: str = ""
) -> dict[str, Any] | None:
    """tier=fast 或配置关闭时返回 None（跳过规划）。"""
    cfg = load_config()
    if tier == "fast" or tier == "fixed" or not cfg["planner"].get("enabled", True):
        return None
    skills = index_text(10)
    raw_plan = await _call_planner(_system_prompt(tier, tool_digest, skills), query, "规划")
    plan = _normalize_plan(raw_plan, query)
    if plan is None:
        note = "planner 输出不可解析" if raw_plan else "planner 不可用，启发式计划"
        plan = _fallback_plan(query, note)
    return plan


def bind_skills(plan: dict[str, Any] | None, query: str) -> dict[str, Any] | None:
    """请求命中技能时把 skill_load 写成计划首步（幂等）。

    评估器规则层（evaluator._rule_check）会判定「计划声明的注册表工具未被成功调用」
    不合格并触发返工，所以步骤一旦进计划，执行者就必须真的调用 skill_load——
    强制力来自既有机制，这里只负责把步骤放进去。
    """
    if not plan or not load_config()["skills"].get("enabled", True):
        return plan
    steps = [s for s in (plan.get("steps") or []) if isinstance(s, dict)]
    matched = match_skills(query, limit=1)
    if not matched:
        return plan
    name = str(matched[0]["name"])
    planned = [s for s in steps if s.get("tool") == "skill_load"]
    if planned:
        # 规划器自己规划了 skill_load，但参数键名常写错（skill/skill_name）——替换为规范步骤，
        # 沿用原步骤 id 以免打乱已发出的 step_update 编号
        sid = str(planned[0].get("id") or "s0")
        rest = [s for s in steps if s.get("tool") != "skill_load"]
    else:
        sid = "sk0" if any(s.get("id") == "s0" for s in steps) else "s0"
        rest = steps
    bound = dict(plan)
    bound["steps"] = [
        {
            "id": sid,
            "tool": "skill_load",
            "params": {"name": name},
            "success": f"技能 {name} 的完整指令已加载，回答严格遵循其中的输出要求",
        },
        *rest,
    ][:MAX_STEPS]
    bound["_skill_bound"] = name
    # 已含真实工具步骤，不再是纯占位计划：摘掉豁免标记让规则层对 skill_load 生效
    bound.pop("_fallback", None)
    return bound


async def revise_plan(
    query: str, plan: dict[str, Any], feedback: str, tool_digest: str = ""
) -> dict[str, Any] | None:
    """携评估反馈重新生成整份计划（fail-open：失败返回 None，调用方退回反馈执行者）。"""
    cfg = load_config()
    if not cfg["planner"].get("enabled", True):
        return None
    skills = index_text(10)
    user = (
        f"用户请求：{query[:800]}\n\n"
        f"上一份计划：\n{json.dumps(plan, ensure_ascii=False)[:2000]}\n\n"
        f"评估者反馈（验收未通过）：{feedback[:800]}\n\n"
        "请修订并重新生成整份计划（保留仍然有效的步骤，修正未达标步骤），只输出 JSON。"
    )
    raw_plan = await _call_planner(
        _system_prompt("standard", tool_digest, skills), user, "修订"
    )
    revised = _normalize_plan(raw_plan, query)
    if revised is not None:
        revised["_revised"] = True
    return revised
