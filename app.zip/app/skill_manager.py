"""Agent Skills：data/skills/*.md 技能卡（frontmatter 元数据 + 正文指令）。

格式：
---
name: translate
description: 一句话描述（注入 P2 技能索引）
triggers: 翻译,译成,translate    # 可选：请求命中触发词即判定与该技能相关
enabled: true                    # 可选，默认 true；false 时对模型全链路隐藏
---
正文：加载后注入执行者的完整指令
"""
from __future__ import annotations

import logging
import re
import threading
from pathlib import Path
from typing import Any

from .config import SKILLS_DIR

logger = logging.getLogger(__name__)

_lock = threading.Lock()

_SAMPLES: list[tuple[str, str, str, str]] = [
    (
        "translate",
        "中英互译技能：用户给出文本时按目标语言直接翻译，保留格式与术语",
        "翻译,译成,译文,英译中,中译英,translate",
        "当用户要求翻译时：\n1. 自动识别源语言，目标语言取用户指定，未指定则中→英、英→中；\n2. 保留 markdown 结构、代码块与专有名词；\n3. 只输出译文，不附加解释。",
    ),
    (
        "summarize",
        "摘要技能：对长文本/工具结果产出要点式摘要",
        "总结,摘要,概括,要点,summarize",
        "当用户要求总结/摘要时：\n1. 先给一句话结论；\n2. 再给 3-7 条要点（bullet）；\n3. 数字与专有名词必须保留原文。",
    ),
    (
        "code_review",
        "代码评审技能：按正确性/边界/安全/风格四维度输出评审结论",
        "评审,审查代码,代码检查,review",
        "当用户要求评审代码时，按以下维度输出：\n1. 正确性（逻辑错误、边界条件）；\n2. 异常处理与资源释放；\n3. 安全（注入、路径遍历、密钥泄漏）；\n4. 风格与可维护性。\n每条给出 位置 + 问题 + 建议。",
    ),
]


def init_samples() -> None:
    """skills 目录为空时写入示例技能卡（已存在文件一律不动）。"""
    SKILLS_DIR.mkdir(parents=True, exist_ok=True)
    with _lock:
        existing = list(SKILLS_DIR.glob("*.md"))
        if existing:
            return
        for name, desc, triggers, body in _SAMPLES:
            path = SKILLS_DIR / f"{name}.md"
            path.write_text(
                f"---\nname: {name}\ndescription: {desc}\ntriggers: {triggers}\n---\n{body}\n",
                encoding="utf-8",
            )
        logger.info("已生成 %d 个示例技能卡", len(_SAMPLES))


_TOKEN_RE = re.compile(r"[A-Za-z0-9_]+|[\u4e00-\u9fff]+")


def _split_triggers(raw: str) -> list[str]:
    """触发词按逗号/分号/空白切分并去重（每项 ≤32 字符，最多 12 项）。"""
    out: list[str] = []
    for part in re.split(r"[,，;；\s]+", (raw or "").strip()):
        part = part.strip()
        if part and part not in out:
            out.append(part[:32])
    return out[:12]


def _tokens(text: str) -> set[str]:
    """中英混合分词：ASCII 词整体小写，中文取相邻二字组（无词典依赖）。"""
    toks: set[str] = set()
    for m in _TOKEN_RE.finditer(text or ""):
        w = m.group(0)
        if w.isascii():
            toks.add(w.lower())
        else:
            for i in range(len(w) - 1):
                toks.add(w[i : i + 2])
    return toks


def _parse(path: Path) -> dict[str, Any]:
    text = path.read_text(encoding="utf-8", errors="replace")
    name = path.stem
    desc = ""
    enabled = True
    triggers: list[str] = []
    body = text
    if text.startswith("---"):
        parts = text.split("---", 2)
        if len(parts) >= 3:
            for line in parts[1].splitlines():
                if ":" in line:
                    k, v = line.split(":", 1)
                    k = k.strip()
                    v = v.strip()
                    if k == "name" and v:
                        name = v
                    elif k == "description" and v:
                        desc = v
                    elif k == "triggers" and v:
                        triggers = _split_triggers(v)
                    elif k == "enabled":
                        enabled = v.lower() not in ("false", "0", "no", "off")
            body = parts[2].strip()
    if not desc:
        first = next((ln.strip() for ln in body.splitlines() if ln.strip()), "")
        desc = first[:80] or name
    return {
        "name": name,
        "description": desc,
        "enabled": enabled,
        "triggers": triggers,
        "body": body,
    }


def _asset_counts(stem: str) -> tuple[int, int]:
    """可选资源目录 data/skills/<stem>/scripts|references 下的文件数。"""
    base = SKILLS_DIR / stem

    def count(sub: str) -> int:
        d = base / sub
        if not d.is_dir():
            return 0
        return sum(1 for p in d.rglob("*") if p.is_file())

    return count("scripts"), count("references")


def list_skills(enabled_only: bool = False) -> list[dict[str, Any]]:
    """技能卡列表。enabled_only=True 只返回启用项——模型侧（P2 索引、skill_list、
    技能匹配）一律用它，UI 管理页用默认值以便看到并重新启用禁用卡。"""
    if not SKILLS_DIR.exists():
        return []
    items = []
    for path in sorted(SKILLS_DIR.glob("*.md")):
        try:
            parsed = _parse(path)
            if enabled_only and not parsed["enabled"]:
                continue
            scripts, refs = _asset_counts(path.stem)
            items.append(
                {
                    "name": parsed["name"],
                    "description": parsed["description"],
                    "enabled": parsed["enabled"],
                    "triggers": parsed["triggers"],
                    "scripts": scripts,
                    "references": refs,
                }
            )
        except OSError as e:
            logger.warning("技能卡读取失败 %s: %s", path.name, e)
    return items


def reload_skills() -> int:
    """重扫技能目录（list 每次都现读，这里仅供 UI 反馈数量）。"""
    return len(list_skills())


def create_skill(name: str, description: str, body: str = "") -> dict[str, Any]:
    """新建技能卡 data/skills/<name>.md。"""
    name = (name or "").strip()
    description = (description or "").strip()
    if not name or not description:
        raise ValueError("技能名称与说明不能为空")
    if len(name) > 64 or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]*", name):
        raise ValueError("技能名称仅限字母、数字、连字符或下划线（≤64 字符）")
    path = SKILLS_DIR / f"{name}.md"
    if path.exists():
        raise ValueError(f"技能「{name}」已存在")
    SKILLS_DIR.mkdir(parents=True, exist_ok=True)
    path.write_text(
        f"---\nname: {name}\ndescription: {description}\nenabled: true\n---\n"
        + (body.strip() + "\n" if body.strip() else ""),
        encoding="utf-8",
    )
    return {
        "name": name,
        "description": description,
        "enabled": True,
        "triggers": [],
        "scripts": 0,
        "references": 0,
    }


def set_enabled(name: str, enabled: bool) -> dict[str, Any] | None:
    """开关技能：写回 frontmatter 的 enabled 标志。按 name 或文件 stem 匹配。"""
    if not name or "/" in name or "\\" in name or ".." in name:
        return None
    target: Path | None = None
    candidates = [SKILLS_DIR / f"{name}.md"] + sorted(SKILLS_DIR.glob("*.md"))
    for path in candidates:
        try:
            if not path.exists():
                continue
            parsed = _parse(path)
            if parsed["name"] == name or path.stem == name:
                target = path
                break
        except OSError:
            continue
    if target is None:
        return None
    text = target.read_text(encoding="utf-8", errors="replace")
    flag = "true" if enabled else "false"
    if text.startswith("---"):
        parts = text.split("---", 2)
        if len(parts) >= 3:
            lines = [
                ln
                for ln in parts[1].splitlines()
                if ln.strip() and not ln.strip().startswith("enabled:")
            ]
            front = "\n".join(lines + [f"enabled: {flag}"]).strip("\n")
            target.write_text(
                f"---\n{front}\n---\n{parts[2]}", encoding="utf-8"
            )
    else:
        target.write_text(
            f"---\nenabled: {flag}\n---\n{text}", encoding="utf-8"
        )
    # 刚禁用的卡片会被默认过滤掉，这里必须带 include_disabled 才能给 UI 回执
    return get_skill(target.stem, include_disabled=True)


def get_skill(name: str, include_disabled: bool = False) -> dict[str, Any] | None:
    """按 name 或文件 stem 精确匹配，返回完整技能卡。

    默认跳过 enabled=false 的技能（skill_load 与技能匹配用），使 UI 的技能开关
    对模型真正生效；管理界面传 include_disabled=True 才能查看禁用卡。
    """
    if not name or "/" in name or "\\" in name or ".." in name:
        return None
    candidates = [SKILLS_DIR / f"{name}.md"] + sorted(SKILLS_DIR.glob("*.md"))
    for path in candidates:
        try:
            if not path.exists():
                continue
            parsed = _parse(path)
            if not include_disabled and not parsed["enabled"]:
                continue
            if parsed["name"] == name or path.stem == name:
                return parsed
        except OSError:
            continue
    return None


def index_text(max_items: int = 20) -> str:
    """P2 注入用技能索引（name: description 行，仅启用项）。"""
    items = list_skills(enabled_only=True)[:max_items]
    if not items:
        return ""
    return "\n".join(f"- {it['name']}: {it['description']}" for it in items)


MIN_MATCH_SCORE = 3  # 低于此分视为无关：宁可漏召也不误绑技能步骤


def match_skills(query: str, limit: int = 1) -> list[dict[str, Any]]:
    """按触发词/名称/描述给请求打分，返回命中的启用技能（降序，最多 limit 个）。

    打分：触发词作为子串出现 +10（中文无词边界，子串最可靠）；触发词分词有重叠 +6；
    名称+描述的分词重叠每词 +1。请求为空或无技能达到阈值时返回 []——匹配不到就不
    绑技能步骤，管道照原路走（fail-open）。
    """
    text = (query or "").strip()
    if not text or limit <= 0:
        return []
    cards = list_skills(enabled_only=True)
    low = text.lower()
    q = _tokens(text)
    scored: list[tuple[int, dict[str, Any]]] = []
    for card in cards:
        score = 0
        for trig in card.get("triggers") or []:
            t = trig.lower()
            if t and t in low:
                score += 10
            elif q and _tokens(trig) & q:
                score += 6
        if q:
            score += len(q & _tokens(f"{card['name']} {card['description']}"))
        if score >= MIN_MATCH_SCORE:
            scored.append((score, card))
    scored.sort(key=lambda x: x[0], reverse=True)
    return [card for _, card in scored[:limit]]