"""data/ 目录管理、config.json 读写、.env 加载（对齐原版 config.py）。

原则（照搬原版）：
- 配置即文件、损坏容错：JSON 解析失败不崩服务，记录错误并暴露给 UI
- 密钥 SSOT：API Key 只存 data/.env，config.json 不存任何密钥
"""
from __future__ import annotations

import json
import os
import threading
from pathlib import Path

from dotenv import load_dotenv

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = PROJECT_ROOT / "data"
ENV_PATH = DATA_DIR / ".env"
CONFIG_PATH = DATA_DIR / "config.json"
MCP_CONFIG_PATH = DATA_DIR / "mcp.json"
SESSIONS_PATH = DATA_DIR / "sessions.json"
SESSIONS_DIR = DATA_DIR / "sessions"
MCP_CACHE_DIR = DATA_DIR / "cache" / "mcp"
WEB_DIST_DIR = PROJECT_ROOT / "web" / "dist"
SKILLS_DIR = DATA_DIR / "skills"
WORKSPACE_DIR = DATA_DIR / "workspace"
MEMORIES_PATH = DATA_DIR / "memories.json"
PAGES_PATH = DATA_DIR / "pages.json"
JOBS_PATH = DATA_DIR / "jobs.json"
# 资料库上传/导入的二进制与网页文件托管目录（/library 静态挂载）
LIBRARY_DIR = DATA_DIR / "library"
# 聊天附件（会话级一次性上下文）：data/attachments/<session_id>/<att_id>/
ATTACHMENTS_DIR = DATA_DIR / "attachments"
# 工作区注册表与索引元数据（{workspaces: {...}, meta: {...}}）
WORKSPACES_PATH = DATA_DIR / "workspaces.json"
# 自动化任务与运行记录（{automations: {...}, runs: [...], meta: {...}}）
AUTOMATIONS_PATH = DATA_DIR / "automations.json"

DEFAULT_BASE_URL = "http://192.168.1.128:9800/v1"

_DEFAULT_CONFIG: dict = {
    "ui": {
        "title": "Arche Agent Platform",
        "subtitle": "Arche Agent",
        "prompt_rules": [],
        # 界面语言（zh | ko | en），前端 i18n 初始化用
        "language": "zh",
        # 用户 / 机器人资料与品牌（设置 → 用户资料）
        "user_name": "K哥",
        "user_avatar": "",  # dataURL
        "bot_name": "Agent",
        "bot_avatar": "",  # dataURL
        "executor_instructions": "",
        # 外观（设置 → 主题与外观），mode 由前端 theme 同步写入
        "appearance": {
            "mode": "light",
            "tone": "default",  # default | warm | cool
            "accent": "indigo",
            "font_scale": 100,  # 85 - 150
            "glow": False,
            "chat_bg_kind": "none",  # none | custom
            "chat_bg": "",  # dataURL
        },
    },
    "llm": {
        "base_url": DEFAULT_BASE_URL,
        "model": "",
        "temperature": 0.7,
        "max_tokens": 8192,
        "max_tool_rounds": 25,
        # 历史滑窗：单次请求最多携带的近期历史消息条数（开头 2 条始终保留，见 session_manager）
        "history_max_messages": 40,
        # 降级链：主模型调用失败（网络/5xx 重试耗尽）后换该模型再试一次，空 = 不降级
        "fallback_model": "",
    },
    # RAG 知识库（kb_search/kb_answer 工具与 /api/rag）
    "rag": {
        "enabled": True,
        "embed_model": "",  # 空 = 自动探测网关 embedding 模型，探测失败则纯 BM25
        "chunk_size": 512,
        "chunk_overlap": 64,
        "top_k": 8,           # 混合召回条数
        "rrf_k": 60,          # RRF 融合常数
        "rerank_top_n": 4,    # 融合后保留条数
        "refuse_threshold": 0.35,  # 相关度下限：低于即拒答
    },
    # 访问认证（红线：共享给团队前必须开启）：enabled 时 API 校验 Bearer token
    "auth": {"enabled": False, "token": ""},
    # LiteLLM 式抽象层：命名 provider 声明（base_url + api_key_env，密钥仍走环境变量）
    "providers": {},
    # 按角色分离模型：model 空 = 继承 llm.model；provider 空/default = 默认网关
    "roles": {
        "planner": {"provider": "default", "model": ""},
        "executor": {"provider": "default", "model": ""},
        # 恢复执行者：工具连续失败 / 执行模型报错后切换的后备模型（空 = 与 executor 同源）
        "executor_recovery": {"provider": "default", "model": ""},
        "evaluator": {"provider": "default", "model": ""},
        "memory": {"provider": "default", "model": ""},
        # 文档链路角色（设置 → LLM 配置；解析/文档/多模态后备）
        "doc_compose": {"provider": "default", "model": ""},
        "doc_parse": {"provider": "default", "model": ""},
        "multimodal": {"provider": "default", "model": ""},
    },
    "workflow": {"mode": "auto"},  # auto | fast | standard | deep
    # 工作区检索（设置 → 工作区检索）：搜索运行模式
    "retrieval": {"mode": "auto"},  # auto | fast | precise
    # 模型连接（设置 → LLM 配置 → 管理模型连接）：内置提供商验证状态 +
    # 自定义模型验证状态（custom_models 按 provider id 键控）。
    # 状态值：disconnected | unverified | connected | error
    "connections": {
        "internal": {"status": "unverified", "last_checked": None, "error": None},
        "internal_proxy": {"status": "unverified", "last_checked": None, "error": None},
        "custom_models": {},
    },
    # 运行与存储（设置 → 运行与存储）
    "runtime": {"allow_export": False, "yolo_mode": False},
    "planner": {"enabled": True},
    "evaluator": {"enabled": True, "max_rework": 3},
    "memory": {"enabled": True, "auto_extract": True, "inject_top_k": 5, "max_items": 200},
    "skills": {"enabled": True},
    "workspace": {"enabled": True},
    "doc": {"enabled": True},
    "jobs": {"enabled": True},
    "pages": {"enabled": True},
}

_DEFAULT_MCP: dict = {
    "mcpServers": {
        "sequential-thinking": {
            "transport": "stdio",
            "command": "npx",
            "args": ["-y", "@modelcontextprotocol/server-sequential-thinking@2026.7.4"],
            "enabled": True,
        },
    },
}

_DEFAULT_ENV = """# ── Arche Agent 工作台本地配置 ─────────────────────────────
# LLM 网关 API Key（必填）。密钥只存这里，不会出现在 config.json / 代码里。
API_KEY=

# 可选覆盖项（不设置则使用 config.json 中的值）
# LLM_BASE_URL=http://192.168.1.128:9800/v1
# LLM_MODEL=
"""

_lock = threading.Lock()
_config: dict | None = None
mcp_config_error: str | None = None  # mcp.json 解析失败原因（UI 展示用）


def init_data_dir() -> Path:
    """首次启动生成 data/ 与默认配置；已存在文件一律不动。"""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    SESSIONS_DIR.mkdir(parents=True, exist_ok=True)
    MCP_CACHE_DIR.mkdir(parents=True, exist_ok=True)
    SKILLS_DIR.mkdir(parents=True, exist_ok=True)
    WORKSPACE_DIR.mkdir(parents=True, exist_ok=True)
    LIBRARY_DIR.mkdir(parents=True, exist_ok=True)
    ATTACHMENTS_DIR.mkdir(parents=True, exist_ok=True)

    if not ENV_PATH.exists():
        ENV_PATH.write_text(_DEFAULT_ENV, encoding="utf-8")
    if not CONFIG_PATH.exists():
        CONFIG_PATH.write_text(
            json.dumps(_DEFAULT_CONFIG, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
    if not MCP_CONFIG_PATH.exists():
        MCP_CONFIG_PATH.write_text(
            json.dumps(_DEFAULT_MCP, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )
    if not SESSIONS_PATH.exists():
        SESSIONS_PATH.write_text('{"sessions": {}}\n', encoding="utf-8")

    # .env 必须在任何网络调用前加载
    load_dotenv(ENV_PATH)
    return DATA_DIR


def _load_json_file(path: Path) -> dict | None:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


def load_config() -> dict:
    """读取 config.json（带进程内缓存）。缺失/损坏时回退默认值。"""
    global _config
    with _lock:
        if _config is not None:
            return _config
        data = _load_json_file(CONFIG_PATH)
        if not isinstance(data, dict):
            _config = json.loads(json.dumps(_DEFAULT_CONFIG))
            return _config
        # 逐节合并默认值，缺字段自动补齐（roles 做二层合并，允许只覆盖单个角色）
        merged = json.loads(json.dumps(_DEFAULT_CONFIG))
        for section, default in _DEFAULT_CONFIG.items():
            val = data.get(section)
            if not isinstance(default, dict) or not isinstance(val, dict):
                continue
            if section == "roles":
                for role, spec in val.items():
                    if isinstance(spec, dict):
                        merged[section].setdefault(role, {}).update(spec)
            else:
                merged[section].update(val)
        _config = merged
        return _config


def atomic_write_json(path: Path, data: dict | list) -> None:
    """原子写 JSON：先写临时文件再 os.replace，避免进程崩溃留下半截文件。"""
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(
        json.dumps(data, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    os.replace(tmp, path)


def save_config(cfg: dict) -> None:
    global _config
    with _lock:
        atomic_write_json(CONFIG_PATH, cfg)
        _config = cfg


def update_config(updates: dict) -> dict:
    cfg = load_config()
    for section, val in (updates or {}).items():
        if section in _DEFAULT_CONFIG and isinstance(val, dict):
            cfg.setdefault(section, {}).update(val)
    save_config(cfg)
    return cfg


def llm_settings() -> dict:
    """生效的 LLM 设置：.env 覆盖 > config.json > 内置默认。"""
    cfg = load_config()
    llm = dict(cfg["llm"])
    if os.getenv("LLM_BASE_URL", "").strip():
        llm["base_url"] = os.getenv("LLM_BASE_URL").strip()
    if os.getenv("LLM_MODEL", "").strip():
        llm["model"] = os.getenv("LLM_MODEL").strip()
    return llm


def api_key() -> str:
    return os.getenv("API_KEY", "").strip()


def _read_env_lines() -> list[str]:
    if not ENV_PATH.exists():
        return []
    return ENV_PATH.read_text(encoding="utf-8").splitlines()


def set_env_key(key: str, value: str) -> None:
    """在 data/.env 中设置/更新一个环境变量并同步到当前进程。

    密钥 SSOT：界面录入的密钥只写 .env，永不进入 config.json。
    保留注释与其他行；已存在的键就地替换，否则追加。
    """
    lines = _read_env_lines()
    found = False
    out: list[str] = []
    for line in lines:
        stripped = line.strip()
        if (
            stripped
            and not stripped.startswith("#")
            and stripped.split("=", 1)[0].strip() == key
        ):
            out.append(f"{key}={value}")
            found = True
        else:
            out.append(line)
    if not found:
        if out and out[-1].strip():
            out.append("")
        out.append(f"{key}={value}")
    ENV_PATH.write_text("\n".join(out) + "\n", encoding="utf-8")
    os.environ[key] = value


def delete_env_key(key: str) -> None:
    """从 data/.env 移除一个环境变量（删除自定义模型时清理其密钥）。"""
    lines = _read_env_lines()
    if not lines:
        os.environ.pop(key, None)
        return
    out = [
        line
        for line in lines
        if not (
            line.strip()
            and not line.strip().startswith("#")
            and line.split("=", 1)[0].strip() == key
        )
    ]
    ENV_PATH.write_text("\n".join(out) + "\n", encoding="utf-8")
    os.environ.pop(key, None)


def normalize_base_url(base_url: str) -> str:
    """OpenAI 兼容 base 规范化：保证以 /v1 结尾（对齐原版 llm_endpoints.py）。"""
    value = (base_url or "").strip().rstrip("/")
    if not value:
        return value
    last = value.rsplit("/", 1)[-1]
    if last != "v1":
        value = f"{value}/v1"
    return value