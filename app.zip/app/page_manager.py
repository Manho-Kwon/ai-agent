"""Page Tools：资料库页面/书签/文件夹存储（data/pages.json + data/library/ 文件托管）。

页面类型（kind）：
- page     文本页面（HTML / Markdown / 代码 / 纯文本），内容存 pages.json
- folder   文件夹，可嵌套（parent_id），用于整理页面
- bookmark 外部 URL 书签或其他 Agent 托管页面（hosted=True），内容实时从源站加载
- file     上传/导入的二进制文件（图片、zip 等），实体文件存 data/library/<id>/

工具 + REST 双入口；自动归档（workspace 输出文件）走 upsert_source。
"""
from __future__ import annotations

import io
import json
import logging
import shutil
import threading
import uuid
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import quote, urlparse

from .config import LIBRARY_DIR, PAGES_PATH
from . import doc_parser

logger = logging.getLogger(__name__)
_lock = threading.Lock()

# 单页文本内容上限（字符）。输出报告类文件较大，放宽到 10 万。
_CONTENT_CAP = 100_000
# 上传/导入文件大小上限（字节）：15 MB
_MAX_FILE_BYTES = 15 * 1024 * 1024

# 可作为文本读取的扩展名（其余按二进制文件托管）
TEXT_EXTS = {
    ".html", ".htm", ".jsx", ".tsx", ".js", ".mjs", ".ts", ".md", ".markdown",
    ".css", ".json", ".xml", ".csv", ".txt", ".svg", ".log", ".yaml", ".yml",
}
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".ico", ".bmp", ".avif"}

_KIND_PAGE = "page"
_KIND_FOLDER = "folder"
_KIND_BOOKMARK = "bookmark"
_KIND_FILE = "file"


def _now() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def _safe_filename(name: str) -> str:
    """取 basename 并去掉危险字符，保证可安全落盘 / 拼 URL。"""
    name = Path((name or "").strip()).name.strip()
    for ch in '<>:"|?*':
        name = name.replace(ch, "_")
    return name or "file"


def _validate_url(url: str) -> str:
    url = (url or "").strip()
    parsed = urlparse(url)
    if parsed.scheme not in ("http", "https") or not parsed.netloc:
        raise ValueError("URL 格式不正确，请输入以 http:// 或 https:// 开头的完整地址")
    return url


class PageManager:
    def __init__(self) -> None:
        self._pages: dict[str, dict[str, Any]] = {}
        self._loaded = False

    def _load(self) -> None:
        if self._loaded:
            return
        try:
            data = json.loads(PAGES_PATH.read_text(encoding="utf-8"))
            pages = data.get("pages", {})
            self._pages = {k: v for k, v in pages.items() if isinstance(v, dict)}
        except (json.JSONDecodeError, OSError):
            self._pages = {}
        self._loaded = True

    def _save(self) -> None:
        PAGES_PATH.write_text(
            json.dumps({"pages": self._pages}, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )

    # ── 内部工具 ──────────────────────────────────────────────

    def _validate_parent(self, parent_id: str) -> None:
        if not parent_id:
            return
        parent = self._pages.get(parent_id)
        if parent is None:
            raise ValueError("父文件夹不存在，可能已被删除")
        if parent.get("kind", _KIND_PAGE) != _KIND_FOLDER:
            raise ValueError("目标位置不是文件夹")

    def _new_record(
        self,
        title: str,
        kind: str,
        *,
        description: str = "",
        parent_id: str = "",
        source: str = "",
        default_title: str = "未命名页面",
    ) -> dict[str, Any]:
        now = _now()
        return {
            "id": uuid.uuid4().hex[:8],
            "title": (title or "").strip()[:80] or default_title,
            "description": (description or "").strip()[:500],
            "kind": kind,
            "parent_id": parent_id or "",
            "source": source or "",
            "content": "",
            "url": "",
            "hosted": False,
            "file_name": "",
            "file_size": 0,
            "created_at": now,
            "updated_at": now,
        }

    def _files_dir(self, page_id: str) -> Path:
        d = LIBRARY_DIR / page_id
        d.mkdir(parents=True, exist_ok=True)
        return d

    def _public(self, rec: dict[str, Any]) -> dict[str, Any]:
        """对外视图：补齐 kind/parent_id 等字段并计算 size（与 list() 保持一致）。"""
        content = rec.get("content") or ""
        return {
            **rec,
            "kind": rec.get("kind", _KIND_PAGE),
            "parent_id": rec.get("parent_id", ""),
            "description": rec.get("description", ""),
            "url": rec.get("url", ""),
            "hosted": rec.get("hosted", False),
            "file_name": rec.get("file_name", ""),
            "file_size": rec.get("file_size", 0),
            "source": rec.get("source", ""),
            "size": rec.get("file_size") or len(content.encode("utf-8")),
        }

    def _remove_files(self, page_id: str) -> None:
        shutil.rmtree(LIBRARY_DIR / page_id, ignore_errors=True)

    def _store_bytes(self, rec: dict[str, Any], data: bytes, filename: str) -> None:
        """把二进制文件落到 data/library/<id>/，zip 自动解压；回填 url / file_size。"""
        if len(data) > _MAX_FILE_BYTES:
            raise ValueError(f"文件超过 15 MB 上限（实际 {len(data) / 1024 / 1024:.1f} MB）")
        name = _safe_filename(filename)
        d = self._files_dir(rec["id"])
        rec["file_name"] = name
        rec["file_size"] = len(data)

        if name.lower().endswith(".zip"):
            try:
                with zipfile.ZipFile(io.BytesIO(data)) as zf:
                    for member in zf.namelist():
                        # zip-slip 防护：解压目标必须在目录内
                        target = (d / member).resolve()
                        if not target.is_relative_to(d.resolve()):
                            raise ValueError(f"压缩包内存在非法路径：{member}")
                    zf.extractall(d)
            except zipfile.BadZipFile:
                raise ValueError("文件不是有效的 zip 压缩包")
            index = d / "index.html"
            entry = "index.html" if index.is_file() else name
            rec["url"] = f"/library/{rec['id']}/{quote(entry)}"
        else:
            (d / name).write_bytes(data)
            rec["url"] = f"/library/{rec['id']}/{quote(name)}"

    # ── 写入入口 ──────────────────────────────────────────────

    def create(self, title: str, content: str) -> dict[str, Any]:
        """兼容旧入口（工具 page_save / 旧版 POST /api/pages）。"""
        return self.add_text(title, "", content, source="manual")

    def add_text(
        self,
        title: str,
        description: str,
        content: str,
        *,
        source: str = "manual",
        parent_id: str = "",
        file_name: str = "",
    ) -> dict[str, Any]:
        with _lock:
            self._load()
            self._validate_parent(parent_id)
            rec = self._new_record(
                title, _KIND_PAGE, description=description,
                parent_id=parent_id, source=source,
            )
            rec["content"] = (content or "")[:_CONTENT_CAP]
            rec["file_name"] = file_name or ""
            rec["file_size"] = len(rec["content"].encode("utf-8"))
            self._pages[rec["id"]] = rec
            self._save()
            return self._public(rec)

    def add_folder(self, title: str, description: str = "", parent_id: str = "") -> dict[str, Any]:
        with _lock:
            self._load()
            self._validate_parent(parent_id)
            rec = self._new_record(
                title, _KIND_FOLDER, description=description,
                parent_id=parent_id, default_title="新建文件夹",
            )
            self._pages[rec["id"]] = rec
            self._save()
            return self._public(rec)

    def add_bookmark(
        self,
        url: str,
        title: str = "",
        description: str = "",
        parent_id: str = "",
        *,
        hosted: bool = False,
    ) -> dict[str, Any]:
        url = _validate_url(url)
        with _lock:
            self._load()
            self._validate_parent(parent_id)
            default_title = urlparse(url).netloc or url
            rec = self._new_record(
                title, _KIND_BOOKMARK, description=description,
                parent_id=parent_id, source=f"{'hosted' if hosted else 'url'}:{url}",
                default_title=default_title,
            )
            rec["url"] = url
            rec["hosted"] = hosted
            self._pages[rec["id"]] = rec
            self._save()
            return self._public(rec)

    def add_file_bytes(
        self,
        title: str,
        description: str,
        data: bytes,
        filename: str,
        parent_id: str = "",
        *,
        source: str = "",
    ) -> dict[str, Any]:
        name = _safe_filename(filename)
        with _lock:
            self._load()
            self._validate_parent(parent_id)
            rec = self._new_record(
                title or name, _KIND_FILE, description=description,
                parent_id=parent_id, source=source or f"upload:{name}",
                default_title=name,
            )
            self._store_bytes(rec, data, name)
            ext = Path(name).suffix.lower()
            if ext in doc_parser.DOC_EXTS or ext in doc_parser.IMAGE_EXTS:
                # 二进制/图片也解析出文本进 RAG 索引；失败回落仅托管
                try:
                    res = doc_parser.parse_bytes(data, ext)
                    text = (res["text"] or "").strip()
                    if text:
                        if len(text) > _CONTENT_CAP:
                            text = text[:_CONTENT_CAP] + f"\n[文本已截断，原文共 {len(text)} 字符]"
                        rec["content"] = text
                except Exception as e:  # noqa: BLE001 — 解析失败不阻断托管
                    logger.warning("资料库文件 %s 解析失败（仅托管）: %s", name, e)
            self._pages[rec["id"]] = rec
            self._save()
            return self._public(rec)

    def import_from_path(
        self, path: str, title: str = "", description: str = "", parent_id: str = ""
    ) -> dict[str, Any]:
        """读取服务器本机绝对路径上的文件：文本类注册为页面，二进制类拷贝托管。"""
        raw_path = (path or "").strip()
        if not raw_path:
            raise ValueError("请输入文件的绝对路径")
        p = Path(raw_path).expanduser()
        if not p.is_file():
            raise ValueError(f"文件不存在或不是文件：{raw_path}")
        size = p.stat().st_size
        if size > _MAX_FILE_BYTES:
            raise ValueError(f"文件超过 15 MB 上限（实际 {size / 1024 / 1024:.1f} MB）")
        ext = p.suffix.lower()
        source = f"path:{p}"
        if ext in TEXT_EXTS:
            try:
                text = p.read_text(encoding="utf-8", errors="replace")
            except OSError as e:
                raise ValueError(f"读取文件失败：{e}")
            return self.add_text(
                title or p.name, description, text,
                source=source, parent_id=parent_id, file_name=p.name,
            )
        return self.add_file_bytes(
            title or p.name, description, p.read_bytes(), p.name,
            parent_id, source=source,
        )

    def upsert_source(self, source: str, title: str, content: str) -> dict[str, Any]:
        """按 source（如 workspace:notes/a.md）去重保存：存在则更新，否则新建。

        用于把会话中的输出结果文件自动归档进资料库。
        """
        source = (source or "").strip()
        if not source:
            return self.add_text(title, "", content, source="manual")
        title = (title or "").strip() or "未命名页面"
        with _lock:
            self._load()
            for page in self._pages.values():
                if page.get("source") == source:
                    page["title"] = title[:80]
                    page["content"] = (content or "")[:_CONTENT_CAP]
                    page["kind"] = page.get("kind", _KIND_PAGE)
                    page["file_size"] = len(page["content"].encode("utf-8"))
                    page["updated_at"] = _now()
                    self._save()
                    return self._public(page)
            rec = self._new_record(title, _KIND_PAGE, source=source)
            rec["content"] = (content or "")[:_CONTENT_CAP]
            rec["file_size"] = len(rec["content"].encode("utf-8"))
            self._pages[rec["id"]] = rec
            self._save()
            return self._public(rec)

    # ── 读取 / 删除 ───────────────────────────────────────────

    def list(self) -> list[dict[str, Any]]:
        with _lock:
            self._load()
            items: list[dict[str, Any]] = []
            for p in self._pages.values():
                pub = self._public(p)
                # 列表只回预览片段；文件夹/书签/文件不回内容
                if pub["kind"] != _KIND_PAGE:
                    pub["content"] = ""
                else:
                    pub["content"] = (pub.get("content") or "")[:120]
                items.append(pub)
            folders = sorted(
                (i for i in items if i["kind"] == _KIND_FOLDER),
                key=lambda i: i["title"].lower(),
            )
            others = sorted(
                (i for i in items if i["kind"] != _KIND_FOLDER),
                key=lambda i: i.get("updated_at", ""),
                reverse=True,
            )
            return folders + others

    def get(self, page_id: str) -> dict[str, Any] | None:
        with _lock:
            self._load()
            p = self._pages.get(page_id)
            return self._public(p) if p else None

    def iter_page_contents(self) -> list[dict[str, Any]]:
        """全文迭代（RAG 索引用）：返回 id/title/content/updated_at。

        收录条件是「有正文」：页面/笔记天然有；托管文件（kind=file）只有在
        doc_parser 解析出文本时才带 content，因此解析过的 PDF/Word/图片同样进索引，
        解析不出或纯托管的文件仍只存文件不进索引；文件夹无正文，自然排除。
        历史数据可能缺 kind 字段，与 _public 同语义按页面处理。
        """
        with _lock:
            self._load()
            return [
                {
                    "id": p["id"],
                    "title": p.get("title") or "",
                    "content": p.get("content") or "",
                    "updated_at": p.get("updated_at") or "",
                }
                for p in self._pages.values()
                if (p.get("content") or "").strip()
            ]

    def delete(self, page_id: str) -> bool:
        """删除页面；文件夹级联删除其下所有内容（含托管文件）。"""
        with _lock:
            self._load()
            if page_id not in self._pages:
                return False
            # 收集子树（BFS：folder 的直接/间接子项）
            to_delete = [page_id]
            for pid in to_delete:
                rec = self._pages.get(pid)
                if rec and rec.get("kind", _KIND_PAGE) == _KIND_FOLDER:
                    to_delete += [
                        k for k, v in self._pages.items()
                        if v.get("parent_id") == pid
                    ]
            for pid in to_delete:
                rec = self._pages.pop(pid, None)
                if rec:
                    self._remove_files(pid)
            self._save()
            return True


page_manager = PageManager()
