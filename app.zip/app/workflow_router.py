"""Workflow Router：工作流四层管线（fixed / fast / standard / deep）。

- fixed：规则命中（data/workflow_rules.json，热重载）→ 固定工作流，零模型调用
- fast：直答，不规划、不挂工具、不评估（低延迟；短请求命中技能触发词时升级 standard）
- standard：Planner 规划 + Executor 工具循环 + Evaluator 验收
- deep：同 standard，但规划更细、评估更严（返工预算 evaluator.max_rework）
路由：config workflow.mode 手动指定（fast|standard|deep）或 auto 启发式 + 规则层。
返回 (tier, reason, rule_name)：tier 含 "fixed" 时 rule_name 为命中的规则名。
"""
from __future__ import annotations

import json
import re
from pathlib import Path

from .config import DATA_DIR
from .skill_manager import match_skills

RULES_PATH = DATA_DIR / "workflow_rules.json"

TIERS = ("fixed", "fast", "standard", "deep")

FAST_MAX_LEN = 24
_TOOL_HINT = (
    "文件", "工作区", "写入", "读取", "目录", "页面", "page", "记忆", "memory",
    "定时", "任务", "技能", "skill", "工具", "搜索", "查询", "mcp",
    "write", "read", "list", "schedule",
)
_DEEP_HINT = (
    "深度", "详细分析", "分析报告", "方案", "研究", "对比", "评审", "设计",
    "多步", "计划", "全面", "总结", "deep", "research", "plan",
)
_GREET = re.compile(r"^(你好|hi|hello|hey|在吗|谢谢|ok|好的|嗯)[!！.。~\s]*$", re.I)

_rules_cache: list[dict] | None = None
_rules_mtime: float = -1.0


def _load_rules() -> list[dict]:
    """加载固定工作流规则（mtime 变化热重载；文件缺失时播种默认规则）。"""
    global _rules_cache, _rules_mtime
    try:
        mtime = RULES_PATH.stat().st_mtime
    except OSError:
        mtime = -1.0
    if _rules_cache is not None and mtime == _rules_mtime:
        return _rules_cache
    if mtime < 0:
        # 播种默认规则文件（首次）
        from .fixed_flows import _dump_default_rules

        try:
            RULES_PATH.write_text(
                json.dumps(_dump_default_rules(), indent=2, ensure_ascii=False) + "\n",
                encoding="utf-8",
            )
            mtime = RULES_PATH.stat().st_mtime
        except OSError:
            _rules_cache, _rules_mtime = [], -1.0
            return _rules_cache
    try:
        data = json.loads(RULES_PATH.read_text(encoding="utf-8"))
        rules = [
            {"name": str(r.get("name") or r.get("flow") or "?"),
             "pattern": re.compile(str(r.get("pattern") or "")),
             "flow": str(r.get("flow") or "")}
            for r in (data.get("rules") or [])
            if isinstance(r, dict) and r.get("pattern") and r.get("flow")
        ]
    except (json.JSONDecodeError, re.error, OSError):
        rules = []
    _rules_cache, _rules_mtime = rules, mtime
    return rules


def match_rule(content: str) -> dict | None:
    """第一层：固定工作流规则匹配（确定性请求零模型调用）。"""
    text = (content or "").strip()
    if not text or len(text) > 120:  # 过长文本不进固定流程
        return None
    for r in _load_rules():
        try:
            if r["pattern"].search(text):
                return r
        except re.error:
            continue
    return None


def rule_flow(name: str | None) -> str | None:
    """按规则名查它对应的 flow 名（route 只回传规则名，执行方需要 flow 名）。"""
    if not name:
        return None
    for r in _load_rules():
        if r["name"] == name:
            return r["flow"] or None
    return None


def route(content: str, mode: str = "auto") -> tuple[str, str, str | None]:
    """返回 (tier, reason, rule_name)。mode 非 auto 时手动指定（fixed 规则仍优先）。"""
    text = (content or "").strip()

    # 第一层：固定工作流（确定性操作，0 次模型调用）——手动模式也优先命中
    rule = match_rule(text)
    if rule:
        return "fixed", f"命中固定工作流规则「{rule['name']}」", rule["name"]

    if mode in ("fast", "standard", "deep"):
        return mode, f"手动配置 workflow.mode={mode}", None

    low = text.lower()
    if _GREET.match(text):
        return "fast", "寒暄/致谢 → 直答层", None
    if len(text) <= FAST_MAX_LEN and not any(h in low for h in _TOOL_HINT) and not any(h in low for h in _DEEP_HINT):
        # fast 层 tools=None，命中技能的短请求必须升级才有 skill_load 可调
        if match_skills(text):
            return "standard", "短请求命中技能意图 → 标准层（需调用技能工具）", None
        return "fast", "短消息且无工具/深度意图 → 直答层", None
    if any(h in low for h in _DEEP_HINT) or len(text) > 200:
        return "deep", "命中深度分析意图或长文本 → 深度层", None
    return "standard", "默认标准层（规划+执行+评估）", None
