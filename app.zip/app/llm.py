"""OpenAI 兼容 LLM 客户端（httpx 直连，对齐原版 core/llm.py 裁剪版）。

- GET  {base}/models            网关模型列表探测
- POST {base}/chat/completions  stream=true SSE chunk 协议解析 / 非流式整包
- 工具调用增量（delta.tool_calls 分片）自动拼装
- 网络/5xx 错误重试 2 次，指数退避（1s/2s）；4xx 不重试
- 降级链：重试耗尽后若配置 llm.fallback_model 且不同于当前模型，换档再试一轮
- 计量审计：每次调用耗时/token 用量落 audit（M0 计量埋点，供 M10 成本看板）
- 角色化调用：cfg 参数由 model_router.resolve_role 注入（LiteLLM 抽象层同款语义）
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
from collections.abc import AsyncGenerator
from typing import Any

import httpx

from . import audit
from .config import api_key, llm_settings, normalize_base_url

logger = logging.getLogger(__name__)

MAX_RETRIES = 2  # 额外重试次数
RETRY_BACKOFF_S = 1.0  # 指数退避基数：第 n 次重试前等待 RETRY_BACKOFF_S * 2^n


class LLMError(Exception):
    """对用户可陈述的 LLM 调用失败（配置错误 / 4xx，重试无意义）。"""


class _RetryableError(Exception):
    """网络传输错误 / 5xx，可重试。"""


def default_cfg() -> dict[str, Any]:
    """默认角色配置（executor 语义）：.env 覆盖 > config.json > 内置默认。"""
    s = llm_settings()
    return {
        "base_url": normalize_base_url(s["base_url"]),
        "model": s["model"],
        "temperature": s["temperature"],
        "max_tokens": s["max_tokens"],
        "api_key": api_key(),
    }


def _resolve_cfg(cfg: dict[str, Any] | None) -> dict[str, Any]:
    return cfg if cfg else default_cfg()


def _headers(key: str) -> dict[str, str]:
    headers = {"Content-Type": "application/json"}
    if key:
        headers["Authorization"] = f"Bearer {key}"
    return headers


def _check_cfg(cfg: dict[str, Any]) -> None:
    if not cfg.get("base_url"):
        raise LLMError(
            "未配置网关地址（config.json → llm.base_url 或 .env → LLM_BASE_URL）"
        )
    if not cfg.get("model"):
        raise LLMError("未配置模型名：可在界面设置中选择，或编辑 data/config.json")
    if not cfg.get("api_key"):
        raise LLMError("未配置 API Key：请在 data/.env 中设置 API_KEY 后重启服务")


async def list_models(cfg: dict[str, Any] | None = None) -> list[str]:
    """探测网关模型列表（GET {base}/models）。失败抛 LLMError。"""
    c = _resolve_cfg(cfg)
    base = normalize_base_url(c["base_url"])
    if not base:
        raise LLMError("未配置网关地址（LLM_BASE_URL）")
    try:
        async with httpx.AsyncClient(timeout=15) as client:
            resp = await client.get(f"{base}/models", headers=_headers(c["api_key"]))
            resp.raise_for_status()
            data = resp.json()
    except httpx.HTTPError as e:
        raise LLMError(f"网关不可达：{e}") from e
    items = data.get("data") or []
    return [m.get("id", "") for m in items if isinstance(m, dict) and m.get("id")]


def _parse_fragments(fragments: dict[int, dict[str, Any]]) -> list[dict[str, Any]]:
    calls: list[dict[str, Any]] = []
    for idx in sorted(fragments):
        frag = fragments[idx]
        try:
            args = json.loads(frag["arguments"]) if frag["arguments"] else {}
        except json.JSONDecodeError:
            args = {}
        calls.append(
            {"id": frag["id"] or f"call_{idx}", "name": frag["name"], "arguments": args}
        )
    return [c for c in calls if c["name"]]


async def _stream_once(
    url: str, payload: dict[str, Any], key: str
) -> AsyncGenerator[dict[str, Any], None]:
    """单次流式调用。产出事件：delta / tool_calls / usage（网关返回 usage 时）。"""
    timeout = httpx.Timeout(connect=15.0, read=600.0, write=30.0, pool=30.0)
    fragments: dict[int, dict[str, Any]] = {}
    tool_calls_emitted = False

    async with httpx.AsyncClient(timeout=timeout) as client:
        async with client.stream(
            "POST", url, json=payload, headers=_headers(key)
        ) as resp:
            if resp.status_code >= 400:
                body = (await resp.aread()).decode("utf-8", errors="replace")
                hint = body[:500]
                if resp.status_code >= 500:
                    raise _RetryableError(f"HTTP {resp.status_code}: {hint}")
                raise LLMError(f"网关返回 HTTP {resp.status_code}: {hint}")

            async for line in resp.aiter_lines():
                if not line.startswith("data:"):
                    continue
                data = line[5:].strip()
                if not data:
                    continue
                if data == "[DONE]":
                    break
                try:
                    chunk = json.loads(data)
                except json.JSONDecodeError:
                    continue
                # 计量：部分网关在末尾 chunk 附带 usage（无需 stream_options）
                usage = chunk.get("usage")
                if isinstance(usage, dict) and usage:
                    yield {"type": "usage", "usage": usage}
                choices = chunk.get("choices") or [{}]
                choice = choices[0] if choices else {}
                delta = choice.get("delta") or {}

                content = delta.get("content")
                if content:
                    yield {"type": "delta", "content": content}

                for tc in delta.get("tool_calls") or []:
                    idx = int(tc.get("index") or 0)
                    frag = fragments.setdefault(
                        idx, {"id": "", "name": "", "arguments": ""}
                    )
                    if tc.get("id"):
                        frag["id"] = tc["id"]
                    fn = tc.get("function") or {}
                    if fn.get("name"):
                        frag["name"] += fn["name"]  # 名称也可能分片到达
                    if fn.get("arguments"):
                        frag["arguments"] += fn["arguments"]

                if choice.get("finish_reason") == "tool_calls" and fragments:
                    tool_calls_emitted = True
                    yield {
                        "type": "tool_calls",
                        "tool_calls": _parse_fragments(fragments),
                    }
                    return

    # 部分网关不发 finish_reason=tool_calls，流结束后兜底
    if fragments and not tool_calls_emitted:
        yield {"type": "tool_calls", "tool_calls": _parse_fragments(fragments)}


def _model_chain(c: dict[str, Any]) -> list[str]:
    """主模型 + 可选降级档（fallback_model 与主模型不同时追加，只降一次）。"""
    chain = [c["model"]]
    fb = str(c.get("fallback_model") or "").strip()
    if fb and fb != c["model"]:
        chain.append(fb)
    return chain


async def stream_chat(
    messages: list[dict[str, Any]],
    tools: list[dict[str, Any]] | None = None,
    cfg: dict[str, Any] | None = None,
    role: str = "",
) -> AsyncGenerator[dict[str, Any], None]:
    """带重试（指数退避）与降级链的流式对话。

    产出 delta / tool_calls 事件（usage 仅内部消费不外发）；失败抛 LLMError。
    """
    c = _resolve_cfg(cfg)
    _check_cfg(c)

    base_payload: dict[str, Any] = {
        "messages": messages,
        "stream": True,
        "temperature": c.get("temperature", 0.7),
        "max_tokens": c.get("max_tokens", 8192),
    }
    if tools:
        base_payload["tools"] = tools
        base_payload["tool_choice"] = "auto"

    url = f"{c['base_url']}/chat/completions"
    usage: dict[str, Any] = {}
    start = time.perf_counter()
    last_err: Exception | None = None
    for model in _model_chain(c):
        payload = {**base_payload, "model": model}
        for attempt in range(1 + MAX_RETRIES):
            try:
                async for event in _stream_once(url, payload, c["api_key"]):
                    if event["type"] == "usage":
                        usage = event["usage"]
                    else:
                        yield event
                audit.append(
                    "llm_call", role=role, model=model, stream=True,
                    prompt_tokens=usage.get("prompt_tokens"),
                    completion_tokens=usage.get("completion_tokens"),
                    duration_ms=round((time.perf_counter() - start) * 1000),
                )
                return
            except (_RetryableError, httpx.TransportError) as e:
                last_err = e
                logger.warning("LLM 流式调用失败（model=%s 第 %d 次）: %s", model, attempt + 1, e)
                if attempt < MAX_RETRIES:
                    await asyncio.sleep(RETRY_BACKOFF_S * (2 ** attempt))
    audit.append(
        "llm_call", role=role, model=c["model"], stream=True, is_error=True,
        error=str(last_err), duration_ms=round((time.perf_counter() - start) * 1000),
    )
    raise LLMError(f"网关调用失败（已重试 {MAX_RETRIES} 次）: {last_err}")


async def embed_texts(
    texts: list[str], model: str = "", cfg: dict[str, Any] | None = None
) -> list[list[float]]:
    """批量向量化（POST {base}/embeddings）。返回与输入等长且按 index 排序的向量列表。"""
    c = _resolve_cfg(cfg)
    if not c.get("base_url"):
        raise LLMError("未配置网关地址（config.json → llm.base_url 或 .env → LLM_BASE_URL）")
    if not texts:
        return []
    payload = {"input": texts, "model": model or "embedding"}
    try:
        async with httpx.AsyncClient(timeout=60) as client:
            resp = await client.post(
                f"{c['base_url']}/embeddings", json=payload, headers=_headers(c["api_key"])
            )
            resp.raise_for_status()
            data = resp.json()
    except httpx.HTTPError as e:
        raise LLMError(f"向量化失败：{e}") from e
    items = sorted(data.get("data") or [], key=lambda d: int(d.get("index") or 0))
    vecs = [d.get("embedding") or [] for d in items if isinstance(d, dict)]
    if len(vecs) != len(texts):
        raise LLMError(f"向量化返回条数不符：期望 {len(texts)}，得到 {len(vecs)}")
    return vecs


async def _complete_once(url: str, payload: dict[str, Any], key: str) -> tuple[str, dict[str, Any]]:
    timeout = httpx.Timeout(connect=15.0, read=300.0, write=30.0, pool=30.0)
    async with httpx.AsyncClient(timeout=timeout) as client:
        resp = await client.post(url, json=payload, headers=_headers(key))
        if resp.status_code >= 400:
            hint = resp.text[:500]
            if resp.status_code >= 500:
                raise _RetryableError(f"HTTP {resp.status_code}: {hint}")
            raise LLMError(f"网关返回 HTTP {resp.status_code}: {hint}")
        data = resp.json()
    choices = data.get("choices") or [{}]
    message = (choices[0] if choices else {}).get("message") or {}
    return message.get("content") or "", (data.get("usage") or {})


async def complete_chat(
    messages: list[dict[str, Any]],
    cfg: dict[str, Any] | None = None,
    tools: list[dict[str, Any]] | None = None,
    role: str = "",
) -> str:
    """带重试（指数退避）与降级链的非流式对话（Planner/Evaluator/Memory 等结构化调用用）。"""
    c = _resolve_cfg(cfg)
    _check_cfg(c)
    base_payload: dict[str, Any] = {
        "messages": messages,
        "stream": False,
        "temperature": c.get("temperature", 0.7),
        "max_tokens": c.get("max_tokens", 8192),
    }
    if tools:
        base_payload["tools"] = tools
    url = f"{c['base_url']}/chat/completions"
    start = time.perf_counter()
    last_err: Exception | None = None
    for model in _model_chain(c):
        payload = {**base_payload, "model": model}
        for attempt in range(1 + MAX_RETRIES):
            try:
                content, usage = await _complete_once(url, payload, c["api_key"])
                audit.append(
                    "llm_call", role=role, model=model, stream=False,
                    prompt_tokens=usage.get("prompt_tokens"),
                    completion_tokens=usage.get("completion_tokens"),
                    duration_ms=round((time.perf_counter() - start) * 1000),
                )
                return content
            except (_RetryableError, httpx.TransportError) as e:
                last_err = e
                logger.warning("LLM 非流式调用失败（model=%s 第 %d 次）: %s", model, attempt + 1, e)
                if attempt < MAX_RETRIES:
                    await asyncio.sleep(RETRY_BACKOFF_S * (2 ** attempt))
    audit.append(
        "llm_call", role=role, model=c["model"], stream=False, is_error=True,
        error=str(last_err), duration_ms=round((time.perf_counter() - start) * 1000),
    )
    raise LLMError(f"网关调用失败（已重试 {MAX_RETRIES} 次）: {last_err}")