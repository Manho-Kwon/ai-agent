"""Scheduled Tasks：一次性/周期性任务调度（data/jobs.json + asyncio 1s tick）。

状态机：pending(一次性待执行) / active(周期) → done / cancelled。
触发行为：
- 无 prompt：留痕（记录 last_run_at/run_count）
- 有 prompt：经 task_runner 走真实 LLM 执行通道，结果写回 job.result（后台异步，不阻塞 tick）
边界：重启后过期的一次性任务自动顺延 5s 执行；周期任务间隔下限 5s；
      同任务并发去重（上轮未结束跳过本轮）；单次执行超时保护。
"""
from __future__ import annotations

import asyncio
import json
import logging
import threading
import uuid
from datetime import datetime, timedelta, timezone
from typing import Any

from .config import JOBS_PATH, atomic_write_json

logger = logging.getLogger(__name__)
_lock = threading.Lock()

MAX_DELAY_S = 7 * 24 * 3600
MIN_INTERVAL_S = 5


def _now() -> datetime:
    return datetime.now(timezone.utc).astimezone()


def _iso(dt: datetime) -> str:
    return dt.isoformat(timespec="seconds")


class JobScheduler:
    def __init__(self) -> None:
        self._jobs: dict[str, dict[str, Any]] = {}
        self._task: asyncio.Task | None = None
        self._loaded = False
        self._pending_exec: list[str] = []  # tick 登记的待真实执行 job id

    # --- 持久化 ---

    def _load(self) -> None:
        if self._loaded:
            return
        try:
            data = json.loads(JOBS_PATH.read_text(encoding="utf-8"))
            jobs = data.get("jobs", {})
            self._jobs = {k: v for k, v in jobs.items() if isinstance(v, dict)}
        except (json.JSONDecodeError, OSError):
            self._jobs = {}
        # 重启顺延：过期的一次性 pending 任务 5s 后补跑
        now = _now()
        for job in self._jobs.values():
            if job.get("status") == "pending":
                try:
                    run_at = datetime.fromisoformat(job["run_at"])
                except (KeyError, ValueError):
                    job["status"] = "cancelled"
                    continue
                if run_at < now:
                    job["run_at"] = _iso(now + timedelta(seconds=5))
        self._loaded = True

    def _save(self) -> None:
        atomic_write_json(JOBS_PATH, {"jobs": self._jobs})

    # --- CRUD ---

    def create(
        self,
        title: str,
        note: str = "",
        delay_seconds: float | None = None,
        interval_seconds: float | None = None,
        prompt: str = "",
    ) -> tuple[dict[str, Any] | None, str | None]:
        title = (title or "").strip()
        if not title:
            return None, "任务标题不能为空"
        has_delay = delay_seconds is not None
        has_interval = interval_seconds is not None
        if has_delay == has_interval:
            return None, "delay_seconds 与 interval_seconds 必须二选一"
        now = _now()
        if has_delay:
            try:
                delay = float(delay_seconds)
            except (TypeError, ValueError):
                return None, "delay_seconds 必须为数字"
            if not 1 <= delay <= MAX_DELAY_S:
                return None, f"delay_seconds 需在 1~{MAX_DELAY_S} 之间"
            run_at = now + timedelta(seconds=delay)
            status = "pending"
            interval = None
        else:
            try:
                interval = float(interval_seconds)
            except (TypeError, ValueError):
                return None, "interval_seconds 必须为数字"
            if interval < MIN_INTERVAL_S:
                return None, f"interval_seconds 不能小于 {MIN_INTERVAL_S}"
            run_at = now + timedelta(seconds=interval)
            status = "active"
        job = {
            "id": uuid.uuid4().hex[:8],
            "title": title[:80],
            "note": (note or "")[:500],
            # 有 prompt → 到期后经 task_runner 真实执行；空 = 仅留痕提醒
            "prompt": (prompt or "").strip()[:8000],
            "created_at": _iso(now),
            "run_at": _iso(run_at),
            "interval_seconds": interval,
            "status": status,
            "run_count": 0,
            "last_run_at": None,
            "result": "",
            "last_error": "",
        }
        with _lock:
            self._load()
            self._jobs[job["id"]] = job
            self._save()
        return job, None

    def list(self) -> list[dict[str, Any]]:
        with _lock:
            self._load()
            return sorted(
                (dict(j) for j in self._jobs.values()),
                key=lambda j: j.get("created_at", ""),
                reverse=True,
            )

    def cancel(self, job_id: str) -> bool:
        with _lock:
            self._load()
            job = self._jobs.get(job_id)
            if not job or job["status"] in ("done", "cancelled"):
                return False
            job["status"] = "cancelled"
            self._save()
            return True

    def delete(self, job_id: str) -> bool:
        """彻底移除任务记录（含已 done/cancelled 的留痕），同步落盘。"""
        with _lock:
            self._load()
            if job_id not in self._jobs:
                return False
            del self._jobs[job_id]
            self._save()
            return True

    # --- 调度循环 ---

    async def start(self) -> None:
        self._load()
        if self._task is None or self._task.done():
            self._task = asyncio.create_task(self._loop(), name="job-scheduler")
            logger.info("定时任务调度器已启动（%d 个任务）", len(self._jobs))

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None

    async def _loop(self) -> None:
        while True:
            await asyncio.sleep(1)
            try:
                self._tick()
                await self._dispatch()
            except Exception as e:  # noqa: BLE001 — 调度器自身不能崩
                logger.error("job scheduler tick 异常: %s", e)

    async def _dispatch(self) -> None:
        """把 tick 登记的到期任务投递为后台真实执行（异步上下文调用）。"""
        for job_id in self._pending_exec:
            asyncio.create_task(self._execute_job(job_id), name=f"job-exec-{job_id}")
        self._pending_exec.clear()

    async def _execute_job(self, job_id: str) -> None:
        """后台执行有 prompt 的任务：完整管道 → 结果写回 job。"""
        from . import task_runner

        with _lock:
            job = self._jobs.get(job_id)
            prompt = (job or {}).get("prompt") or ""
            title = (job or {}).get("title") or ""
        if not job or not prompt.strip():
            return
        res = await task_runner.execute_prompt(
            prompt, title=title, dedup_key=f"job:{job_id}"
        )
        with _lock:
            job = self._jobs.get(job_id)
            if job:
                if res["ok"]:
                    job["result"] = res["answer"][:2000]
                    job["last_error"] = ""
                else:
                    job["last_error"] = (res["error"] or res["state"])[:300]
                self._save()
        logger.info(
            "定时任务执行完成: [%s] %s → %s", job_id, title, "success" if res["ok"] else res["state"]
        )

    def _tick(self) -> None:
        now = _now()
        due: list[dict[str, Any]] = []
        with _lock:
            self._load()
            for job in self._jobs.values():
                if job["status"] not in ("pending", "active"):
                    continue
                try:
                    run_at = datetime.fromisoformat(job["run_at"])
                except (KeyError, ValueError):
                    job["status"] = "cancelled"
                    continue
                if run_at <= now:
                    due.append(job)
            if due:
                for job in due:
                    job["run_count"] = int(job.get("run_count", 0)) + 1
                    job["last_run_at"] = _iso(now)
                    if job["status"] == "pending":
                        job["status"] = "done"
                    else:  # active：排下一次
                        interval = float(job.get("interval_seconds") or MIN_INTERVAL_S)
                        job["run_at"] = _iso(now + timedelta(seconds=interval))
                    if (job.get("prompt") or "").strip():
                        self._pending_exec.append(job["id"])
                self._save()
        for job in due:
            logger.info(
                "定时任务触发: [%s] %s（第 %d 次）", job["id"], job["title"], job["run_count"]
            )


job_scheduler = JobScheduler()