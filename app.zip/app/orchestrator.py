"""AgentOrchestrator：Planner→Executor→Evaluator 三角色管道（对齐方案 M1/M2/M3/M4）。

1. 请求分析：Workflow Router 四层路由（fixed 固定工作流零模型调用 / fast / standard / deep）
   + Planner 产出结构化执行计划（步骤绑定工具与验收标准）
2. 执行委派：Executor 工具循环（统一执行网关：参数校验→danger 确认门→超时→审计）
3. 响应传递：Evaluator 两层验收；FAIL → Planner 携反馈修订计划（fail-open 退回执行者返工），
   全局预算 evaluator.max_rework（超限转 paused_human 等人工介入，绝不无限烧 token）

SSE 事件：start / workflow / role_active / plan / step_update / delta / tool_call /
          tool_result / round / confirm_request / eval / done / error / cancelled
          （round = 每个执行轮的字符数与模型耗时，供 UI 展示思考链路的可观测指标）
任务状态机：planning → executing → evaluating →(rework)→ done | paused_human | error | cancelled
取消 = session 级 cancel_event，在流块/工具调用/角色切换之间的安全点退出。
"""
from __future__ import annotations

import asyncio
import json
import logging
import time
from collections.abc import AsyncGenerator
from typing import Any

from . import attachments, audit, evaluator, fixed_flows, planner, prompt_assembler, workflow_router
from .config import load_config
from .llm import LLMError, complete_chat, stream_chat
from .memory_manager import memory_manager
from .model_router import resolve_role
from .session_manager import DEFAULT_TITLE, prepare_thread, session_manager
from .tool_registry import tool_registry

logger = logging.getLogger(__name__)

# 会话级取消事件（chat 路由 cancel 端点触发）
_cancel_events: dict[str, asyncio.Event] = {}
# 会话级 danger 确认门：{session_id: {call_id: {event, approved}}}
_pending_confirms: dict[str, dict[str, dict[str, Any]]] = {}

CONFIRM_TIMEOUT_S = 120.0  # 确认门等待上限，超时视为拒绝


async def _auto_title(session_id: str, user_text: str, answer: str) -> None:
    """用 planner 概括会话标题写回元数据；fail-open，命名失败不影响主流程。"""
    # 触发条件「标题仍是占位默认值」一举保证三件事：只命名一次、不覆盖用户手动改过的名、
    # 概括失败（网关不可达等）下一轮会自动重试
    meta = session_manager.get_session(session_id)
    if not meta or meta.get("title") != DEFAULT_TITLE:
        return
    try:
        raw = await complete_chat(
            [
                {
                    "role": "system",
                    "content": (
                        "你是会话标题生成器。根据用户任务与助手回答，生成一个不超过 16 个字的"
                        "中文短标题，概括这次任务实际做了什么。只输出标题本身，"
                        "不要引号、不要句末标点、不要任何解释。"
                    ),
                },
                {
                    "role": "user",
                    "content": (
                        f"用户任务：{(user_text or '').strip()[:400]}\n\n"
                        f"助手回答：{(answer or '').strip()[:1200]}"
                    ),
                },
            ],
            cfg=resolve_role("planner"),
            role="planner",
        )
    except Exception as e:  # noqa: BLE001 — 概括失败只是少个标题，不许影响回合结果
        logger.info("会话 %s 自动命名跳过（%s）", session_id, e)
        return
    # 先裁首行再剥引号：模型若输出「"标题"\n解释」，反序会让行尾引号夹在串中间剥不掉
    title = raw.split("\n")[0].strip().strip("\"'「」『』").strip()[:24]
    if title:
        session_manager.update_title(session_id, title)


def cancel_turn(session_id: str) -> bool:
    ev = _cancel_events.get(session_id)
    if ev:
        ev.set()
        return True
    return False


def resolve_confirm(session_id: str, call_id: str, approved: bool) -> bool:
    """前端确认/拒绝一个 danger 工具调用（chat 路由 confirm 端点触发）。"""
    pending = _pending_confirms.get(session_id, {}).get(call_id)
    if not pending:
        return False
    pending["approved"] = bool(approved)
    pending["event"].set()
    return True


async def _safe_extract(user_text: str, answer: str) -> None:
    try:
        await memory_manager.auto_extract(user_text, answer)
    except Exception as e:  # noqa: BLE001 — 后台抽取绝不影响主链路
        logger.warning("后台记忆抽取失败: %s", e)


async def _executor_loop(
    thread: list[dict[str, Any]],
    tools: list[dict[str, Any]] | None,
    cancel_ev: asyncio.Event,
    cfg: dict[str, Any],
    max_rounds: int,
    session_id: str,
    holder: dict[str, Any],
    plan: dict[str, Any] | None,
    recovery_cfg: dict[str, Any] | None = None,
) -> AsyncGenerator[dict[str, Any], None]:
    """执行者工具循环。结果写入 holder：final / error / cancelled / tool_trace。

    recovery_cfg = roles.executor_recovery 解析结果：工具连续 2 轮全失败、
    或执行模型直接报错时，切换到恢复执行者模型重试一次（未配置不同模型则无感）。
    plan 非空时按步骤绑定工具发 step_update 事件（计划与执行软绑定）。
    """
    active_cfg = cfg
    switched = False
    consec_err_rounds = 0
    # 挂到 holder 上供 run_turn 落盘：步骤状态属于思考链路，刷新后也要能回看
    step_states: dict[str, str] = holder.setdefault("step_states", {})

    def _can_switch() -> bool:
        """恢复执行者配置了有效的不同模型时切换（仅一次）。"""
        nonlocal active_cfg, switched
        if switched or not recovery_cfg:
            return False
        # 恢复模型未配置（空）时切换无意义：必然二次失败并报"未配置模型名"，
        # 反而掩盖主模型的真实错误（网关 400 / 密钥失效等），故不切换。
        if not recovery_cfg.get("model"):
            return False
        same = (
            recovery_cfg.get("base_url") == active_cfg.get("base_url")
            and recovery_cfg.get("model") == active_cfg.get("model")
        )
        if same:
            return False
        active_cfg = recovery_cfg
        switched = True
        return True

    def _match_step(tool_name: str) -> dict[str, Any] | None:
        """计划中绑定该工具且未开始的步骤。"""
        if not plan:
            return None
        for s in plan.get("steps") or []:
            if isinstance(s, dict) and s.get("tool") == tool_name and step_states.get(s["id"]) is None:
                return s
        return None

    for round_no in range(1, max_rounds + 1):
        if cancel_ev.is_set():
            holder["cancelled"] = True
            return

        round_text = ""
        tool_calls: list[dict[str, Any]] = []
        round_started = time.perf_counter()
        try:
            async for ev in stream_chat(thread, tools=tools, cfg=active_cfg, role="executor"):
                if cancel_ev.is_set():
                    break
                if ev["type"] == "delta":
                    round_text += ev["content"]
                    yield ev
                elif ev["type"] == "tool_calls":
                    tool_calls = ev["tool_calls"]
        except LLMError as e:
            if _can_switch():
                logger.info("会话 %s 执行模型报错（%s），切换恢复执行者", session_id, e)
                yield {"type": "role_active", "role": "executor"}
                continue
            holder["error"] = str(e)
            return
        # 只计模型流式耗时；工具执行时间由 tool_result 的 ms 单独承载，口径不混
        round_ms = round((time.perf_counter() - round_started) * 1000)

        if cancel_ev.is_set():
            if round_text:
                session_manager.append_messages(
                    session_id, [{"role": "assistant", "content": round_text}]
                )
            holder["cancelled"] = True
            return

        if not tool_calls:
            yield {
                "type": "round", "round": round_no, "chars": len(round_text),
                "ms": round_ms, "tool_calls": 0, "final": True,
            }
            holder["final"] = round_text
            return

        # 工具调用轮：assistant(tool_calls) 消息进协议线程
        thread.append({
            "role": "assistant",
            "content": round_text,
            "tool_calls": [
                {
                    "id": c["id"],
                    "type": "function",
                    "function": {
                        "name": c["name"],
                        "arguments": json.dumps(c["arguments"], ensure_ascii=False),
                    },
                }
                for c in tool_calls
            ],
        })

        trace: list[dict[str, Any]] = []
        for c in tool_calls:
            if cancel_ev.is_set():
                break
            server, tool = tool_registry.info(c["name"])
            yield {
                "type": "tool_call",
                "id": c["id"],
                "server": server,
                "tool": tool,
                "arguments": c["arguments"],
            }

            # danger 高危确认门：挂起等人工放行（超时/拒绝 → 不执行）
            # YOLO 模式跳过确认门，直接执行
            cfg = load_config()
            yolo = bool(cfg.get("runtime", {}).get("yolo_mode", False))
            if tool_registry.is_danger(c["name"]) and not yolo:
                call_id = str(c["id"])
                ev_wait = asyncio.Event()
                _pending_confirms.setdefault(session_id, {})[call_id] = {
                    "event": ev_wait, "approved": False,
                }
                yield {
                    "type": "confirm_request",
                    "id": call_id,
                    "server": server,
                    "tool": tool,
                    "arguments": c["arguments"],
                }
                try:
                    await asyncio.wait_for(ev_wait.wait(), timeout=CONFIRM_TIMEOUT_S)
                    approved = bool(_pending_confirms[session_id][call_id]["approved"])
                except asyncio.TimeoutError:
                    approved = False
                finally:
                    _pending_confirms.get(session_id, {}).pop(call_id, None)
                if not approved:
                    result_text = (
                        f"Error: 用户拒绝执行工具 '{tool}'（danger 高危操作需人工确认）"
                    )
                    yield {
                        "type": "tool_result", "id": c["id"], "server": server,
                        "tool": tool, "content": result_text, "is_error": True,
                        "ms": 0,
                    }
                    trace.append({"id": c["id"], "server": server, "tool": tool,
                                  "arguments": c["arguments"], "content": result_text,
                                  "is_error": True, "ms": 0})
                    thread.append({"role": "tool", "tool_call_id": c["id"],
                                   "content": result_text[:8000]})
                    continue

            step = _match_step(c["name"])
            if step:
                step_states[step["id"]] = "running"
                yield {"type": "step_update", "step_id": step["id"], "state": "running"}

            tool_started = time.perf_counter()
            result_text = await tool_registry.call(c["name"], c["arguments"])
            tool_ms = round((time.perf_counter() - tool_started) * 1000)
            is_err = result_text.startswith("Error:")
            yield {
                "type": "tool_result",
                "id": c["id"],
                "server": server,
                "tool": tool,
                "content": result_text,
                "is_error": is_err,
                "ms": tool_ms,
            }
            if step:
                step_states[step["id"]] = "failed" if is_err else "done"
                yield {"type": "step_update", "step_id": step["id"],
                       "state": step_states[step["id"]]}
            trace.append({
                "id": c["id"],
                "server": server,
                "tool": tool,
                "arguments": c["arguments"],
                "content": result_text,
                "is_error": is_err,
                "ms": tool_ms,
            })
            thread.append({
                "role": "tool",
                "tool_call_id": c["id"],
                "content": result_text[:8000],
            })

        holder.setdefault("tool_trace", []).extend(trace)
        # 本轮（含工具痕迹）立即持久化（崩溃/取消不丢已完成的工具痕迹）
        session_manager.append_messages(
            session_id,
            [{"role": "assistant", "content": round_text, "tool_trace": trace}],
        )
        logger.info("会话 %s 第 %d 轮执行了 %d 个工具调用", session_id, round_no, len(trace))
        yield {
            "type": "round", "round": round_no, "chars": len(round_text),
            "ms": round_ms, "tool_calls": len(trace), "final": False,
        }

        # 工具连续 2 轮全部失败 → 切换恢复执行者（配置了不同模型时）
        if trace and all(t["content"].startswith("Error:") for t in trace):
            consec_err_rounds += 1
        else:
            consec_err_rounds = 0
        if consec_err_rounds >= 2 and _can_switch():
            logger.info("会话 %s 工具连续 %d 轮失败，切换恢复执行者", session_id, consec_err_rounds)
            yield {"type": "role_active", "role": "executor"}

    holder["error"] = f"已达工具调用轮次上限（{max_rounds}）"


async def run_turn(
    session_id: str, tier_override: str | None = None
) -> AsyncGenerator[dict[str, Any], None]:
    """编排一个回合。tier_override：定时任务/自动化执行时强制指定工作流层。"""
    cancel_ev = asyncio.Event()
    _cancel_events[session_id] = cancel_ev
    try:
        cfg = load_config()
        msgs = session_manager.get_messages(session_id)
        last_user = ""
        last_atts: list[dict[str, Any]] = []
        for m in reversed(msgs):
            if m.get("role") == "user":
                last_user = m.get("content") or ""
                last_atts = m.get("attachments") or []
                break

        # 1. 请求分析：四层路由（fixed 零模型调用 / fast / standard / deep）
        tier, reason, rule = workflow_router.route(
            last_user, tier_override or cfg["workflow"].get("mode", "auto")
        )
        audit.append("route", session_id=session_id, tier=tier, reason=reason,
                     rule=rule, query=audit.digest(last_user, 120))
        yield {"type": "start"}
        yield {"type": "workflow", "tier": tier, "reason": reason, "rule": rule}

        # 1.5 固定工作流：确定性请求零模型调用直接产出结果
        if tier == "fixed" and rule:
            flow = workflow_router.rule_flow(rule)  # route 回传规则名，执行需 flow 名
            result = await fixed_flows.run_flow(flow, last_user) if flow else None
            if result is not None:
                session_manager.append_messages(
                    session_id, [{"role": "assistant", "content": result}]
                )
                yield {"type": "delta", "content": result}
                await _auto_title(session_id, last_user, result)
                yield {"type": "done", "content": result, "state": "done"}
                return
            tier = "fast"  # 流程执行失败 → 回退直答，管道不中断
            yield {"type": "workflow", "tier": tier, "reason": "固定流程失败回退直答", "rule": None}

        # 附件轮：附件在上传时已解析（含扫描件/图片 OCR）并注入本轮上下文，规划与评估
        # 必须知道这一事实——否则规划器会安排 doc_parse/workspace_* 步骤，而附件不在
        # workspace 内，执行者找不到文件 → 规则层判「声明工具未被调用」→ 返工到预算耗尽。
        plan_query = last_user
        if last_atts:
            names = "、".join(str(a.get("name") or "") for a in last_atts[:8])
            plan_query = (
                f"{last_user}\n\n"
                f"[系统说明] 本轮消息已携带附件：{names}。附件内容（文本/表格/OCR 结果）"
                "已自动解析并注入你的上下文，直接依据注入内容作答即可；计划中不要安排 "
                "doc_parse、workspace_read/list 等读取文件的步骤——附件不在 workspace 内，"
                "调用只会失败。"
            )

        # 规划：结构化计划（步骤绑定注册表内真实工具 + 验收标准）
        plan: dict[str, Any] | None = None
        tools: list[dict[str, Any]] | None = None
        tool_digest = ""
        # 思考链路可观测指标：随最终 assistant 消息落盘，刷新/翻历史仍可回看
        stages: list[dict[str, Any]] = []
        evals_log: list[dict[str, Any]] = []
        if tier != "fast" and not cancel_ev.is_set():
            await tool_registry.rebuild()
            tools = tool_registry.schemas() or None
            tool_digest = tool_registry.digest()
            yield {"type": "role_active", "role": "planner"}
            plan_started = time.perf_counter()
            plan = await planner.make_plan(plan_query, tier, tool_digest)
            plan_ms = round((time.perf_counter() - plan_started) * 1000)
            if plan:
                plan = planner.bind_skills(plan, plan_query)
                yield {
                    "type": "plan", "plan": plan, "ms": plan_ms,
                    "fallback": plan.get("_fallback"),
                }
            stages.append({
                "stage": "planner",
                "ms": plan_ms,
                "fallback": (plan or {}).get("_fallback"),
            })
        if cancel_ev.is_set():
            yield {"type": "cancelled"}
            return

        system_prompt = prompt_assembler.assemble(last_user, tier, session_id, plan)
        thread = prepare_thread(session_id, system_prompt)

        # 附件一次性上下文：仅注入本轮内存 thread 的最后一条 user 消息，不改落库历史，
        # 下一轮 prepare_thread 重建时自然消失。last_user 始终是原始正文（落库、路由、
        # prompt 装配都用它）；只有规划/评估用带附件说明的 plan_query。
        if last_atts:
            block = attachments.build_context_block(session_id, last_atts)
            if block:
                for tm in reversed(thread):
                    if tm.get("role") == "user":
                        tm["content"] = (tm.get("content") or "") + "\n\n" + block
                        break

        max_rounds = int(cfg["llm"].get("max_tool_rounds", 25))
        eval_on = tier != "fast" and cfg["evaluator"].get("enabled", True)
        max_rework = int(cfg["evaluator"].get("max_rework", 3)) if eval_on else 0

        # 2. 执行委派 + 3. 响应传递（FAIL → 修订/返工闭环，预算耗尽转人工）
        answer = ""
        attempt = 0
        paused = False
        last_verdict: dict[str, Any] | None = None
        last_step_states: dict[str, str] = {}
        while True:
            yield {"type": "role_active", "role": "executor"}
            holder: dict[str, Any] = {"final": "", "error": None, "cancelled": False}
            async for ev in _executor_loop(
                thread, tools, cancel_ev, resolve_role("executor"),
                max_rounds, session_id, holder, plan,
                recovery_cfg=resolve_role("executor_recovery"),
            ):
                if ev.get("type") == "round":
                    stages.append({"stage": "executor", **{
                        k: ev[k] for k in ("round", "chars", "ms", "tool_calls", "final")
                        if k in ev
                    }})
                yield ev
            if holder["error"]:
                yield {"type": "error", "message": holder["error"]}
                return
            if holder["cancelled"]:
                yield {"type": "cancelled"}
                return
            answer = holder["final"]
            last_step_states = holder.get("step_states") or {}

            if not eval_on:
                break
            if cancel_ev.is_set():
                yield {"type": "cancelled"}
                return
            yield {"type": "role_active", "role": "evaluator"}
            eval_started = time.perf_counter()
            verdict = await evaluator.evaluate(
                plan_query, plan, answer, tool_trace=holder.get("tool_trace"),
                session_id=session_id,
            )
            eval_ms = round((time.perf_counter() - eval_started) * 1000)
            attempt += 1
            last_verdict = verdict
            eval_entry = {
                "passed": verdict["passed"],
                "feedback": verdict["feedback"],
                "attempt": attempt,
                "score": verdict.get("score"),
                "failures": verdict.get("failures") or [],
                # fallback 非空 = 这次「通过」是 fail-open 放行，不是真实评估结论
                "fallback": verdict.get("fallback"),
                "ms": eval_ms,
            }
            evals_log.append(eval_entry)
            stages.append({
                "stage": "evaluator", "attempt": attempt, "ms": eval_ms,
                "fallback": verdict.get("fallback"),
            })
            yield {"type": "eval", **eval_entry}
            if verdict["passed"]:
                break
            if attempt > max_rework:
                paused = True  # 全局评估预算耗尽 → 转人工，绝不无限烧 token
                break

            # FAIL → Planner 携反馈修订计划（fail-open：修订失败退回执行者返工）
            revised = None
            if plan:
                yield {"type": "role_active", "role": "planner"}
                revise_started = time.perf_counter()
                revised = await planner.revise_plan(plan_query, plan, verdict["feedback"], tool_digest)
                revise_ms = round((time.perf_counter() - revise_started) * 1000)
                if revised:
                    plan = planner.bind_skills(revised, plan_query)
                    yield {
                        "type": "plan", "plan": plan, "ms": revise_ms,
                        "fallback": plan.get("_fallback"), "revised": True,
                    }
                stages.append({
                    "stage": "planner",
                    "revised": True,
                    "ms": revise_ms,
                    "fallback": (plan or {}).get("_fallback"),
                })
            if revised is None:
                thread.append({
                    "role": "user",
                    "content": (
                        f"[评估者反馈] 验收未通过：{verdict['feedback']} "
                        "请修正并重新给出完整最终答案（直接输出答案，不要解释过程）。"
                    ),
                })

        answer = answer or "（空回复）"
        # 思考链路随最终答案落盘，刷新页面/翻历史消息后仍可回看。
        # meta 不会进 LLM 上下文：session_manager._expand_tool_trace 只挑
        # role/content/tool_trace 重建协议消息，其余键一律不带入请求体。
        meta = {
            "tier": tier,
            "plan": plan,
            "evals": evals_log,
            "stages": stages,
            "step_states": last_step_states,
            "state": "paused_human" if paused else "done",
        }
        session_manager.append_messages(
            session_id, [{"role": "assistant", "content": answer, "meta": meta}]
        )
        await _auto_title(session_id, last_user, answer)
        if paused:
            yield {
                "type": "done",
                "content": answer,
                "state": "paused_human",
                "feedback": (last_verdict or {}).get("feedback", ""),
                "failures": (last_verdict or {}).get("failures") or [],
                "meta": meta,
            }
            return  # 失败经验进审计不进记忆（蒸馏有门槛）
        yield {"type": "done", "content": answer, "state": "done", "meta": meta}

        # 回合后后台记忆抽取（fail-open；仅真实通过验收的任务才有资格沉淀）。
        # 评估器失效时 verdict.fallback 非空——那种「通过」只是放行，回答未经验收，
        # 蒸馏进长期记忆会随每轮 prompt 回注把污染扩散到后续所有对话，故在此拦住。
        # fast 层不走评估（eval_on=False），不属于评估失效，照常抽取。
        mem_cfg = cfg["memory"]
        eval_degraded = bool(eval_on and (last_verdict or {}).get("fallback"))
        if eval_degraded:
            logger.info(
                "会话 %s 评估者未实际工作（%s），跳过记忆抽取以免污染长期记忆",
                session_id, (last_verdict or {}).get("fallback"),
            )
        elif mem_cfg.get("enabled", True) and mem_cfg.get("auto_extract", True):
            asyncio.create_task(
                _safe_extract(last_user, answer), name=f"mem-extract-{session_id}"
            )
    finally:
        _cancel_events.pop(session_id, None)
