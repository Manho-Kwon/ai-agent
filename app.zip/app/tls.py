"""OS 信任链注入（对齐原版 core/tls.py）。

公司内网 HTTPS 经代理拦截（自签证书链）：Python 默认只信 certifi，
浏览器能过而 Python 报 CERTIFICATE_VERIFY_FAILED。truststore 把 TLS
验证委托给 OS 信任存储（pip 同款做法）。注入失败静默回退，不阻塞启动。
"""
from __future__ import annotations

import logging
import os

logger = logging.getLogger(__name__)

_done = False


def setup_os_trust() -> None:
    """幂等：进程启动时调用一次。WB_DISABLE_TRUSTSTORE=1 可关闭。"""
    global _done
    if _done:
        return
    _done = True

    if os.getenv("WB_DISABLE_TRUSTSTORE"):
        logger.info("WB_DISABLE_TRUSTSTORE 已设置 —— 跳过 OS 信任注入")
        return

    try:
        import truststore

        truststore.inject_into_ssl()
        logger.info("truststore: OS 信任链已注入（内网代理自签 CA 可信）")
    except Exception as e:  # noqa: BLE001 — 注入失败回退 certifi 即可
        logger.warning("truststore 注入失败，回退 certifi 默认信任: %s", e)
