"""MCP 客户端管理器（对齐原版 core/mcp_manager.py + mcp_stdio_runtime.py 裁剪版）。

- stdio 传输：官方 mcp SDK stdio_client + AsyncExitStack 常驻 owner task
  （ready Future 等 initialize、stop_event 控制关闭 —— 原版同款模式）
- npx 注入 npm_config_cache 缓存隔离（data/cache/mcp/<slug>/npm）
- 连接超时 30s；失败置 ERROR 并附 stderr 摘要（env 值打码）
- 工具目录缓存 TTL 5min；OpenAI function 格式；命名空间 server__tool
- 断线自愈：调用中检测连接丢失 → 重连一次
- 热重载：diff added/changed/removed，重连变更者
"""
from __future__ import annotations

import asyncio
import contextlib
import hashlib
import json
import logging
import re
import shutil
import threading
import time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any

from mcp import ClientSession, StdioServerParameters, types
from mcp.client.stdio import stdio_client

from .config import MCP_CACHE_DIR, MCP_CONFIG_PATH

logger = logging.getLogger(__name__)

CONNECT_TIMEOUT_S = 30.0
CLEANUP_TIMEOUT_S = 5.0
TOOL_CACHE_TTL_S = 300.0
TOOL_TIMEOUT_S = 120.0


@dataclass
class StdioLaunch:
    command: str
    args: list[str]
    env: dict[str, str] | None
    runner: str | None  # "npx" | "uvx" | None


def _runner_name(command: str) -> str | None:
    exe = re.split(r"[\\/]", command)[-1].casefold()
    if exe in {"npx", "npx.cmd", "npx.exe"}:
        return "npx"
    if exe in {"uvx", "uvx.exe"}:
        return "uvx"
    return None


def _server_cache_root(server_name: str) -> Any:
    slug = re.sub(r"[^a-z0-9._-]+", "-", server_name.casefold()).strip("-.") or "server"
    slug = slug[:40]
    digest = hashlib.sha256(server_name.encode()).hexdigest()[:10]
    return MCP_CACHE_DIR / f"{slug}-{digest}"


def prepare_stdio_launch(server_name: str, config: dict[str, Any]) -> StdioLaunch:
    """stdio 启动准备：npx/uvx 运行时缓存隔离（原版同款）。"""
    command = config.get("command") or ""
    args = list(config.get("args") or [])
    env = dict(config.get("env") or {})
    runner = _runner_name(command)

    if runner == "npx" and "npm_config_cache" not in {k.casefold() for k in env}:
        env["npm_config_cache"] = str(_server_cache_root(server_name) / "npm")
    elif runner == "uvx" and "UV_CACHE_DIR" not in {k.casefold() for k in env}:
        env["UV_CACHE_DIR"] = str(_server_cache_root(server_name) / "uv")

    return StdioLaunch(command=command, args=args, env=env or None, runner=runner)


class _StderrCapture:
    """捕获子进程 stderr 尾部，用于连接失败诊断（简化版原版 MCPStderrCapture）。"""

    def __init__(self, max_bytes: int = 8192) -> None:
        import os

        read_fd, write_fd = os.pipe()
        self.stream = os.fdopen(write_fd, "wb", buffering=0)
        self._read_fd = read_fd
        self._max = max_bytes
        self._buf = bytearray()
        self._lock = threading.Lock()
        self._closed = False
        self._thread = threading.Thread(target=self._drain, daemon=True)
        self._thread.start()

    def _drain(self) -> None:
        import os

        with os.fdopen(self._read_fd, "rb", buffering=0) as reader:
            while chunk := reader.read(4096):
                with self._lock:
                    self._buf.extend(chunk)
                    if len(self._buf) > self._max:
                        del self._buf[: len(self._buf) - self._max]

    def tail(self) -> str:
        with self._lock:
            return bytes(self._buf).decode("utf-8", errors="replace").strip()

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        with contextlib.suppress(OSError):
            self.stream.close()
        self._thread.join(timeout=1)


def redact(message: str, config: dict[str, Any]) -> str:
    """错误信息中打码 env 敏感值（原版同款）。"""
    values = sorted(
        {v for v in (config.get("env") or {}).values() if v},
        key=len,
        reverse=True,
    )
    for v in values:
        message = message.replace(v, "***")
    return message


class MCPClientManager:
    def __init__(self) -> None:
        self._configs: dict[str, dict[str, Any]] = {}
        # name -> (owner_task, stop_event, session, exit_stack)
        self._connections: dict[str, dict[str, Any]] = {}
        self._statuses: dict[str, str] = {}  # connecting|connected|disconnected|error
        self._errors: dict[str, str] = {}
        self._connected_at: dict[str, str | None] = {}
        self._tool_cache: dict[str, tuple[float, list[dict[str, Any]]]] = {}
        self._lifecycle_locks: dict[str, asyncio.Lock] = {}

    # --- 配置 ---

    def load_config(self) -> None:
        """读取 mcp.json。损坏不崩服务：空配置启动 + 记录原因（原版原则）。"""
        try:
            data = json.loads(MCP_CONFIG_PATH.read_text(encoding="utf-8"))
            servers = data.get("mcpServers", {})
            if not isinstance(servers, dict):
                raise ValueError("mcpServers must be an object")
            self._configs = {name: dict(cfg) for name, cfg in servers.items()}
            import app.config as cfg_mod

            cfg_mod.mcp_config_error = None
            logger.info("已加载 %d 个 MCP 服务器配置", len(self._configs))
        except (json.JSONDecodeError, OSError, ValueError) as e:
            import app.config as cfg_mod

            cfg_mod.mcp_config_error = str(e)
            self._configs = {}
            logger.error("mcp.json 解析失败，空配置启动（原文件未改动）: %s", e)

    def _save_config(self) -> None:
        MCP_CONFIG_PATH.write_text(
            json.dumps({"mcpServers": self._configs}, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )

    # --- 连接生命周期（owner-task 模式，原版同款） ---

    async def _run_owner(
        self,
        server_name: str,
        config: dict[str, Any],
        launch: StdioLaunch,
        ready: asyncio.Future,
        stop_event: asyncio.Event,
    ) -> None:
        stderr_capture: _StderrCapture | None = None
        try:
            async with contextlib.AsyncExitStack() as stack:
                stderr_capture = _StderrCapture()
                stack.callback(stderr_capture.close)
                params = StdioServerParameters(
                    command=launch.command,
                    args=launch.args,
                    env=launch.env,
                )
                read_stream, write_stream = await stack.enter_async_context(
                    stdio_client(params, errlog=stderr_capture.stream)
                )
                session = await stack.enter_async_context(
                    ClientSession(read_stream, write_stream)
                )
                await session.initialize()
                if not ready.done():
                    ready.set_result((session, stack))
                await stop_event.wait()
        except asyncio.CancelledError:
            if not ready.done():
                ready.cancel()
            raise
        except Exception as exc:
            stderr = stderr_capture.tail() if stderr_capture else ""
            if not ready.done():
                ready.set_exception((exc, stderr))
                return
            self._statuses[server_name] = "error"
            self._errors[server_name] = redact(str(exc) or type(exc).__name__, config)
            logger.error("MCP owner task 异常退出 '%s': %s", server_name, exc)

    async def connect_server(self, server_name: str) -> None:
        lock = self._lifecycle_locks.setdefault(server_name, asyncio.Lock())
        async with lock:
            await self._connect_unlocked(server_name)

    async def _connect_unlocked(self, server_name: str) -> None:
        if server_name not in self._configs:
            raise ValueError(f"MCP 服务器 '{server_name}' 不在配置中")
        config = self._configs[server_name]
        if not config.get("enabled", True):
            self._statuses[server_name] = "disconnected"
            return
        if server_name in self._connections:
            await self._disconnect_unlocked(server_name)

        self._statuses[server_name] = "connecting"
        self._errors[server_name] = ""
        try:
            if config.get("transport", "stdio") != "stdio":
                raise ValueError("当前版本仅支持 stdio 传输")
            if not config.get("command"):
                raise ValueError("stdio 传输需要 command 字段")
            launch = prepare_stdio_launch(server_name, config)
            if not shutil.which(launch.command):
                raise ValueError(f"PATH 中找不到命令: '{launch.command}'")

            loop = asyncio.get_running_loop()
            ready: asyncio.Future = loop.create_future()
            stop_event = asyncio.Event()
            task = asyncio.create_task(
                self._run_owner(server_name, config, launch, ready, stop_event),
                name=f"mcp-owner-{server_name}",
            )
            try:
                session, stack = await asyncio.wait_for(ready, CONNECT_TIMEOUT_S)
            except BaseException:
                if not task.done():
                    task.cancel()
                    with contextlib.suppress(BaseException):
                        await task
                raise

            self._connections[server_name] = {
                "task": task,
                "stop_event": stop_event,
                "session": session,
                "stack": stack,
            }
            self._statuses[server_name] = "connected"
            self._connected_at[server_name] = datetime.now(timezone.utc).isoformat()
            self._tool_cache.pop(server_name, None)
            logger.info("已连接 MCP 服务器: %s", server_name)
        except BaseException as exc:  # noqa: BLE001 — 统一转状态，不让启动崩
            cause, stderr = (exc if isinstance(exc, tuple) else (exc, ""))
            if isinstance(exc, asyncio.TimeoutError):
                base_err = f"连接超时（{CONNECT_TIMEOUT_S:g}s）"
            else:
                base_err = str(cause).strip() or type(cause).__name__
            message = f"{base_err}\n{stderr}" if stderr else base_err
            self._statuses[server_name] = "error"
            self._errors[server_name] = redact(message, config)
            logger.error("连接 MCP 服务器失败 '%s': %s", server_name, message)

    async def _disconnect_unlocked(self, server_name: str) -> None:
        conn = self._connections.pop(server_name, None)
        if conn:
            conn["stop_event"].set()
            try:
                await asyncio.wait_for(conn["task"], CLEANUP_TIMEOUT_S)
            except (asyncio.TimeoutError, asyncio.CancelledError):
                logger.debug("'%s' 清理超时，强制继续", server_name)
                if not conn["task"].done():
                    conn["task"].cancel()
            except BaseException as e:  # noqa: BLE001 — anyio cancel scope 噪音忽略
                logger.debug("'%s' 关闭异常（忽略）: %s", server_name, e)
        self._statuses[server_name] = "disconnected"
        self._connected_at[server_name] = None
        self._tool_cache.pop(server_name, None)
        logger.info("已断开 MCP 服务器: %s", server_name)

    async def disconnect_server(self, server_name: str) -> None:
        lock = self._lifecycle_locks.setdefault(server_name, asyncio.Lock())
        async with lock:
            await self._disconnect_unlocked(server_name)

    async def connect_all(self) -> None:
        for name, cfg in self._configs.items():
            if cfg.get("enabled", True):
                try:
                    await self.connect_server(name)
                except Exception as e:  # noqa: BLE001
                    logger.error("连接 MCP 服务器异常 '%s': %s", name, e)

    async def disconnect_all(self) -> None:
        for name in list(self._connections):
            with contextlib.suppress(Exception):
                await self.disconnect_server(name)

    async def reload_config(self) -> dict[str, Any]:
        """热重载：diff 变更，重连需要重连的，不动健康连接（原版原则）。"""
        old = dict(self._configs)
        self.load_config()
        added = [n for n in self._configs if n not in old]
        removed = [n for n in old if n not in self._configs]
        changed = [
            n
            for n, c in self._configs.items()
            if n in old and old[n] != c
        ]
        for name in removed:
            await self.disconnect_server(name)
            self._statuses.pop(name, None)
            self._errors.pop(name, None)
            self._connected_at.pop(name, None)
        for name in changed:
            await self.connect_server(name)
        # 未变但不健康 → 重试（reload 兼作恢复动作）
        retried = []
        for name, cfg in self._configs.items():
            if name in changed or name in removed or not cfg.get("enabled", True):
                continue
            if self._statuses.get(name) != "connected":
                retried.append(name)
                await self.connect_server(name)
        failed = [
            n
            for n, c in self._configs.items()
            if c.get("enabled", True) and self._statuses.get(n) == "error"
        ]
        return {
            "servers": len(self._configs),
            "added": added,
            "changed": changed,
            "removed": removed,
            "retried": retried,
            "failed": failed,
        }

    # --- 工具目录 ---

    def _format_tools(self, server_name: str, tools: list) -> list[dict[str, Any]]:
        """MCP 工具 → OpenAI function 格式，命名空间 server__tool（原版同款）。"""
        formatted: list[dict[str, Any]] = []
        for tool in tools:
            parameters = tool.input_schema or {"type": "object", "properties": {}}
            formatted.append(
                {
                    "type": "function",
                    "function": {
                        "name": f"{server_name}__{tool.name}",
                        "description": tool.description or "",
                        "parameters": parameters,
                    },
                }
            )
        return formatted

    async def _fetch_server_tools(self, server_name: str) -> list[dict[str, Any]]:
        now = time.monotonic()
        cached = self._tool_cache.get(server_name)
        if cached and (now - cached[0]) < TOOL_CACHE_TTL_S:
            return cached[1]
        conn = self._connections.get(server_name)
        if not conn:
            return []
        try:
            result = await conn["session"].list_tools()
            formatted = self._format_tools(server_name, result.tools)
            self._tool_cache[server_name] = (now, formatted)
            return formatted
        except Exception as e:  # noqa: BLE001
            reason = redact(str(e) or type(e).__name__, self._configs.get(server_name, {}))
            logger.error("获取工具列表失败 '%s': %s", server_name, reason)
            if self._is_connection_lost(e):
                await self._recover(server_name)
            return list(cached[1]) if cached else []

    @staticmethod
    def _is_connection_lost(exc: Exception) -> bool:
        msg = str(exc).casefold()
        return any(
            m in msg
            for m in ("connection closed", "closed resource", "broken resource", "end of stream")
        )

    async def _recover(self, server_name: str) -> bool:
        """断线自愈：重连一次（原版同款）。"""
        logger.info("尝试重连 MCP 服务器 '%s' ...", server_name)
        await self._disconnect_unlocked(server_name)
        await self._connect_unlocked(server_name)
        return self._statuses.get(server_name) == "connected"

    async def get_all_tools(self) -> list[dict[str, Any]]:
        names = list(self._connections.keys())
        if not names:
            return []
        results = await asyncio.gather(*(self._fetch_server_tools(n) for n in names))
        return [t for tools in results for t in tools]

    async def get_server_tools(self, server_name: str) -> list[dict[str, Any]]:
        return await self._fetch_server_tools(server_name)

    # --- 工具调用 ---

    async def call_tool(self, server_name: str, tool_name: str, arguments: dict) -> str:
        conn = self._connections.get(server_name)
        if not conn:
            return f"Error: MCP 服务器 '{server_name}' 未连接"
        session = conn["session"]
        try:
            sanitized = json.loads(json.dumps(arguments))  # 参数消毒（原版同款）
            result = await asyncio.wait_for(
                session.call_tool(tool_name, arguments=sanitized), TOOL_TIMEOUT_S
            )
        except asyncio.TimeoutError:
            return f"Error: MCP 工具 '{tool_name}' 超时（{TOOL_TIMEOUT_S:g}s）"
        except Exception as e:  # noqa: BLE001
            safe = redact(str(e) or type(e).__name__, self._configs.get(server_name, {}))
            if self._is_connection_lost(e):
                recovered = await self._recover(server_name)
                if recovered:
                    return "Error: 连接中断已重连，请重试工具调用"
            return f"Error: 调用工具 '{tool_name}' 失败: {safe}"

        texts: list[str] = []
        for content in result.content:
            if isinstance(content, types.TextContent):
                texts.append(content.text)
            elif isinstance(content, types.ImageContent):
                texts.append(f"[图片: {content.mimeType}]")
            elif isinstance(content, types.EmbeddedResource):
                texts.append(f"[资源: {content.resource.uri}]")
            else:
                texts.append(str(content))
        output = "\n".join(texts) if texts else "工具执行成功（无输出）"
        if result.is_error:
            return f"Error: MCP 工具 '{tool_name}' 执行失败: {output}"
        return output

    # --- 状态 ---

    def get_all_server_statuses(self) -> list[dict[str, Any]]:
        out = []
        for name, cfg in self._configs.items():
            out.append(
                {
                    "name": name,
                    "transport": cfg.get("transport", "stdio"),
                    "command": cfg.get("command"),
                    "args": cfg.get("args") or [],
                    "enabled": cfg.get("enabled", True),
                    "status": self._statuses.get(name, "disconnected"),
                    "error": self._errors.get(name) or None,
                    "connected_at": self._connected_at.get(name),
                }
            )
        return out


mcp_manager = MCPClientManager()
