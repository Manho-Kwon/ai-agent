"""对话流式路由（SSE typed 事件 + 5s 心跳 + 取消）。

事件流由 app.orchestrator.run_turn 驱动（Planner→Executor→Evaluator 管道）。
注意：不能用 wait_for 包住异步生成器的 __anext__（超时取消会弄坏生成器状态，
导致 error 事件丢失）——这里用「生产者 task + 队列」解耦心跳与事件消费。
"""
from __future__ import annotations

import asyncio
import base64
import binascii
import contextlib
import json
import mimetypes

from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel

from .. import attachments, orchestrator
from ..session_manager import session_manager

router = APIRouter(prefix="/api/chat", tags=["chat"])

HEARTBEAT_S = 5.0


class ChatReq(BaseModel):
    session_id: str
    content: str
    attachment_ids: list[str] = []


class ChatUploadReq(BaseModel):
    session_id: str
    file_name: str
    content_b64: str


class CancelReq(BaseModel):
    session_id: str


class ConfirmReq(BaseModel):
    session_id: str
    call_id: str
    approved: bool


def _sse(event: dict) -> str:
    return f"data: {json.dumps(event, ensure_ascii=False)}\n\n"


@router.post("/stream")
async def chat_stream(req: ChatReq):
    if not session_manager.get_session(req.session_id):
        raise HTTPException(404, "会话不存在")
    content = req.content.strip()
    att_ids = req.attachment_ids
    if len(att_ids) > 8:
        raise HTTPException(400, f"单条消息最多携带 8 个附件，当前 {len(att_ids)} 个")
    if not content and not att_ids:
        raise HTTPException(400, "消息内容为空")
    metas: list[dict] = []
    if att_ids:
        try:
            metas = attachments.load_metas(req.session_id, att_ids)
        except ValueError as e:
            raise HTTPException(400, str(e))
    user_msg: dict = {"role": "user", "content": content}
    if metas:
        user_msg["attachments"] = metas
    session_manager.append_messages(req.session_id, [user_msg])

    async def gen():
        queue: asyncio.Queue = asyncio.Queue()
        sentinel = object()

        async def producer():
            try:
                async for ev in orchestrator.run_turn(req.session_id):
                    await queue.put(ev)
            except asyncio.CancelledError:
                raise
            except Exception as e:  # noqa: BLE001 — 兜底：错误以事件形式送达前端
                await queue.put({"type": "error", "message": str(e)})
            finally:
                await queue.put(sentinel)

        task = asyncio.create_task(producer(), name=f"chat-{req.session_id}")
        try:
            while True:
                try:
                    ev = await asyncio.wait_for(queue.get(), timeout=HEARTBEAT_S)
                except asyncio.TimeoutError:
                    yield ": heartbeat\n\n"  # SSE 注释行：保活不触发前端事件
                    continue
                if ev is sentinel:
                    break
                yield _sse(ev)
        finally:
            task.cancel()
            with contextlib.suppress(BaseException):
                await task

    return StreamingResponse(
        gen(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


@router.post("/upload")
async def chat_upload(req: ChatUploadReq):
    """上传聊天附件：base64 解码 → 落盘 → 按格式解析（线程池 + 20s 超时，fail-open）。"""
    if not session_manager.get_session(req.session_id):
        raise HTTPException(404, "会话不存在")
    try:
        raw = base64.b64decode(req.content_b64 or "", validate=True)
    except (binascii.Error, ValueError):
        raise HTTPException(400, "文件数据损坏，请重新选择文件")
    try:
        meta = await asyncio.wait_for(
            asyncio.to_thread(
                attachments.save_upload, req.session_id, req.file_name, raw
            ),
            timeout=20.0,
        )
    except ValueError as e:
        raise HTTPException(400, str(e))
    except asyncio.TimeoutError:
        raise HTTPException(400, "文件解析超时（20s），请尝试更小或更简单的文件")
    return meta


@router.get("/attachments/{session_id}/{att_id}/file")
async def chat_attachment_file(session_id: str, att_id: str):
    """附件原文件：仅图片 inline 预览，其余强制下载（杜绝同源渲染执行面）。"""
    try:
        path, meta = attachments.resolve_file(session_id, att_id)
    except ValueError as e:
        raise HTTPException(404, str(e))
    name = meta.get("name", "file")
    media_type = mimetypes.guess_type(name)[0] or "application/octet-stream"
    headers = None
    if meta.get("kind") != "image":
        from urllib.parse import quote
        headers = {
            "Content-Disposition": f"attachment; filename*=UTF-8''{quote(name)}"
        }
    return FileResponse(path, media_type=media_type, headers=headers)


@router.post("/cancel")
async def chat_cancel(req: CancelReq):
    return {"ok": orchestrator.cancel_turn(req.session_id)}


@router.post("/confirm")
async def chat_confirm(req: ConfirmReq):
    """danger 高危工具确认门：前端弹窗结果回传（approved=false 或超时 = 拒绝执行）。"""
    ok = orchestrator.resolve_confirm(req.session_id, req.call_id, req.approved)
    if not ok:
        raise HTTPException(404, "确认请求不存在或已超时")
    return {"ok": True}