"""RAG 知识库路由：索引状态 / 强制重建 / 检索调试 / 带引用问答。

- GET  /api/rag/status   索引状态（chunk 数 / embed 模型 / 构建时间 / 启用开关）
- POST /api/rag/reindex  强制重建索引（资料库页面全文 → 分块 → BM25+向量）
- GET  /api/rag/search   混合检索调试（q 必填，k 可选）
- POST /api/rag/answer   带引用问答（低于拒答阈值返回 refused=true）
"""
from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel

from ..rag import rag_engine

router = APIRouter(prefix="/api/rag", tags=["rag"])


class AnswerReq(BaseModel):
    query: str


@router.get("/status")
async def status():
    return rag_engine.status()


@router.post("/reindex")
async def reindex():
    return await rag_engine.reindex()


@router.get("/search")
async def search(q: str = Query(..., min_length=1), k: int = Query(0, ge=0)):
    return await rag_engine.search(q, k=k)


@router.post("/answer")
async def answer(req: AnswerReq):
    if not req.query.strip():
        raise HTTPException(status_code=400, detail="query 不能为空")
    return await rag_engine.answer(req.query.strip())
