"""自动化路由：任务 CRUD / 启停 / 手动运行 / 批量操作 / 运行记录。"""
from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from ..automation_manager import automation_manager

router = APIRouter(prefix="/api/automations", tags=["automations"])


class ScheduleReq(BaseModel):
    type: str = "once"
    run_at: str | None = None
    time: str | None = None
    weekday: int | None = None


class ValidityReq(BaseModel):
    type: str = "permanent"
    end: str | None = None


class AutomationReq(BaseModel):
    name: str
    prompt: str
    model_tier: str = "balanced"
    workspace_id: str = ""
    workspace_name: str = ""
    access: str = "full"
    schedule: ScheduleReq
    validity: ValidityReq = ValidityReq()
    push_wechat: bool = False
    push_wecom: bool = False
    status: str = "active"


class ToggleReq(BaseModel):
    active: bool


class BatchReq(BaseModel):
    action: str  # pause | resume | delete
    ids: list[str]


@router.get("")
async def au_list():
    return {
        "automations": automation_manager.list(),
        "runs": automation_manager.runs(),
    }


@router.post("")
async def au_create(req: AutomationReq):
    fields = req.model_dump()
    status = fields.pop("status", "active")
    try:
        return automation_manager.create(fields, status=status)
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.patch("/{aid}")
async def au_update(aid: str, req: AutomationReq):
    fields = req.model_dump()
    fields.pop("status", None)
    try:
        rec = automation_manager.update(aid, fields)
    except ValueError as e:
        raise HTTPException(400, str(e))
    if rec is None:
        raise HTTPException(404, "自动化任务不存在")
    return rec


@router.post("/{aid}/toggle")
async def au_toggle(aid: str, req: ToggleReq):
    rec = automation_manager.set_status(aid, req.active)
    if rec is None:
        raise HTTPException(404, "自动化任务不存在")
    return rec


@router.post("/{aid}/run")
async def au_run(aid: str):
    run = automation_manager.trigger(aid, trigger="manual")
    if run is None:
        raise HTTPException(404, "自动化任务不存在")
    await automation_manager.dispatch_pending()  # 立即投递后台执行
    return run


@router.delete("/{aid}")
async def au_delete(aid: str):
    if not automation_manager.delete(aid):
        raise HTTPException(404, "自动化任务不存在")
    return {"ok": True}


@router.post("/batch")
async def au_batch(req: BatchReq):
    try:
        return automation_manager.batch(req.action, req.ids)
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.post("/runs/clear")
async def au_clear_runs():
    return automation_manager.clear_runs()
