"""扩展域路由：memories / skills / pages / jobs / pipeline（架构图各 Manager 的 REST 面）。"""
from __future__ import annotations

import base64
import binascii
import re

import httpx
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from ..config import load_config
from ..job_scheduler import job_scheduler
from ..memory_manager import memory_manager
from ..model_router import describe as role_describe
from ..page_manager import page_manager
from ..skill_manager import get_skill, list_skills

router = APIRouter(prefix="/api", tags=["extras"])


# --- memories ---

class MemoryAddReq(BaseModel):
    content: str
    tags: list[str] = []


@router.get("/memories")
async def memories_list():
    return {"memories": memory_manager.list()}


@router.post("/memories")
async def memories_add(req: MemoryAddReq):
    try:
        return memory_manager.add(req.content, tags=req.tags, source="manual")
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.delete("/memories/{memory_id}")
async def memories_delete(memory_id: str):
    if not memory_manager.delete(memory_id):
        raise HTTPException(404, "记忆不存在")
    return {"ok": True}


# --- skills ---

class SkillCreateReq(BaseModel):
    name: str
    description: str
    body: str = ""


class SkillEnabledReq(BaseModel):
    enabled: bool


@router.get("/skills")
async def skills_list():
    return {"skills": list_skills()}


@router.post("/skills/reload")
async def skills_reload():
    """重扫技能目录（技能卡每次请求都现读，这里返回数量供 UI 反馈）。"""
    from ..skill_manager import reload_skills

    return {"ok": True, "count": reload_skills()}


@router.post("/skills")
async def skills_create(req: SkillCreateReq):
    from ..skill_manager import create_skill

    try:
        return create_skill(req.name, req.description, req.body)
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.post("/skills/{name}/enabled")
async def skills_enabled(name: str, req: SkillEnabledReq):
    from ..skill_manager import set_enabled

    rec = set_enabled(name, req.enabled)
    if rec is None:
        raise HTTPException(404, "技能不存在")
    return rec


@router.get("/skills/{name}")
async def skills_get(name: str):
    # 管理界面需要能查看已禁用的技能卡，否则关闭后无法再打开重新启用
    skill = get_skill(name, include_disabled=True)
    if not skill:
        raise HTTPException(404, "技能不存在")
    return skill


# --- pages（资料库：页面 / 文件夹 / 书签 / 上传 / 路径导入 / 托管导入） ---

class PageCreateReq(BaseModel):
    title: str = ""
    content: str = ""
    description: str = ""
    kind: str = "page"          # page | folder | bookmark
    url: str = ""
    parent_id: str = ""


class PageUploadReq(BaseModel):
    title: str = ""
    description: str = ""
    parent_id: str = ""
    file_name: str
    # 文本类文件直接传 text_content；二进制文件传 content_b64（base64）
    text_content: str | None = None
    content_b64: str | None = None


class PagePathReq(BaseModel):
    path: str
    title: str = ""
    description: str = ""
    parent_id: str = ""


class PageHostedReq(BaseModel):
    url: str
    title: str = ""
    description: str = ""
    parent_id: str = ""


@router.get("/pages")
async def pages_list():
    return {"pages": page_manager.list()}


@router.post("/pages")
async def pages_create(req: PageCreateReq):
    """通用新建：手动文本页面 / 文件夹 / 外部 URL 书签。"""
    try:
        if req.kind == "folder":
            return page_manager.add_folder(req.title, req.description, req.parent_id)
        if req.kind == "bookmark":
            return page_manager.add_bookmark(
                req.url, req.title, req.description, req.parent_id, hosted=False
            )
        return page_manager.add_text(
            req.title, req.description, req.content,
            source="manual", parent_id=req.parent_id,
        )
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.post("/pages/upload")
async def pages_upload(req: PageUploadReq):
    """上传文件注册：文本类读内容入库，二进制（图片/zip 等）落盘 /library 托管。"""
    try:
        if req.text_content is not None:
            return page_manager.add_text(
                req.title or req.file_name, req.description, req.text_content,
                source=f"upload:{req.file_name}", parent_id=req.parent_id,
                file_name=req.file_name,
            )
        try:
            raw = base64.b64decode(req.content_b64 or "", validate=True)
        except (binascii.Error, ValueError):
            raise ValueError("文件数据损坏，请重新选择文件")
        return page_manager.add_file_bytes(
            req.title or req.file_name, req.description, raw, req.file_name,
            req.parent_id, source=f"upload:{req.file_name}",
        )
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.post("/pages/import-path")
async def pages_import_path(req: PagePathReq):
    """从服务器本机绝对路径导入网页文件。"""
    try:
        return page_manager.import_from_path(
            req.path, req.title, req.description, req.parent_id
        )
    except (ValueError, OSError) as e:
        raise HTTPException(400, f"导入失败：{e}")


@router.post("/pages/import-hosted")
async def pages_import_hosted(req: PageHostedReq):
    """导入同一网络中其他 Agent 托管的页面：先验证连通性，再注册为书签。"""
    url = req.url.strip()
    if not url:
        raise HTTPException(400, "请输入托管页面 URL")
    try:
        async with httpx.AsyncClient(timeout=8.0, follow_redirects=True) as client:
            resp = await client.get(url)
            resp.raise_for_status()
            body = resp.text[:200_000]
    except httpx.HTTPError as e:
        raise HTTPException(400, f"无法连接托管页面：{e}")
    title = req.title.strip()
    if not title:
        m = re.search(r"<title[^>]*>(.*?)</title>", body, re.IGNORECASE | re.DOTALL)
        if m:
            title = re.sub(r"\s+", " ", m.group(1)).strip()
    try:
        return page_manager.add_bookmark(
            url, title, req.description, req.parent_id, hosted=True
        )
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.get("/pages/{page_id}")
async def pages_get(page_id: str):
    page = page_manager.get(page_id)
    if not page:
        raise HTTPException(404, "页面不存在")
    return page


@router.delete("/pages/{page_id}")
async def pages_delete(page_id: str):
    if not page_manager.delete(page_id):
        raise HTTPException(404, "页面不存在")
    return {"ok": True}


# --- jobs ---

@router.get("/jobs")
async def jobs_list():
    return {"jobs": job_scheduler.list()}


@router.post("/jobs/{job_id}/cancel")
async def jobs_cancel(job_id: str):
    if not job_scheduler.cancel(job_id):
        raise HTTPException(404, "任务不存在或已结束")
    return {"ok": True}


# --- pipeline（编排管道当前配置，调试/UI 用） ---

@router.get("/pipeline")
async def pipeline():
    cfg = load_config()
    return {
        "workflow": cfg["workflow"],
        "roles": role_describe(),
        "planner": cfg["planner"],
        "evaluator": cfg["evaluator"],
        "memory": cfg["memory"],
        "skills": {"enabled": cfg["skills"].get("enabled", True), "count": len(list_skills())},
        "providers": sorted((cfg.get("providers") or {}).keys()),
    }