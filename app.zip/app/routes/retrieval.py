"""工作区检索路由（设置 → 工作区检索）。

- GET /api/retrieval/status  当前生效的检索策略与语料库统计（文档数真实扫描）
- PUT /api/retrieval/mode    搜索运行模式（auto | fast | precise）
"""
from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from ..config import load_config, save_config
from ..workspace_manager import workspace_manager

router = APIRouter(prefix="/api/retrieval", tags=["retrieval"])

_MODES = {"auto": "自适应", "fast": "快速", "precise": "精确"}
_CONSERVATIVE_REASON = "缺少质量评估报告，因此保持保守的本地配置。"


@router.get("/status")
async def status():
    cfg = load_config()
    ws = workspace_manager.stats()
    docs = int(ws.get("documents", 0) or 0)
    paragraphs = int(ws.get("paragraphs", 0) or 0)
    # 有效深度：小语料库走保守默认（K20/evidence 8），大语料库加深
    small = docs < 500
    return {
        "mode": cfg.get("retrieval", {}).get("mode", "auto"),
        "modes": _MODES,
        "gate": "safe-default",
        "documents": docs,
        "paragraphs": paragraphs,
        "effective": {
            "k": 20 if small else 30,
            "evidence": 8 if small else 12,
            "small_corpus": small,
        },
        "dense": {"enabled": False, "reason": _CONSERVATIVE_REASON},
        "reranker": {"enabled": False, "reason": _CONSERVATIVE_REASON},
        "compile": {"timeout_s": 10.0, "samples": 0},
        "deep_read": "adaptive",
    }


class ModeReq(BaseModel):
    mode: str


@router.put("/mode")
async def set_mode(req: ModeReq):
    if req.mode not in _MODES:
        raise HTTPException(400, "无效的检索模式")
    cfg = load_config()
    cfg.setdefault("retrieval", {})["mode"] = req.mode
    save_config(cfg)
    return {"ok": True, "mode": req.mode}
