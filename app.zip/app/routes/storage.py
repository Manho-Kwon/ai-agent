"""运行与存储路由：data/ 目录磁盘用量真实扫描 + 分类清理。

- GET  /api/storage          分类统计（文件数 / 字节数），retained 为保留区不参与清理
- POST /api/storage/clean    清理选中的分类（确认对话框由前端负责）
"""
from __future__ import annotations

import os
import shutil
import time

from fastapi import APIRouter
from pydantic import BaseModel, Field

from ..config import (
    AUTOMATIONS_PATH,
    DATA_DIR,
    JOBS_PATH,
    LIBRARY_DIR,
    MCP_CACHE_DIR,
    SESSIONS_DIR,
    SKILLS_DIR,
    WORKSPACE_DIR,
)
from ..session_manager import session_manager

router = APIRouter(prefix="/api/storage", tags=["storage"])

# 已删除对话的残留（本版本没有回收站目录，恒为 0，保留占位以对齐原版分类）
_TRASH_DIR = DATA_DIR / "trash"
# 搜索索引 / 工具结果存档目录（暂未启用，占位）
_SEARCH_DIR = DATA_DIR / "cache" / "search"
_TOOL_ARCHIVE_DIR = DATA_DIR / "cache" / "tools"
# 缓存分类 = data/cache 中未被其他分类单独统计的剩余项
_CACHE_EXCLUDE = {MCP_CACHE_DIR.name, _SEARCH_DIR.name, _TOOL_ARCHIVE_DIR.name}

# 清理上限：单目录最多统计 20000 个文件，防止异常大目录拖垮请求
_MAX_FILES = 20000


def _scan_dir(root) -> tuple[int, int]:
    """递归统计目录下文件数与总字节数。目录不存在 → (0, 0)。"""
    files, total = 0, 0
    if not root.exists():
        return 0, 0
    stack = [root]
    while stack and files < _MAX_FILES:
        cur = stack.pop()
        try:
            entries = list(os.scandir(cur))
        except OSError:
            continue
        for e in entries:
            try:
                if e.is_dir(follow_symlinks=False):
                    stack.append(e.path)
                elif e.is_file(follow_symlinks=False):
                    files += 1
                    total += e.stat().st_size
            except OSError:
                continue
            if files >= _MAX_FILES:
                break
    return files, total


def _clear_dir(root, keep: set[str] | None = None) -> int:
    """清空目录内容（保留目录本身）；keep 中的同级名跳过。返回删除的文件数。"""
    if not root.exists():
        return 0
    removed = 0
    for e in list(os.scandir(root)):
        if keep and e.name in keep:
            continue
        try:
            if e.is_dir(follow_symlinks=False):
                shutil.rmtree(e.path)
            else:
                os.remove(e.path)
            removed += 1
        except OSError:
            continue
    return removed


def _purge_sessions() -> int:
    """清空全部会话（运行记录）：删除消息文件并清空注册表。"""
    count = 0
    for meta in list(session_manager.list_sessions()):
        if session_manager.delete_session(meta["id"]):
            count += 1
    return count


def _stats() -> dict:
    cats: list[dict] = []

    def add(key, label, desc, files, size, *, cleanable=True, retained=False):
        cats.append(
            {
                "key": key,
                "label": label,
                "desc": desc,
                "files": files,
                "bytes": size,
                "cleanable": cleanable,
                "retained": retained,
            }
        )

    f, b = _scan_dir(WORKSPACE_DIR / "reports")
    reports = (f, b)
    wf = _scan_dir(WORKSPACE_DIR)
    add(
        "workspace_files",
        "工作文件",
        "任务运行时创建的脚本、草稿与产物，位于受控工作区内（不含生成的文档）。",
        wf[0] - reports[0],
        wf[1] - reports[1],
    )

    sess = _scan_dir(SESSIONS_DIR)
    run_extra = sum(
        p.stat().st_size for p in (AUTOMATIONS_PATH, JOBS_PATH) if p.exists()
    )
    add(
        "run_logs",
        "运行记录",
        "会话消息与执行事件。清理可释放空间，但会失去会话续接与历史查阅。文档、页面和记忆不受影响。",
        sess[0],
        sess[1] + run_extra,
    )

    trash = _scan_dir(_TRASH_DIR)
    add(
        "deleted_conv",
        "已删除对话的记录",
        "已消失的对话残留的记录行。不会触碰仍然存在的对话。",
        trash[0],
        trash[1],
    )

    idx = _scan_dir(_SEARCH_DIR)
    add(
        "search_free",
        "搜索索引空闲空间",
        "搜索索引中未归还的空页。回收后索引内容保持不变，无需重新索引。",
        idx[0],
        idx[1],
    )

    arch = _scan_dir(_TOOL_ARCHIVE_DIR)
    add(
        "tool_archives",
        "工具结果存档",
        "历史工具调用的结果存档，供会话回溯引用。",
        arch[0],
        arch[1],
    )

    add(
        "generated_docs",
        "生成的文档",
        "自动化与任务生成的报告文档。",
        reports[0],
        reports[1],
    )

    mcp = _scan_dir(MCP_CACHE_DIR)
    add(
        "tool_cache_unused",
        "未使用的工具缓存",
        "重命名或删除的 MCP 服务器遗留的下载内容。不会影响正在使用的缓存。",
        mcp[0],
        mcp[1],
    )

    cache_root = DATA_DIR / "cache"
    cache_f = cache_b = 0
    if cache_root.exists():
        for e in os.scandir(cache_root):
            if e.is_dir(follow_symlinks=False):
                if e.name in _CACHE_EXCLUDE:
                    continue
                f2, b2 = _scan_dir(e.path)
                cache_f += f2
                cache_b += b2
            elif e.is_file(follow_symlinks=False):
                cache_f += 1
                cache_b += e.stat().st_size
    add(
        "cache",
        "缓存",
        "网关与页面缓存。清理后按需自动重建。",
        cache_f,
        cache_b,
    )

    lib = _scan_dir(LIBRARY_DIR)
    add(
        "parsed_docs",
        "已解析文档",
        "资料库中托管的文档与页面文件，始终保留。",
        lib[0],
        lib[1],
        cleanable=False,
        retained=True,
    )
    skills = _scan_dir(SKILLS_DIR)
    add(
        "skills",
        "技能文件",
        "内置与自定义技能的指令文件，始终保留。",
        skills[0],
        skills[1],
        cleanable=False,
        retained=True,
    )

    return {
        "categories": [c for c in cats if not c["retained"]],
        "retained": [c for c in cats if c["retained"]],
        "workspace_dir": str(WORKSPACE_DIR),
        "generated_at": int(time.time()),
    }


@router.get("")
async def storage_stats():
    return _stats()


class CleanReq(BaseModel):
    keys: list[str] = Field(default_factory=list)


_CLEANERS = {
    "workspace_files": lambda: _clear_dir(WORKSPACE_DIR, keep={"reports"}),
    "run_logs": _purge_sessions,
    "deleted_conv": lambda: _clear_dir(_TRASH_DIR),
    "search_free": lambda: _clear_dir(_SEARCH_DIR),
    "tool_archives": lambda: _clear_dir(_TOOL_ARCHIVE_DIR),
    "generated_docs": lambda: _clear_dir(WORKSPACE_DIR / "reports"),
    "tool_cache_unused": lambda: _clear_dir(MCP_CACHE_DIR),
    "cache": lambda: _clear_dir(DATA_DIR / "cache", keep=_CACHE_EXCLUDE),
}


@router.post("/clean")
async def storage_clean(req: CleanReq):
    removed = 0
    for key in req.keys:
        fn = _CLEANERS.get(key)
        if fn:
            removed += fn()
    return {"ok": True, "removed": removed, **_stats()}
