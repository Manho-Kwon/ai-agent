"""工作区路由：注册表 CRUD / 索引统计 / 同步 / 每日检查配置 / 目录浏览。"""
from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from ..workspace_manager import workspace_manager

router = APIRouter(prefix="/api/workspaces", tags=["workspaces"])


class WorkspaceCreateReq(BaseModel):
    name: str
    path: str
    description: str = ""


class DailyConfigReq(BaseModel):
    enabled: bool
    hour: int = 3
    minute: int = 0


@router.get("")
async def ws_list():
    return {"workspaces": workspace_manager.list()}


@router.post("")
async def ws_create(req: WorkspaceCreateReq):
    try:
        rec = workspace_manager.create(req.name, req.path, req.description)
    except ValueError as e:
        raise HTTPException(400, str(e))
    workspace_manager.sync()  # 注册后立即刷新索引统计
    return rec


@router.get("/stats")
async def ws_stats():
    return workspace_manager.stats()


@router.post("/sync")
async def ws_sync():
    return workspace_manager.sync()


@router.post("/retry-failed")
async def ws_retry_failed():
    return workspace_manager.retry_failed()


@router.post("/daily-config")
async def ws_daily_config(req: DailyConfigReq):
    try:
        workspace_manager.set_daily_config(req.enabled, req.hour, req.minute)
    except ValueError as e:
        raise HTTPException(400, str(e))
    return workspace_manager.stats()


@router.get("/browse")
async def ws_browse(path: str = ""):
    try:
        return workspace_manager.browse(path)
    except ValueError as e:
        raise HTTPException(400, str(e))


@router.delete("/{ws_id}")
async def ws_delete(ws_id: str):
    if not workspace_manager.delete(ws_id):
        raise HTTPException(404, "工作区不存在")
    workspace_manager.sync()  # 删除后立即刷新索引统计
    return {"ok": True}
