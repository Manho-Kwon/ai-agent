"""设置路由（对齐原版 api/endpoints/settings.py 裁剪版）。

- GET  /api/settings          读生效配置（密钥只返回是否已配置，不回显）
- PUT  /api/settings          更新 config.json（白名单字段：llm / ui / roles /
                              workflow.mode / runtime.allow_export / evaluator.enabled）
- POST /api/settings/probe    网关连通性探测（GET /models，返回模型列表与延迟）
"""
from __future__ import annotations

import time

from fastapi import APIRouter
from pydantic import BaseModel, Field

from .. import model_router
from ..config import api_key, load_config, llm_settings, save_config
from ..llm import LLMError, list_models

router = APIRouter(prefix="/api/settings", tags=["settings"])

# ui 节允许写入的键（appearance 为嵌套 dict，整体替换）
_UI_KEYS = (
    "title",
    "subtitle",
    "user_name",
    "user_avatar",
    "bot_name",
    "bot_avatar",
    "executor_instructions",
    "appearance",
)
# 允许设置模型的角色（planner/executor/executor_recovery/evaluator/memory/doc_*）
_ROLE_KEYS = model_router.ROLES
_WORKFLOW_MODES = ("auto", "fast", "standard", "deep")


class SettingsUpdate(BaseModel):
    base_url: str | None = None
    model: str | None = None
    temperature: float | None = None
    max_tokens: int | None = None
    max_tool_rounds: int | None = None
    ui: dict | None = None
    roles: dict[str, dict] = Field(default_factory=dict)
    workflow_mode: str | None = None
    allow_export: bool | None = None
    yolo_mode: bool | None = None
    evaluator_enabled: bool | None = None
    memory_enabled: bool | None = None


@router.get("")
async def get_settings():
    s = llm_settings()
    cfg = load_config()
    return {
        "ui": cfg["ui"],
        "llm": {
            "base_url": s["base_url"],
            "model": s["model"],
            "temperature": s["temperature"],
            "max_tokens": s["max_tokens"],
            "max_tool_rounds": s["max_tool_rounds"],
            "api_key_set": bool(api_key()),
        },
        "roles": model_router.describe(),
        "workflow": cfg["workflow"],
        "runtime": cfg["runtime"],
        "yolo_mode": cfg["runtime"].get("yolo_mode", False),
        "evaluator": cfg["evaluator"],
        "memory": cfg.get("memory", {"enabled": True, "auto_extract": True}),
    }


@router.put("")
async def put_settings(req: SettingsUpdate):
    cfg = load_config()

    llm_updates: dict = {}
    for field in ("base_url", "model", "temperature", "max_tokens", "max_tool_rounds"):
        value = getattr(req, field)
        if value is not None:
            llm_updates[field] = value
    if llm_updates:
        cfg["llm"].update(llm_updates)

    if req.ui is not None:
        for key in _UI_KEYS:
            if key in req.ui:
                cfg["ui"][key] = req.ui[key]

    for role, spec in (req.roles or {}).items():
        if role not in _ROLE_KEYS or not isinstance(spec, dict):
            continue
        entry = cfg["roles"].setdefault(role, {"provider": "default", "model": ""})
        if spec.get("provider"):
            entry["provider"] = str(spec["provider"])
        entry["model"] = str(spec.get("model") or "")

    if req.workflow_mode is not None:
        if req.workflow_mode not in _WORKFLOW_MODES:
            from fastapi import HTTPException

            raise HTTPException(400, "无效的运行策略")
        cfg["workflow"]["mode"] = req.workflow_mode

    if req.allow_export is not None:
        cfg["runtime"]["allow_export"] = bool(req.allow_export)

    if req.yolo_mode is not None:
        cfg["runtime"]["yolo_mode"] = bool(req.yolo_mode)

    if req.evaluator_enabled is not None:
        cfg["evaluator"]["enabled"] = bool(req.evaluator_enabled)

    if req.memory_enabled is not None:
        cfg["memory"]["enabled"] = bool(req.memory_enabled)

    save_config(cfg)
    return {"ok": True}


@router.post("/probe")
async def probe_gateway():
    start = time.perf_counter()
    try:
        models = await list_models()
        return {
            "ok": True,
            "models": models,
            "latency_ms": round((time.perf_counter() - start) * 1000),
            "model": llm_settings()["model"],
        }
    except LLMError as e:
        return {
            "ok": False,
            "error": str(e),
            "latency_ms": round((time.perf_counter() - start) * 1000),
        }
