"""会话 CRUD 路由（对齐原版 api/endpoints/sessions.py 裁剪版）。"""
from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from ..session_manager import session_manager

router = APIRouter(prefix="/api/sessions", tags=["sessions"])


class CreateSessionReq(BaseModel):
    title: str = ""


class UpdateSessionReq(BaseModel):
    title: str


@router.get("")
async def list_sessions():
    return session_manager.list_sessions()


@router.post("")
async def create_session(req: CreateSessionReq):
    return session_manager.create_session(req.title)


@router.get("/{session_id}")
async def get_session(session_id: str):
    meta = session_manager.get_session(session_id)
    if not meta:
        raise HTTPException(404, "会话不存在")
    return {**meta, "messages": session_manager.get_messages(session_id)}


@router.patch("/{session_id}")
async def update_session(session_id: str, req: UpdateSessionReq):
    meta = session_manager.update_title(session_id, req.title)
    if not meta:
        raise HTTPException(404, "会话不存在")
    return meta


@router.delete("/{session_id}")
async def delete_session(session_id: str):
    if not session_manager.delete_session(session_id):
        raise HTTPException(404, "会话不存在")
    return {"ok": True}
