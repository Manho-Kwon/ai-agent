"""模型连接路由（设置 → LLM 配置 → 管理模型连接）。

两类配置方式：
- 内置密钥型提供商：内部 LLM · 内部处理 / 内部 LLM 代理 · 外部传输
  （共用网关地址 + API_KEY）。「配置」录入密钥，密钥只写 data/.env（SSOT），
  随后立即 GET /models 验证。
- 自定义 / 自托管：每条 = config.json providers 节的一个命名 provider
  （base_url + model + api_key_env），密钥写入生成的 .env 变量
  CONN_CM_<id>_KEY；model_router 按 roles.<role>.provider 直接消费，
  角色分配无需额外胶水。

验证状态持久化在 config.json connections 节；GET 只读数、不做网络请求，
验证动作只发生在 POST /refresh（批量）、POST /{key}/key（保存密钥即验）、
POST /custom/models（添加即验证，失败不保存）。
"""
from __future__ import annotations

import asyncio
import logging
import os
import re
import uuid
from datetime import datetime

import httpx
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from ..config import (
    api_key,
    delete_env_key,
    llm_settings,
    load_config,
    normalize_base_url,
    save_config,
    set_env_key,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/connections", tags=["connections"])

# 内置提供商定义（顺序即弹窗中的展示顺序）
BUILTIN_PROVIDERS = (
    {
        "key": "internal",
        "title": "内部 LLM · 内部处理",
        "env": "API_KEY",
        "base_url": None,  # 跟随 llm.base_url（内部网关）
    },
    {
        "key": "internal_proxy",
        "title": "内部 LLM 代理 · 外部传输",
        "env": "API_KEY",
        "base_url": None,
    },
)
_BUILTIN_KEYS = {p["key"] for p in BUILTIN_PROVIDERS}

_STATUS_TEXT = {
    "disconnected": "需要连接",
    "unverified": "需要验证",
    "connected": "已连接",
    "error": "连接失败",
    "checking": "验证中…",
}

# 角色 key → 中文展示名（「使用中」橙色提示与模型分配面包屑共用）
ROLE_LABELS = {
    "planner": "规划代理",
    "executor": "执行代理",
    "executor_recovery": "恢复执行代理",
    "evaluator": "评估代理",
    "memory": "记忆",
    "doc_compose": "文档 AI · Compose",
    "doc_parse": "文档解析",
    "multimodal": "多模态后备",
}
# 面包屑顺序（模型分配页「应用角色」行）
ROLE_ORDER = ("planner", "executor", "evaluator", "doc_compose", "doc_parse", "multimodal")

VERIFY_TIMEOUT = 10.0


# ────────────────────────────────────────────────────────────────
# 验证逻辑
# ────────────────────────────────────────────────────────────────

def _headers(key: str) -> dict[str, str]:
    headers = {"Content-Type": "application/json"}
    if key:
        headers["Authorization"] = f"Bearer {key}"
    return headers


async def _verify_endpoint(base_url: str, key: str) -> tuple[bool, str | None, int]:
    """GET {base}/models 验证连通性与密钥。返回 (ok, error, model_count)。"""
    base = normalize_base_url(base_url or "")
    if not base:
        return False, "未配置 API Base URL", 0
    try:
        async with httpx.AsyncClient(timeout=VERIFY_TIMEOUT) as client:
            resp = await client.get(f"{base}/models", headers=_headers(key))
            if resp.status_code in (401, 403):
                return False, f"认证失败（HTTP {resp.status_code}），请检查 API 密钥", 0
            if resp.status_code >= 500:
                return False, f"网关错误（HTTP {resp.status_code}），请稍后重试", 0
            if resp.status_code >= 400:
                return False, f"网关返回 HTTP {resp.status_code}", 0
            data = resp.json()
    except httpx.HTTPError as e:
        return False, f"无法连接：{type(e).__name__}", 0
    except ValueError:
        return False, "返回内容不是有效的 JSON", 0
    items = data.get("data") if isinstance(data, dict) else None
    count = len(items) if isinstance(items, list) else 0
    return True, None, count


def _builtin_endpoint() -> tuple[str, str]:
    """内置提供商当前的 (base_url, api_key)（两项内部 LLM 均跟随 llm 配置）。"""
    s = llm_settings()
    return s["base_url"], api_key()


async def _verify_builtin(key: str) -> tuple[str, bool, str | None]:
    base, secret = _builtin_endpoint()
    if not secret:
        return key, False, "未配置 API 密钥"
    ok, err, _count = await _verify_endpoint(base, secret)
    return key, ok, err


async def _verify_custom(pid: str, spec: dict) -> tuple[str, bool, str | None]:
    env_name = str(spec.get("api_key_env") or "").strip()
    secret = os.getenv(env_name, "").strip() if env_name else ""
    ok, err, _count = await _verify_endpoint(str(spec.get("base_url") or ""), secret)
    return pid, ok, err


def _now() -> str:
    return datetime.now().isoformat(timespec="seconds")


def _ensure_conn_section(cfg: dict) -> dict:
    """防御性补齐 connections 节（老 config.json 无此节或缺键）。"""
    conn = cfg.setdefault("connections", {})
    for p in BUILTIN_PROVIDERS:
        conn.setdefault(
            p["key"], {"status": "disconnected", "last_checked": None, "error": None}
        )
    conn.setdefault("custom_models", {})
    return conn


# ────────────────────────────────────────────────────────────────
# 状态组装
# ────────────────────────────────────────────────────────────────

def _builtin_key_set() -> bool:
    return bool(api_key())


def _state() -> dict:
    cfg = load_config()
    conn = _ensure_conn_section(cfg)
    providers: list[dict] = []

    checked_times: list[str] = []

    for p in BUILTIN_PROVIDERS:
        meta = conn.get(p["key"]) or {}
        key_set = _builtin_key_set()
        last_checked = meta.get("last_checked")
        if last_checked:
            status = meta.get("status") or ("connected" if key_set else "disconnected")
        else:
            status = "unverified" if key_set else "disconnected"
        if last_checked:
            checked_times.append(last_checked)
        providers.append(
            {
                "key": p["key"],
                "title": p["title"],
                "env": p["env"],
                "kind": "builtin",
                "status": status,
                "status_text": _STATUS_TEXT.get(status, status),
                "key_set": key_set,
                "last_checked": last_checked,
                "error": meta.get("error"),
                "note": "已保存密钥。出于安全考虑，不显示其值。" if key_set else None,
            }
        )

    # 自定义 / 自托管：providers 节中 kind=custom 的条目
    roles = cfg.get("roles") or {}
    in_use: dict[str, list[str]] = {}
    for role, spec in roles.items():
        if isinstance(spec, dict):
            prov = str(spec.get("provider") or "default")
            if prov != "default":
                in_use.setdefault(prov, []).append(ROLE_LABELS.get(role, role))

    models_out: list[dict] = []
    providers_cfg = cfg.get("providers") or {}
    custom_items = [
        (pid, spec)
        for pid, spec in providers_cfg.items()
        if isinstance(spec, dict) and spec.get("kind") == "custom"
    ]
    custom_items.sort(key=lambda kv: str(kv[1].get("created_at") or ""))
    custom_meta = conn.get("custom_models") or {}
    for pid, spec in custom_items:
        meta = custom_meta.get(pid) or {}
        last_checked = meta.get("last_checked")
        if last_checked:
            status = meta.get("status") or "unverified"
            checked_times.append(last_checked)
        else:
            status = "unverified"
        models_out.append(
            {
                "id": pid,
                "label": str(spec.get("label") or spec.get("model") or pid),
                "model": str(spec.get("model") or ""),
                "base_url": str(spec.get("base_url") or ""),
                "status": status,
                "status_text": _STATUS_TEXT.get(status, status),
                "last_checked": last_checked,
                "error": meta.get("error"),
                "in_use": in_use.get(pid, []),
            }
        )

    total = len(models_out)
    connected = sum(1 for m in models_out if m["status"] == "connected")
    if total == 0:
        c_status, c_text = "disconnected", "尚未添加模型"
    elif connected == total:
        c_status, c_text = "connected", f"已连接 · {total} 个模型"
    elif connected > 0:
        c_status, c_text = "unverified", f"已连接 {connected}/{total} 个模型"
    else:
        c_status, c_text = "error", f"{total} 个模型均未连接"

    providers.append(
        {
            "key": "custom",
            "title": "自定义 / 自托管",
            "kind": "custom",
            "subtitle": "直接验证 API Base 和模型。",
            "status": c_status,
            "status_text": c_text,
            "connected_count": connected,
            "total_count": total,
            "models": models_out,
        }
    )

    return {
        "providers": providers,
        "last_checked": max(checked_times) if checked_times else None,
        "role_order": [ROLE_LABELS[r] for r in ROLE_ORDER],
    }


# ────────────────────────────────────────────────────────────────
# 请求模型
# ────────────────────────────────────────────────────────────────

class KeyReq(BaseModel):
    api_key: str = ""
    """内部提供商可顺带更新网关地址"""
    base_url: str | None = None


class CustomModelReq(BaseModel):
    label: str = ""
    model: str = ""
    base_url: str = ""
    api_key: str = ""


# ────────────────────────────────────────────────────────────────
# 路由
# ────────────────────────────────────────────────────────────────

@router.get("")
async def list_connections():
    return _state()


@router.post("/refresh")
async def refresh_all():
    """全部刷新：并行验证所有内置提供商 + 全部自定义模型，落盘状态。"""
    cfg = load_config()
    conn = _ensure_conn_section(cfg)

    tasks = [_verify_builtin(p["key"]) for p in BUILTIN_PROVIDERS]
    custom = [
        (pid, spec)
        for pid, spec in (cfg.get("providers") or {}).items()
        if isinstance(spec, dict) and spec.get("kind") == "custom"
    ]
    tasks.extend(_verify_custom(pid, spec) for pid, spec in custom)

    results = await asyncio.gather(*tasks, return_exceptions=True)
    now = _now()
    custom_pids = {pid for pid, _ in custom}
    for r in results:
        if isinstance(r, Exception):
            logger.warning("连接验证异常: %s", r)
            continue
        target, ok, err = r
        if target in custom_pids:
            conn["custom_models"][target] = {
                "status": "connected" if ok else "error",
                "last_checked": now,
                "error": err,
            }
        else:
            # 未录入密钥的内置提供商保持「需要连接」，而非「连接失败」
            status = "connected" if ok else ("disconnected" if not _builtin_key_set() else "error")
            conn[target] = {"status": status, "last_checked": now, "error": err}
    save_config(cfg)
    return _state()


@router.post("/{key}/key")
async def save_key(key: str, req: KeyReq):
    """录入/更新内置提供商密钥（写 .env）后立即验证。"""
    if key not in _BUILTIN_KEYS:
        raise HTTPException(404, "未知提供商")
    secret = (req.api_key or "").strip()
    if not secret:
        raise HTTPException(400, "API 密钥不能为空")

    set_env_key("API_KEY", secret)

    # 内部提供商允许顺带更新网关地址
    if key in ("internal", "internal_proxy") and req.base_url and req.base_url.strip():
        cfg = load_config()
        cfg["llm"]["base_url"] = normalize_base_url(req.base_url.strip())
        save_config(cfg)

    target, ok, err = await _verify_builtin(key)
    cfg = load_config()
    conn = _ensure_conn_section(cfg)
    conn[target] = {
        "status": "connected" if ok else "error",
        "last_checked": _now(),
        "error": err,
    }
    save_config(cfg)
    if not ok:
        # 密钥已保存但验证失败：保留密钥，返回 422 让界面提示原因
        raise HTTPException(422, f"密钥已保存，但验证未通过：{err or '无法连接'}")
    return _state()


@router.post("/custom/models")
async def add_custom_model(req: CustomModelReq):
    """添加自定义 / 自托管模型：先验证连通性，通过后才落盘。"""
    label = (req.label or "").strip()
    model = (req.model or "").strip()
    base_url = normalize_base_url((req.base_url or "").strip())
    secret = (req.api_key or "").strip()

    if not label:
        raise HTTPException(400, "请填写显示名称")
    if not model:
        raise HTTPException(400, "请填写模型 ID（例如 openai/gpt-4o）")
    if not base_url:
        raise HTTPException(400, "请填写 API Base URL")
    if not re.match(r"^https?://", base_url):
        raise HTTPException(400, "API Base URL 必须以 http:// 或 https:// 开头")

    ok, err, _count = await _verify_endpoint(base_url, secret)
    if not ok:
        raise HTTPException(422, f"验证未通过，未保存：{err}")

    pid = f"cm_{uuid.uuid4().hex[:8]}"
    env_name = f"CONN_{pid.upper()}_KEY"
    if secret:
        set_env_key(env_name, secret)

    cfg = load_config()
    conn = _ensure_conn_section(cfg)
    cfg.setdefault("providers", {})[pid] = {
        "label": label,
        "kind": "custom",
        "base_url": base_url,
        "model": model,
        "api_key_env": env_name if secret else "",
        "created_at": _now(),
    }
    conn["custom_models"][pid] = {
        "status": "connected",
        "last_checked": _now(),
        "error": None,
    }
    save_config(cfg)
    logger.info("已添加自定义模型 %s (%s @ %s)", pid, model, base_url)
    return _state()


@router.delete("/custom/models/{pid}")
async def delete_custom_model(pid: str):
    cfg = load_config()
    prov = (cfg.get("providers") or {}).get(pid)
    if not isinstance(prov, dict) or prov.get("kind") != "custom":
        raise HTTPException(404, "模型不存在")

    del cfg["providers"][pid]
    # 引用该 provider 的角色回退默认网关
    for spec in (cfg.get("roles") or {}).values():
        if isinstance(spec, dict) and spec.get("provider") == pid:
            spec["provider"] = "default"
            spec["model"] = ""
    env_name = str(prov.get("api_key_env") or "").strip()
    if env_name:
        delete_env_key(env_name)
    conn = _ensure_conn_section(cfg)
    conn.get("custom_models", {}).pop(pid, None)
    save_config(cfg)
    logger.info("已删除自定义模型 %s", pid)
    return {"ok": True}
