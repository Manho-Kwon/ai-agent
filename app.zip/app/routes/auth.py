"""访问认证路由（红线：共享给团队前必须开启）。

- GET  /api/auth/status   {enabled, token_configured}
- POST /api/auth/enable   开启认证：body 可带自定义 token（≥8 位），缺省自动生成安全随机 token；
                          响应返回完整 token（唯一一次完整展示机会）
- POST /api/auth/disable  关闭认证

安全边界：enable/disable 仅允许本机回环调用（防远程攻击者关闭认证）；
token 只存 config.json auth.token；API 侧由 main.py 中间件统一校验 Bearer。
"""
from __future__ import annotations

import secrets

from fastapi import APIRouter, HTTPException, Request
from pydantic import BaseModel

from ..config import load_config, update_config

router = APIRouter(prefix="/api/auth", tags=["auth"])


def _require_loopback(request: Request) -> None:
    host = request.client.host if request.client else ""
    if host not in ("127.0.0.1", "::1", "localhost"):
        raise HTTPException(403, "认证开关仅允许本机操作")


class EnableReq(BaseModel):
    token: str = ""


@router.get("/status")
async def status():
    auth = load_config().get("auth") or {}
    return {"enabled": bool(auth.get("enabled")), "token_configured": bool(auth.get("token"))}


@router.post("/enable")
async def enable(request: Request, req: EnableReq | None = None):
    _require_loopback(request)
    token = (req.token or "").strip() if req else ""
    if token:
        if len(token) < 8:
            raise HTTPException(400, "自定义 token 至少 8 位")
    else:
        token = secrets.token_urlsafe(24)
    update_config({"auth": {"enabled": True, "token": token}})
    return {"enabled": True, "token": token}


@router.post("/disable")
async def disable(request: Request):
    _require_loopback(request)
    update_config({"auth": {"enabled": False, "token": ""}})
    return {"enabled": False}
