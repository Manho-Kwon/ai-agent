"""MCP 服务器管理路由（对齐原版 api/endpoints/mcp.py 裁剪版）。

- GET  /api/mcp/servers             服务器状态 + 各自工具列表 + mcp.json 解析错误
- POST /api/mcp/reload              热重载配置（diff 重连，兼作不健康连接的恢复动作）
- POST /api/mcp/servers             注册新服务器（写 mcp.json 并热连接）
- POST /api/mcp/servers/{name}/enabled  开关单个服务器（写回 mcp.json 并热应用）
- POST /api/mcp/open-config-folder  在资源管理器中打开配置所在文件夹
"""
from __future__ import annotations

import asyncio
import json
import logging
import os
import subprocess
import sys
from contextlib import suppress

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

import app.config as cfg_mod
from ..mcp_manager import mcp_manager

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/mcp", tags=["mcp"])


@router.get("/servers")
async def list_servers():
    servers = []
    for s in mcp_manager.get_all_server_statuses():
        tools = await mcp_manager.get_server_tools(s["name"])
        s["tools"] = [
            {
                "name": t["function"]["name"],  # 命名空间全名 server__tool
                "short_name": t["function"]["name"].split("__", 1)[-1],
                "description": t["function"]["description"],
            }
            for t in tools
        ]
        servers.append(s)
    return {
        "servers": servers,
        "config_error": cfg_mod.mcp_config_error,
        "config_path": str(cfg_mod.MCP_CONFIG_PATH),
    }


@router.post("/reload")
async def reload_config():
    result = await mcp_manager.reload_config()
    return result


class AddServerReq(BaseModel):
    name: str
    transport: str = "stdio"  # stdio | http | sse
    command: str | None = None
    args: list[str] = Field(default_factory=list)
    url: str | None = None
    env: dict[str, str] = Field(default_factory=dict)


@router.post("/servers")
async def add_server(req: AddServerReq):
    """注册新 MCP 服务器：写入 mcp.json（enabled 默认 true）后热重载连接。"""
    name = (req.name or "").strip()
    transport = (req.transport or "stdio").strip().lower()
    if not name or any(c in name for c in '/\\"\' '):
        raise HTTPException(400, "服务器名称不能为空，且不能包含空格或路径分隔符")
    if transport not in ("stdio", "http", "sse"):
        raise HTTPException(400, f"不支持的传输方式: {transport}")
    if transport == "stdio" and not (req.command or "").strip():
        raise HTTPException(400, "stdio 传输必须填写启动命令")
    if transport in ("http", "sse") and not (req.url or "").strip():
        raise HTTPException(400, f"{transport} 传输必须填写 URL")
    path = cfg_mod.MCP_CONFIG_PATH
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        data = {"mcpServers": {}}
    except json.JSONDecodeError as e:
        raise HTTPException(409, detail=f"mcp.json 解析失败: {e}")
    servers = data.setdefault("mcpServers", {})
    if name in servers:
        raise HTTPException(400, f"服务器「{name}」已存在")
    entry: dict = {"transport": transport, "enabled": True}
    if transport == "stdio":
        entry["command"] = req.command.strip()
        if req.args:
            entry["args"] = [a for a in req.args if a.strip()]
        if req.env:
            entry["env"] = {k: v for k, v in req.env.items() if k.strip()}
    else:
        entry["url"] = (req.url or "").strip()
    servers[name] = entry
    path.write_text(
        json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    # 后台热重载：连接不可达服务器最多等 CONNECT_TIMEOUT_S（30s），
    # 不能让「添加」请求挂那么久 —— 状态由列表页轮询呈现
    asyncio.create_task(mcp_manager.reload_config(), name="mcp-reload-after-add")
    return {"ok": True, "name": name}


class EnabledBody(BaseModel):
    enabled: bool


@router.post("/servers/{name}/enabled")
async def set_server_enabled(name: str, body: EnabledBody):
    """开关单个 MCP 服务器：写回 mcp.json 后热应用（启用→连接，停用→断开）。"""
    path = cfg_mod.MCP_CONFIG_PATH
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError:
        raise HTTPException(status_code=404, detail="mcp.json 不存在")
    except json.JSONDecodeError as e:
        raise HTTPException(status_code=409, detail=f"mcp.json 解析失败: {e}")
    servers = data.setdefault("mcpServers", {})
    if name not in servers:
        raise HTTPException(status_code=404, detail=f"未知 MCP 服务器: {name}")
    servers[name]["enabled"] = body.enabled
    path.write_text(
        json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )

    async def _apply_toggle() -> None:
        result = await mcp_manager.reload_config()
        if not body.enabled:
            # reload 只断开「被移除」的服务器；停用的需显式断开残留连接
            with suppress(Exception):
                await mcp_manager.disconnect_server(name)
        logger.info("MCP 开关热应用完成: %s → %s %s", name, body.enabled, result.get("changed"))

    asyncio.create_task(_apply_toggle(), name=f"mcp-toggle-{name}")
    return {"ok": True, "name": name, "enabled": body.enabled}


@router.post("/open-config-folder")
async def open_config_folder():
    """在系统文件管理器中打开 mcp.json 所在文件夹。"""
    folder = str(cfg_mod.MCP_CONFIG_PATH.parent)
    try:
        if sys.platform == "win32":
            os.startfile(folder)  # type: ignore[attr-defined]  # noqa: S606
        elif sys.platform == "darwin":
            subprocess.Popen(["open", folder])  # noqa: S603
        else:
            subprocess.Popen(["xdg-open", folder])  # noqa: S603
    except OSError as e:
        raise HTTPException(status_code=500, detail=f"无法打开文件夹: {e}")
    return {"ok": True}
