"""RAG 知识库引擎：BM25 + 向量混合检索（RRF 融合），数据源为资料库页面全文。

- 分块：字符滑窗（chunk_size / chunk_overlap，中文友好）
- BM25：字符 bigram 词袋 + Okapi BM25（纯 Python，零外部依赖）
- 向量：网关 /v1/embeddings（rag.embed_model 空 → 自动探测含 embed 的模型；探测失败 → 纯 BM25）
- 混合：两路各取 top_k，RRF(k=rrf_k) 融合后取 rerank_top_n
- 拒答：confidence = top1 余弦相似度（有向量）或 BM25 经验归一化（纯词法），低于 refuse_threshold 拒答
- 索引：data/rag_index.json 懒加载；页面集合签名变化自动增量重建（无 watcher 依赖）
"""
from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import math
import re
import threading
import time
from typing import Any

from . import audit
from .config import DATA_DIR, load_config
from .llm import LLMError, embed_texts, list_models

logger = logging.getLogger(__name__)

INDEX_PATH = DATA_DIR / "rag_index.json"
MAX_CHUNKS = 2000  # 索引 chunk 上限（防止向量文件无限膨胀）
_EMBED_BATCH = 32  # 向量化批量大小
_BM25_K1 = 1.5
_BM25_B = 0.75
_BM25_CONF_CAP = 6.0  # 纯 BM25 模式 confidence 归一化分母（经验值）

_WORD_RE = re.compile(r"[a-zA-Z0-9_]+")


def _tokenize(text: str) -> list[str]:
    """中文 bigram + 英文/数字词（查询与索引共用同一分词）。"""
    tokens: list[str] = []
    for word in _WORD_RE.findall(text):
        tokens.append(word.lower())
    han = re.sub(r"[^\u4e00-\u9fff]", " ", text)
    for seg in han.split():
        if len(seg) == 1:
            tokens.append(seg)
        else:
            tokens.extend(seg[i : i + 2] for i in range(len(seg) - 1))
    return tokens


def _chunk_text(text: str, size: int, overlap: int) -> list[str]:
    text = (text or "").strip()
    if not text:
        return []
    if len(text) <= size:
        return [text]
    step = max(1, size - overlap)
    return [text[i : i + size] for i in range(0, len(text), step)]


def _cosine(a: list[float], b: list[float]) -> float:
    if not a or not b or len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    na = math.sqrt(sum(x * x for x in a))
    nb = math.sqrt(sum(x * x for x in b))
    if na == 0.0 or nb == 0.0:
        return 0.0
    return dot / (na * nb)


class _BM25:
    """Okapi BM25（bigram 词袋）。"""

    def __init__(self) -> None:
        self._tf: list[dict[str, int]] = []
        self._df: dict[str, int] = {}
        self._avgdl = 1.0

    def build(self, docs_tokens: list[list[str]]) -> None:
        self._tf = []
        self._df = {}
        total = 0
        for toks in docs_tokens:
            tf: dict[str, int] = {}
            for t in toks:
                tf[t] = tf.get(t, 0) + 1
            self._tf.append(tf)
            for t in tf:
                self._df[t] = self._df.get(t, 0) + 1
            total += len(toks)
        self._avgdl = (total / len(docs_tokens)) if docs_tokens else 1.0

    def search(self, query: str, top_k: int, n_docs: int) -> list[tuple[int, float]]:
        q_tokens = _tokenize(query)
        if not q_tokens or not self._tf:
            return []
        scores: list[float] = [0.0] * len(self._tf)
        for i, tf in enumerate(self._tf):
            dl = sum(tf.values()) or 1
            for t in q_tokens:
                f = tf.get(t)
                if not f:
                    continue
                df = self._df.get(t, 0)
                idf = math.log(1.0 + (n_docs - df + 0.5) / (df + 0.5))
                scores[i] += (
                    idf * f * (_BM25_K1 + 1.0)
                    / (f + _BM25_K1 * (1.0 - _BM25_B + _BM25_B * dl / self._avgdl))
                )
        ranked = sorted(enumerate(scores), key=lambda x: x[1], reverse=True)
        return [(i, s) for i, s in ranked[:top_k] if s > 0.0]


_detect_cache: str | None = None  # 进程内 embed 模型探测缓存（None = 未探测）


async def detect_embed_model() -> str:
    """探测网关 embedding 模型（config rag.embed_model 优先，否则取名字含 embed 的模型）。

    结果进程内缓存；返回空串 = 不可用（调用方退化为词法检索）。
    记忆检索（memory_manager.retrieve_hybrid）与 RAG 共用本函数，避免两套探测逻辑。
    """
    global _detect_cache
    if _detect_cache is not None:
        return _detect_cache
    model = str((load_config().get("rag") or {}).get("embed_model") or "").strip()
    if not model:
        try:
            for name in await list_models():
                if "embed" in name.lower():
                    model = name
                    break
        except LLMError:
            logger.info("embedding 探测失败（网关不可达），使用词法检索")
    _detect_cache = model
    return model


def reset_embed_detect() -> None:
    """清除探测缓存（reindex 时强制重新探测）。"""
    global _detect_cache
    _detect_cache = None


class RagEngine:
    def __init__(self) -> None:
        self._lock = asyncio.Lock()  # 重建互斥（async 语义）
        self._persist_lock = threading.Lock()
        self._chunks: list[dict[str, Any]] = []
        self._bm25 = _BM25()
        self._signature: str = ""
        self._embed_model: str = ""  # 生效的 embedding 模型（"" = 纯 BM25）
        self._built_at: str = ""
        self._loaded = False

    # --- 持久化 ---

    def _load_index(self) -> None:
        if self._loaded:
            return
        try:
            data = json.loads(INDEX_PATH.read_text(encoding="utf-8"))
            self._chunks = [c for c in data.get("chunks", []) if isinstance(c, dict)]
            self._signature = data.get("signature", "")
            self._embed_model = data.get("embed_model", "")
            self._built_at = data.get("built_at", "")
        except (json.JSONDecodeError, OSError):
            self._chunks = []
        self._rebuild_bm25()
        self._loaded = True

    def _save_index(self) -> None:
        with self._persist_lock:
            try:
                INDEX_PATH.write_text(
                    json.dumps(
                        {
                            "signature": self._signature,
                            "embed_model": self._embed_model,
                            "built_at": self._built_at,
                            "chunks": self._chunks,
                        },
                        ensure_ascii=False,
                    ),
                    encoding="utf-8",
                )
            except OSError:
                logger.warning("RAG 索引写入失败", exc_info=True)

    def _rebuild_bm25(self) -> None:
        self._bm25.build([_tokenize(c["text"]) for c in self._chunks])

    # --- 数据源与签名 ---

    def _pages_signature(self, pages: list[dict[str, Any]]) -> str:
        h = hashlib.sha1()
        for p in sorted(pages, key=lambda x: x["id"]):
            h.update(f"{p['id']}:{p['updated_at']}:{len(p['content'])};".encode("utf-8"))
        return h.hexdigest()

    # --- 向量化 ---

    async def _detect_embed_model(self) -> str:
        return await detect_embed_model()

    async def _embed(self, texts: list[str]) -> list[list[float]] | None:
        if not self._embed_model:
            return None
        try:
            return await embed_texts(texts, model=self._embed_model)
        except LLMError as e:
            logger.warning("RAG：向量化失败（%s），该次检索退化为纯 BM25", e)
            return None

    # --- 索引构建 ---

    async def _ensure_fresh(self) -> None:
        """懒加载 + 页面集合签名变化时自动重建。"""
        self._load_index()
        from .page_manager import page_manager

        pages = page_manager.iter_page_contents()
        sig = self._pages_signature(pages)
        if sig == self._signature and self._chunks:
            return
        async with self._lock:
            pages = page_manager.iter_page_contents()
            sig = self._pages_signature(pages)
            if sig == self._signature and self._chunks:
                return
            await self._build(pages, sig)

    async def _build(self, pages: list[dict[str, Any]], sig: str) -> None:
        start = time.perf_counter()
        rag_cfg = load_config().get("rag") or {}
        size = int(rag_cfg.get("chunk_size") or 512)
        overlap = int(rag_cfg.get("chunk_overlap") or 64)

        chunks: list[dict[str, Any]] = []
        for p in pages:
            for i, piece in enumerate(_chunk_text(p["content"], size, overlap)):
                chunks.append(
                    {
                        "id": f"{p['id']}#{i}",
                        "page_id": p["id"],
                        "title": p["title"],
                        "text": piece,
                        "vec": [],
                    }
                )
                if len(chunks) >= MAX_CHUNKS:
                    break
            if len(chunks) >= MAX_CHUNKS:
                break

        self._embed_model = await self._detect_embed_model()
        if self._embed_model and chunks:
            vecs = await self._embed([c["text"] for c in chunks])
            if vecs:
                for c, v in zip(chunks, vecs):
                    c["vec"] = [round(x, 5) for x in v]
            else:
                self._embed_model = ""  # 探测到的模型不可用 → 纯 BM25

        self._chunks = chunks
        self._signature = sig
        self._built_at = time.strftime("%Y-%m-%dT%H:%M:%S")
        self._rebuild_bm25()
        self._save_index()
        audit.append(
            "rag_index", chunks=len(chunks), embed_model=self._embed_model or "(bm25)",
            duration_ms=round((time.perf_counter() - start) * 1000),
        )
        logger.info("RAG 索引重建完成：%d chunks，embed=%s", len(chunks), self._embed_model or "纯BM25")

    async def reindex(self) -> dict[str, Any]:
        """强制重建索引（/api/rag/reindex 与设置页入口）。"""
        self._load_index()
        reset_embed_detect()
        async with self._lock:
            from .page_manager import page_manager

            pages = page_manager.iter_page_contents()
            await self._build(pages, self._pages_signature(pages))
            return self.status()

    # --- 检索 ---

    async def search(self, query: str, k: int = 0) -> dict[str, Any]:
        """混合检索。返回 {chunks, confidence, embed_model}。"""
        query = (query or "").strip()
        if not query:
            return {"chunks": [], "confidence": 0.0, "embed_model": self._embed_model}
        await self._ensure_fresh()
        rag_cfg = load_config().get("rag") or {}
        top_k = int(k or rag_cfg.get("top_k") or 8)
        top_n = int(rag_cfg.get("rerank_top_n") or 4)
        rrf_k = float(rag_cfg.get("rrf_k") or 60)
        n = len(self._chunks)

        bm25_hits = self._bm25.search(query, top_k, n)
        rrf: dict[str, float] = {}
        best_bm25 = bm25_hits[0][1] if bm25_hits else 0.0
        vec_hits: list[tuple[int, float]] = []
        if self._embed_model and self._chunks:
            qvec = await self._embed([query])
            if qvec and qvec[0]:
                qv = qvec[0]
                sims = [
                    (i, _cosine(qv, c["vec"]))
                    for i, c in enumerate(self._chunks)
                    if c.get("vec")
                ]
                sims.sort(key=lambda x: x[1], reverse=True)
                vec_hits = sims[:top_k]

        for rank, (idx, _) in enumerate(bm25_hits):
            cid = self._chunks[idx]["id"]
            rrf[cid] = rrf.get(cid, 0.0) + 1.0 / (rrf_k + rank + 1)
        for rank, (idx, _s) in enumerate(vec_hits):
            cid = self._chunks[idx]["id"]
            rrf[cid] = rrf.get(cid, 0.0) + 1.0 / (rrf_k + rank + 1)

        ranked = sorted(rrf.items(), key=lambda x: x[1], reverse=True)[:top_n]
        by_id = {c["id"]: c for c in self._chunks}
        out = []
        for cid, score in ranked:
            c = by_id.get(cid)
            if c:
                out.append(
                    {
                        "id": c["id"],
                        "page_id": c["page_id"],
                        "title": c["title"],
                        "text": c["text"],
                        "score": round(score, 6),
                    }
                )

        # 置信度 = 双路证据取最大：向量用 top1 余弦，纯词法用 BM25 经验归一化
        # （任一路径有强证据即不应拒答；长文档会稀释余弦，BM25 证据可兜底）
        cos_conf = vec_hits[0][1] if vec_hits else 0.0
        bm25_conf = min(1.0, best_bm25 / _BM25_CONF_CAP) if best_bm25 > 0 else 0.0
        confidence = max(cos_conf, bm25_conf)
        audit.append(
            "rag_search", query=audit.digest(query, 120), hits=len(out),
            confidence=round(confidence, 4), embed=self._embed_model or "(bm25)",
        )
        return {
            "chunks": out,
            "confidence": round(confidence, 4),
            "embed_model": self._embed_model,
        }

    async def answer(self, query: str) -> dict[str, Any]:
        """检索 + 引用生成（doc_compose 角色）；低于拒答阈值时不调用模型。"""
        res = await self.search(query)
        threshold = float((load_config().get("rag") or {}).get("refuse_threshold") or 0.35)
        chunks = res["chunks"]
        if res["confidence"] < threshold or not chunks:
            return {
                "answer": "",
                "refused": True,
                "confidence": res["confidence"],
                "sources": [],
                "reason": f"知识库中未找到与「{query[:60]}」足够相关的内容（置信度 {res['confidence']:.2f} < 阈值 {threshold:.2f}）",
            }

        from .model_router import resolve_role

        ctx = "\n\n".join(
            f"[{i + 1}] {c['title']}\n{c['text']}" for i, c in enumerate(chunks)
        )
        prompt = (
            "基于以下知识库片段回答用户问题。要求：引用片段用 [编号] 标注；"
            "片段不足以回答的部分明确说明「知识库中未提及」；不要编造。\n\n"
            f"知识库片段：\n{ctx}\n\n用户问题：{query}"
        )
        try:
            from .llm import complete_chat

            text = await complete_chat(
                [{"role": "user", "content": prompt}], cfg=resolve_role("doc_compose"), role="doc_compose"
            )
        except LLMError as e:
            return {
                "answer": "", "refused": True, "confidence": res["confidence"],
                "sources": [], "reason": f"回答生成失败：{e}",
            }
        return {
            "answer": text,
            "refused": False,
            "confidence": res["confidence"],
            "sources": [{"index": i + 1, "page_id": c["page_id"], "title": c["title"]} for i, c in enumerate(chunks)],
        }

    # --- 状态 ---

    def status(self) -> dict[str, Any]:
        self._load_index()
        return {
            "chunks": len(self._chunks),
            "signature": self._signature,
            "built_at": self._built_at,
            "embed_model": self._embed_model,
            "enabled": bool((load_config().get("rag") or {}).get("enabled", True)),
        }


rag_engine = RagEngine()
