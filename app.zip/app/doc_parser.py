"""文档解析层 SSOT：PDF/Word/Excel/PPT/图片/扫描件 → 文本 + 表格 + 布局 + 结构化数据。

附件上传、RAG 资料库 ingestion、doc_parse 工具共用本模块，避免三套解析逻辑分叉。
引擎（全部 lazy import + fail-open，缺失只记 warning 不抛）：
- PyMuPDF：PDF 文本/表格/布局块/扫描页渲染（单库全覆盖，无需 poppler 等外部二进制）
- RapidOCR：中文 OCR（onnxruntime，模型内置于 wheel），吃图片附件与扫描页渲染图
- python-docx / openpyxl / python-pptx：Office 三件套

输出双份：text 是人/模型读的 Markdown 化拼接；structured 是程序可读取数据
（页 → 块[heading/paragraph/table/ocr，带 bbox]→ 表格单元格矩阵）。
"""
from __future__ import annotations

import io
import logging
import re
from typing import Any

logger = logging.getLogger(__name__)

# 与 page_manager.TEXT_EXTS / IMAGE_EXTS 逐字同值（UI 白名单用后者）；此处自持以避免循环导入
TEXT_EXTS = {
    ".html", ".htm", ".jsx", ".tsx", ".js", ".mjs", ".ts", ".md", ".markdown",
    ".css", ".json", ".xml", ".csv", ".txt", ".svg", ".log", ".yaml", ".yml",
}
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".ico", ".bmp", ".avif"}

_DOC_EXTS = {".pdf": "pdf", ".docx": "docx", ".xlsx": "xlsx", ".pptx": "pptx"}
DOC_EXTS = set(_DOC_EXTS)
PARSEABLE_EXTS = TEXT_EXTS | IMAGE_EXTS | DOC_EXTS

_PARSE_MAX_PAGES = 100     # PDF 页上限
_SCAN_TEXT_MIN = 8         # 页文本去空白低于此字符且含图 → 视为扫描页
_OCR_MAX_PAGES = 20        # 单文档 OCR 页上限（防失控）
_OCR_DPI = 150
_XLSX_MAX_ROWS = 200
_XLSX_MAX_COLS = 30

_OCR: Any = None
_OCR_TRIED = False


def _ocr() -> Any:
    """RapidOCR 单例（首次加载模型约 2-5s）；不可用返回 None 由调用方记 warning。"""
    global _OCR, _OCR_TRIED
    if _OCR_TRIED:
        return _OCR
    _OCR_TRIED = True
    try:
        from rapidocr import RapidOCR

        _OCR = RapidOCR()
    except Exception as e:  # noqa: BLE001 — OCR 缺失不阻断其余解析
        logger.warning("OCR 组件不可用: %s", e)
        _OCR = None
    return _OCR


def _decode_text(data: bytes) -> str:
    # Windows 中文用户的 .txt/.csv 常为 GBK，utf-8 失败时回退
    for enc in ("utf-8", "gbk"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace")


def _cell(v: Any) -> str:
    return re.sub(r"[\s|]+", " ", "" if v is None else str(v)).strip()


def md_table(rows: list[list[str]]) -> str:
    if not rows:
        return ""
    out = ["| " + " | ".join(rows[0]) + " |",
           "| " + " | ".join("---" for _ in rows[0]) + " |"]
    out += ["| " + " | ".join(r) + " |" for r in rows[1:]]
    return "\n".join(out)


def _ocr_ndarray(img: Any, warnings: list[str], label: str) -> tuple[str, list[dict]]:
    ocr = _ocr()
    if ocr is None:
        warnings.append(f"OCR 组件未安装（rapidocr/onnxruntime），{label}内容未解析")
        return "", []
    try:
        res = ocr(img)
    except Exception as e:  # noqa: BLE001 — 单页 OCR 失败不影响其余
        warnings.append(f"{label} OCR 失败：{e}")
        return "", []
    txts = list(getattr(res, "txts", None) or [])
    boxes = getattr(res, "boxes", None)
    scores = list(getattr(res, "scores", None) or [])
    lines: list[str] = []
    blocks: list[dict] = []
    for i, text in enumerate(txts):
        text = (text or "").strip()
        if not text:
            continue
        lines.append(text)
        block: dict[str, Any] = {"type": "ocr", "text": text}
        if i < len(scores):
            block["score"] = round(float(scores[i]), 3)
        if boxes is not None and i < len(boxes):
            pts = [[float(x), float(y)] for x, y in boxes[i]]
            xs = [p[0] for p in pts]
            ys = [p[1] for p in pts]
            block["bbox"] = [round(min(xs), 1), round(min(ys), 1),
                             round(max(xs), 1), round(max(ys), 1)]
        blocks.append(block)
    return "\n".join(lines), blocks


def _ocr_bytes(data: bytes, warnings: list[str], label: str) -> tuple[str, list[dict]]:
    try:
        import cv2
        import numpy as np
    except ImportError as e:
        warnings.append(f"OCR 依赖缺失（opencv/numpy）：{e}")
        return "", []
    arr = np.frombuffer(data, dtype=np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    if img is None:
        raise ValueError("图片解码失败（格式损坏或不受支持）")
    return _ocr_ndarray(img, warnings, label)


# ── 各格式解析器：返回 (text, structured_pages, engine, tables, ocr_pages) ──

def _parse_pdf(data: bytes, warnings: list[str]):
    pages: list[dict] = []
    parts: list[str] = []
    engine = "pymupdf"
    tables_total = 0
    ocr_pages = 0
    try:
        import pymupdf as fitz  # PyMuPDF（fitz 为 deprecated 别名）
    except ImportError:
        fitz = None
        warnings.append("PyMuPDF 未安装，回落 pypdf 纯文本（无表格/布局/OCR）")
        engine = "pypdf"

    if fitz is None:
        try:
            from pypdf import PdfReader
        except ImportError as e:
            raise ValueError("PDF 解析组件未安装（PyMuPDF/pypdf）") from e
        reader = PdfReader(io.BytesIO(data))
        if reader.is_encrypted:
            raise ValueError("PDF 已加密，无法解析")
        for i, page in enumerate(reader.pages[:_PARSE_MAX_PAGES], 1):
            try:
                t = (page.extract_text() or "").strip()
            except Exception:  # noqa: BLE001 — 单页损坏不影响其余页
                t = ""
            pages.append({"index": i, "text": t, "tables": [], "blocks": []})
            parts.append(f"## 第{i}页\n{t}" if t else f"## 第{i}页")
        text = "\n".join(parts)
        return text, pages, engine, 0, 0

    try:
        doc = fitz.open(stream=data, filetype="pdf")
    except Exception as e:  # noqa: BLE001 — 损坏/非 PDF 字节统一转 ValueError
        raise ValueError(f"PDF 无法打开（文件损坏或格式不受支持）：{e}") from e
    try:
        if doc.is_encrypted:
            raise ValueError("PDF 已加密，无法解析")
        for i, page in enumerate(doc, 1):
            if i > _PARSE_MAX_PAGES:
                warnings.append(f"超出 PDF 页上限({_PARSE_MAX_PAGES})，后续页未解析")
                break
            raw = (page.get_text("text") or "").strip()
            blocks: list[dict] = []
            for b in page.get_text("blocks"):
                if b[6] == 0 and (b[4] or "").strip():
                    blocks.append({
                        "type": "paragraph", "text": b[4].strip(),
                        "bbox": [round(v, 1) for v in b[:4]],
                    })
            tables: list[list[list[str]]] = []
            if raw:
                try:
                    for t in page.find_tables().tables:
                        rows = [[_cell(c) for c in row] for row in t.extract()]
                        if rows:
                            tables.append(rows)
                except Exception as e:  # noqa: BLE001 — 表格提取失败不阻断文本
                    warnings.append(f"第{i}页表格提取失败：{e}")
            tables_total += len(tables)

            page_text = raw
            dense = len(re.sub(r"\s", "", raw))
            if dense < _SCAN_TEXT_MIN and page.get_images():
                # 扫描页：无文本层，渲染位图后 OCR
                if ocr_pages < _OCR_MAX_PAGES:
                    pix = page.get_pixmap(dpi=_OCR_DPI)
                    ocr_text, ocr_blocks = _ocr_ndarray(
                        _pix_to_bgr(pix, warnings, f"第{i}页"), warnings, f"第{i}页")
                    if ocr_text:
                        page_text = (page_text + "\n" + ocr_text).strip()
                        blocks.extend(ocr_blocks)
                    ocr_pages += 1
                    engine = "pymupdf+rapidocr"
                else:
                    warnings.append(f"第{i}页为扫描页但超出 OCR 页上限({_OCR_MAX_PAGES})，未解析")

            pg: dict[str, Any] = {"index": i, "text": page_text, "tables": tables, "blocks": blocks}
            pages.append(pg)
            seg = [f"## 第{i}页"]
            if page_text:
                seg.append(page_text)
            seg += [md_table(rows) for rows in tables]
            parts.append("\n".join(seg))
    finally:
        doc.close()
    return "\n".join(parts), pages, engine, tables_total, ocr_pages


def _pix_to_bgr(pix: Any, warnings: list[str], label: str):
    try:
        import cv2
        import numpy as np
    except ImportError as e:
        warnings.append(f"OCR 依赖缺失（opencv/numpy）：{e}")
        return None
    img = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width, pix.n)
    if pix.n == 3:
        return cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
    if pix.n == 4:
        return cv2.cvtColor(img, cv2.COLOR_RGBA2BGR)
    return cv2.cvtColor(img, cv2.COLOR_GRAY2BGR)


def _parse_docx(data: bytes, warnings: list[str]):
    try:
        from docx import Document
    except ImportError as e:
        raise ValueError("Word 解析组件未安装（python-docx）") from e
    doc = Document(io.BytesIO(data))
    blocks: list[dict] = []
    tables: list[list[list[str]]] = []
    parts: list[str] = []
    for p in doc.paragraphs:
        t = (p.text or "").strip()
        if not t:
            continue
        style = (p.style.name or "") if p.style is not None else ""
        m = re.match(r"Heading\s*([1-6])", style) or re.match(r"标题\s*([1-6])", style)
        if m:
            lv = int(m.group(1))
            parts.append("#" * lv + " " + t)
            blocks.append({"type": "heading", "text": t, "level": lv})
        else:
            parts.append(t)
            blocks.append({"type": "paragraph", "text": t})
    for tbl in doc.tables:
        rows = [[_cell(c.text) for c in row.cells] for row in tbl.rows]
        if not rows:
            continue
        tables.append(rows)
        md = md_table(rows)
        parts.append(md)
        blocks.append({"type": "table", "text": md})
    return "\n".join(parts), [{"index": 1, "text": "\n".join(parts), "tables": tables, "blocks": blocks}], \
        "python-docx", len(tables), 0


def _parse_xlsx(data: bytes, warnings: list[str]):
    try:
        from openpyxl import load_workbook
    except ImportError as e:
        raise ValueError("Excel 解析组件未安装（openpyxl）") from e
    wb = load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    pages: list[dict] = []
    parts: list[str] = []
    tables_total = 0
    try:
        for si, ws in enumerate(wb.worksheets, 1):
            rows: list[list[str]] = []
            for ri, row in enumerate(ws.iter_rows(values_only=True)):
                if ri >= _XLSX_MAX_ROWS:
                    warnings.append(f"Sheet「{ws.title}」仅解析前 {_XLSX_MAX_ROWS} 行")
                    break
                rows.append([_cell(v) for v in row[:_XLSX_MAX_COLS]])
            rows = [r for r in rows if any(r)]
            md = md_table(rows) if rows else ""
            tables_total += 1 if rows else 0
            pages.append({
                "index": si, "name": ws.title, "text": md,
                "tables": [rows] if rows else [], "blocks": [],
            })
            parts.append(f"## Sheet: {ws.title}\n{md}" if md else f"## Sheet: {ws.title}")
    finally:
        wb.close()
    return "\n".join(parts), pages, "openpyxl", tables_total, 0


def _parse_pptx(data: bytes, warnings: list[str]):
    try:
        from pptx import Presentation
    except ImportError as e:
        raise ValueError("PPT 解析组件未安装（python-pptx）") from e
    prs = Presentation(io.BytesIO(data))
    pages: list[dict] = []
    parts: list[str] = []
    tables_total = 0
    for i, slide in enumerate(prs.slides, 1):
        blocks: list[dict] = []
        tables: list[list[list[str]]] = []
        lines: list[str] = []
        for shape in slide.shapes:
            if getattr(shape, "has_text_frame", False):
                t = (shape.text_frame.text or "").strip()
                if t:
                    lines.append(t)
                    blocks.append({"type": "paragraph", "text": t})
            if getattr(shape, "has_table", False):
                rows = [[_cell(c.text) for c in row.cells] for row in shape.table.rows]
                if rows:
                    tables.append(rows)
                    md = md_table(rows)
                    lines.append(md)
                    blocks.append({"type": "table", "text": md})
        tables_total += len(tables)
        pages.append({"index": i, "text": "\n".join(lines), "tables": tables, "blocks": blocks})
        parts.append(f"## 第{i}页\n" + "\n".join(lines))
    return "\n".join(parts), pages, "python-pptx", tables_total, 0


def _parse_image(data: bytes, warnings: list[str]):
    text, blocks = _ocr_bytes(data, warnings, "图片")
    pages = [{"index": 1, "text": text, "tables": [], "blocks": blocks}]
    return text, pages, "rapidocr", 0, 1 if text else 0


_PARSERS = {
    "pdf": _parse_pdf, "docx": _parse_docx,
    "xlsx": _parse_xlsx, "pptx": _parse_pptx, "image": _parse_image,
}


def kind_of(ext: str) -> str:
    ext = (ext or "").lower()
    if ext in IMAGE_EXTS:
        return "image"
    return _DOC_EXTS.get(ext, "text")


def parse_bytes(data: bytes, ext: str) -> dict[str, Any]:
    """解析入口（fail-open：组件缺失/单页失败记 warnings，整体损坏才抛 ValueError）。"""
    if not data:
        raise ValueError("文件内容为空")
    kind = kind_of(ext)
    warnings: list[str] = []
    if kind == "text":
        text = _decode_text(data)
        return {
            "text": text,
            "structured": {"format": (ext or "").lower(), "chars": len(text),
                           "engine": "text", "tables": 0, "ocr_pages": 0,
                           "pages": [{"index": 1, "text": text, "tables": [], "blocks": []}]},
            "engine": "text", "warnings": warnings, "tables": 0, "ocr_pages": 0,
        }
    text, pages, engine, tables, ocr_pages = _PARSERS[kind](data, warnings)
    text = (text or "").strip()
    return {
        "text": text,
        "structured": {"format": (ext or "").lower(), "chars": len(text), "engine": engine,
                       "tables": tables, "ocr_pages": ocr_pages, "pages": pages},
        "engine": engine, "warnings": warnings, "tables": tables, "ocr_pages": ocr_pages,
    }
