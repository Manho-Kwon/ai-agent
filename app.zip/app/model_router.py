"""LiteLLM 式抽象层：按角色分离模型（planner / executor / evaluator / memory）。

- default provider = config.json llm 节 + .env 覆盖（密钥 SSOT 不变）
- 命名 provider 在 config.json providers 声明：{base_url, api_key_env, model?}
  密钥只存环境变量名（api_key_env），不存明文
- roles.<role> = {provider?, model?, temperature?, max_tokens?}，空值逐级回退
- 解析失败/未声明 → 回退 default，保证管道永远有可用配置
"""
from __future__ import annotations

import logging
import os
from typing import Any

from .config import api_key, llm_settings, load_config, normalize_base_url

logger = logging.getLogger(__name__)

ROLES = (
    "planner",
    "executor",
    "executor_recovery",  # 工具连续失败 / 模型报错后的后备执行者
    "evaluator",
    "memory",
    "doc_compose",
    "doc_parse",
    "multimodal",
)


def resolve_role(role: str) -> dict[str, Any]:
    """解析角色 → 生效的 LLM 连接配置 {base_url, model, temperature, max_tokens, api_key}。"""
    cfg = load_config()
    base_llm = llm_settings()
    base_url = base_llm["base_url"]
    model = base_llm["model"]
    key = api_key()
    temperature = base_llm["temperature"]
    max_tokens = base_llm["max_tokens"]

    roles = cfg.get("roles") or {}
    spec = roles.get(role) or {}
    prov_name = str(spec.get("provider") or "default")
    if prov_name != "default":
        prov = (cfg.get("providers") or {}).get(prov_name)
        if isinstance(prov, dict):
            if prov.get("base_url"):
                base_url = str(prov["base_url"])
            env_name = str(prov.get("api_key_env") or "").strip()
            if env_name:
                env_key = os.getenv(env_name, "").strip()
                if env_key:
                    key = env_key
                else:
                    logger.warning("provider '%s' 的 api_key_env=%s 未设置，回退默认密钥", prov_name, env_name)
            if prov.get("model"):
                model = str(prov["model"])
        else:
            logger.warning("roles.%s 引用了未声明的 provider '%s'，回退 default", role, prov_name)

    if spec.get("model"):
        model = str(spec["model"])
    if spec.get("temperature") is not None:
        try:
            temperature = float(spec["temperature"])
        except (TypeError, ValueError):
            pass
    if spec.get("max_tokens"):
        try:
            max_tokens = int(spec["max_tokens"])
        except (TypeError, ValueError):
            pass

    return {
        "base_url": normalize_base_url(base_url),
        "model": model,
        "temperature": temperature,
        "max_tokens": max_tokens,
        "api_key": key,
        # 降级档（llm.py 重试耗尽后换档再试一次）：取全局 llm.fallback_model
        "fallback_model": (cfg.get("llm") or {}).get("fallback_model") or "",
    }


def describe() -> dict[str, Any]:
    """当前角色→模型映射（UI/调试用，不含密钥）。"""
    out: dict[str, Any] = {}
    for role in ROLES:
        c = resolve_role(role)
        out[role] = {
            "base_url": c["base_url"],
            "model": c["model"] or "(未配置)",
            "provider": (load_config().get("roles") or {}).get(role, {}).get("provider", "default"),
        }
    return out