"""工作区管理：本地目录注册表 + 索引统计 + 每日文件更改检查。

存储 data/workspaces.json：{workspaces: {id: {...}}, meta: {last_sync, daily, last_daily_check}}。

统计口径（真实扫描，非模拟）：
- 可检索文档：工作区目录下受支持文本文件的个数（扫描上限保护）
- 索引段落：抽样读取文件的非空行数（抽样上限保护）
- 等待内容同步：mtime 晚于上次同步时间的文件数
- 监视器：本裁剪版无文件 watcher → 常为「未运行」
- 语义缓存 / 重排器 / 搜索延迟：功能未启用 → 已禁用、零值
"""
from __future__ import annotations

import asyncio
import logging
import os
import threading
import uuid
from datetime import datetime
from pathlib import Path
from typing import Any

from .config import WORKSPACES_PATH

logger = logging.getLogger(__name__)
_lock = threading.Lock()

# 扫描保护上限
_MAX_FILES_PER_WS = 2000        # 每工作区最多统计的文件数
_MAX_PARA_FILES = 500           # 最多抽样读取的文件数
_MAX_FILE_BYTES = 256 * 1024    # 抽样读取单文件的最大字节数

# 受支持的文本扩展名（可检索文档）
TEXT_EXTS = {
    ".md", ".markdown", ".txt", ".html", ".htm", ".json", ".csv", ".xml",
    ".js", ".mjs", ".ts", ".jsx", ".tsx", ".py", ".css", ".yaml", ".yml",
    ".log", ".svg", ".ini", ".toml",
}
# 扫描时跳过的目录名
SKIP_DIRS = {
    ".git", "node_modules", "__pycache__", ".venv", "venv", "dist", "build",
    ".idea", ".vs", ".vscode", ".next", ".cache", "target", ".gradle",
}


def _now_iso() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


class WorkspaceManager:
    def __init__(self) -> None:
        self._data: dict[str, Any] = {"workspaces": {}, "meta": {}}
        self._loaded = False
        self._daily_task: asyncio.Task | None = None

    # ── 存取 ──────────────────────────────────────────────────

    def _load(self) -> None:
        if self._loaded:
            return
        try:
            import json

            data = json.loads(WORKSPACES_PATH.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                self._data = {
                    "workspaces": data.get("workspaces") or {},
                    "meta": data.get("meta") or {},
                }
        except (OSError, ValueError):
            self._data = {"workspaces": {}, "meta": {}}
        self._loaded = True

    def _save(self) -> None:
        import json

        WORKSPACES_PATH.write_text(
            json.dumps(self._data, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )

    def _meta(self) -> dict[str, Any]:
        return self._data.setdefault("meta", {})

    # ── 注册表 CRUD ───────────────────────────────────────────

    def list(self) -> list[dict[str, Any]]:
        with _lock:
            self._load()
            items = sorted(
                self._data["workspaces"].values(),
                key=lambda w: w.get("created_at", ""),
            )
            return [dict(w) for w in items]

    def get(self, ws_id: str) -> dict[str, Any] | None:
        with _lock:
            self._load()
            w = self._data["workspaces"].get(ws_id)
            return dict(w) if w else None

    def create(self, name: str, path: str, description: str = "") -> dict[str, Any]:
        name = (name or "").strip()
        path = (path or "").strip().strip('"')
        if not name:
            raise ValueError("请填写工作区名称")
        if len(name) > 80:
            raise ValueError("工作区名称不能超过 80 个字符")
        if not path:
            raise ValueError("请填写目录路径")
        p = Path(path).expanduser()
        if not p.is_absolute():
            raise ValueError("目录路径必须是绝对路径（例如 C:\\Users\\you\\projects\\my-app）")
        if not p.exists():
            raise ValueError(f"目录不存在：{path}")
        if not p.is_dir():
            raise ValueError(f"该路径不是文件夹：{path}")
        p = p.resolve()
        with _lock:
            self._load()
            for w in self._data["workspaces"].values():
                if Path(w["path"]) == p:
                    raise ValueError(f"该目录已注册为工作区「{w['name']}」")
            now = _now_iso()
            rec = {
                "id": uuid.uuid4().hex[:8],
                "name": name,
                "path": str(p),
                "description": (description or "").strip()[:500],
                "created_at": now,
                "updated_at": now,
            }
            self._data["workspaces"][rec["id"]] = rec
            self._save()
            return dict(rec)

    def delete(self, ws_id: str) -> bool:
        with _lock:
            self._load()
            if ws_id not in self._data["workspaces"]:
                return False
            del self._data["workspaces"][ws_id]
            self._save()
            return True

    # ── 统计 / 同步 ───────────────────────────────────────────

    def _scan_workspace(self, root: Path, since_ts: float) -> dict[str, int]:
        docs = paragraphs = pending = 0
        para_files = 0
        count = 0
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
            for fn in filenames:
                if count >= _MAX_FILES_PER_WS:
                    return {"docs": docs, "paragraphs": paragraphs, "pending": pending}
                fpath = Path(dirpath) / fn
                count += 1
                try:
                    st = fpath.stat()
                except OSError:
                    continue
                if st.st_mtime > since_ts:
                    pending += 1
                if fpath.suffix.lower() not in TEXT_EXTS:
                    continue
                docs += 1
                if para_files >= _MAX_PARA_FILES or st.st_size > _MAX_FILE_BYTES:
                    continue
                para_files += 1
                try:
                    with open(fpath, "r", encoding="utf-8", errors="replace") as f:
                        paragraphs += sum(1 for line in f if line.strip())
                except OSError:
                    pass
        return {"docs": docs, "paragraphs": paragraphs, "pending": pending}

    def sync(self) -> dict[str, Any]:
        """重新扫描全部工作区并刷新统计快照（同步文件更改按钮 / 每日检查）。"""
        with _lock:
            self._load()
            last_sync = self._meta().get("last_sync")
            since_ts = 0.0
            if last_sync:
                try:
                    since_ts = datetime.fromisoformat(last_sync).timestamp()
                except ValueError:
                    since_ts = 0.0
            docs = paragraphs = pending = 0
            for w in self._data["workspaces"].values():
                try:
                    r = self._scan_workspace(Path(w["path"]), since_ts)
                except OSError as e:
                    logger.warning("工作区扫描失败 %s: %s", w["path"], e)
                    continue
                docs += r["docs"]
                paragraphs += r["paragraphs"]
                pending += r["pending"]
            now = _now_iso()
            self._meta()["last_sync"] = now
            self._meta()["stats"] = {
                "documents": docs, "paragraphs": paragraphs, "pending_sync": pending,
            }
            self._save()
        return self.stats()

    def stats(self) -> dict[str, Any]:
        with _lock:
            self._load()
            meta = self._meta()
            cached = meta.get("stats") or {
                "documents": 0, "paragraphs": 0, "pending_sync": 0,
            }
            daily = meta.get("daily") or {"enabled": False, "hour": 3, "minute": 0}
            return {
                "workspace_count": len(self._data["workspaces"]),
                "documents": cached.get("documents", 0),
                "paragraphs": cached.get("paragraphs", 0),
                "pending_sync": cached.get("pending_sync", 0),
                # 裁剪版无转换管道：无失败任务
                "retryable": 0,
                "failed": 0,
                "monitor": "未运行",
                "last_file_event": None,
                "last_sync": meta.get("last_sync") or None,
                "schema": "SQLite v2 · schema 2",
                "daily": {
                    "enabled": bool(daily.get("enabled", False)),
                    "hour": int(daily.get("hour", 3)),
                    "minute": int(daily.get("minute", 0)),
                    "last_run": meta.get("last_daily_check") or None,
                },
                "search": {
                    "ready": True,
                    "p50": None, "p95": None, "samples": 0, "last_search": None,
                },
                "semantic_cache": {
                    "enabled": False, "model": None,
                    "latest": 0, "total": 0, "hit_rate": "0%",
                },
                "reranker": {
                    "enabled": False, "mode": "auto",
                    "recent_ms": 0, "p95_ms": None,
                },
            }

    def retry_failed(self) -> dict[str, Any]:
        """裁剪版无转换管道，失败任务恒为 0；保留接口与 UI 闭环。"""
        return {"ok": True, "retried": 0, "message": "当前没有失败任务"}

    # ── 每日文件更改检查 ──────────────────────────────────────

    def set_daily_config(self, enabled: bool, hour: int, minute: int) -> dict[str, Any]:
        if not (0 <= hour <= 23 and 0 <= minute <= 59):
            raise ValueError("时间不合法：小时 0-23，分钟 0-59")
        with _lock:
            self._load()
            self._meta()["daily"] = {
                "enabled": bool(enabled), "hour": int(hour), "minute": int(minute),
            }
            self._save()
            return dict(self._meta()["daily"])

    def start_daily_loop(self) -> None:
        if self._daily_task is None or self._daily_task.done():
            self._daily_task = asyncio.create_task(self._daily_loop(), name="ws-daily-check")

    async def stop_daily_loop(self) -> None:
        if self._daily_task is not None:
            self._daily_task.cancel()
            try:
                await self._daily_task
            except (asyncio.CancelledError, Exception):
                pass
            self._daily_task = None

    async def _daily_loop(self) -> None:
        """每 30s 检查一次：到达每日设定时间且今天未跑过 → 执行同步。"""
        while True:
            try:
                with _lock:
                    self._load()
                    daily = self._meta().get("daily") or {}
                    enabled = bool(daily.get("enabled"))
                    hour, minute = daily.get("hour", 3), daily.get("minute", 0)
                    last_run = self._meta().get("last_daily_check")
                if enabled:
                    now = datetime.now()
                    today = now.date().isoformat()
                    ran_today = bool(last_run and last_run[:10] == today)
                    if (
                        not ran_today
                        and now.hour == hour and now.minute == minute
                    ):
                        logger.info("工作区每日文件更改检查触发（%02d:%02d）", hour, minute)
                        await asyncio.to_thread(self.sync)
                        with _lock:
                            self._load()
                            self._meta()["last_daily_check"] = _now_iso()
                            self._save()
            except (OSError, ValueError) as e:
                logger.warning("每日检查异常: %s", e)
            await asyncio.sleep(30)

    # ── 目录浏览（添加工作区的文件夹按钮） ────────────────────

    def browse(self, path: str = "") -> dict[str, Any]:
        raw = (path or "").strip()
        if not raw:
            raw = str(Path.home())
        p = Path(raw).expanduser()
        if not p.exists():
            raise ValueError(f"路径不存在：{raw}")
        if not p.is_dir():
            raise ValueError(f"该路径不是文件夹：{raw}")
        p = p.resolve()
        dirs: list[dict[str, str]] = []
        try:
            for child in sorted(p.iterdir(), key=lambda c: c.name.lower()):
                if child.is_dir():
                    dirs.append({"name": child.name, "path": str(child)})
        except (OSError, PermissionError):
            pass  # 无权限目录返回空列表
        parent = str(p.parent) if p.parent != p else None
        return {"current": str(p), "parent": parent, "dirs": dirs}


workspace_manager = WorkspaceManager()
