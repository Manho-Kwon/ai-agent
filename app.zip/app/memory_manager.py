"""Memory Manager：长期记忆存储 / 检索 / 自动抽取（对齐原版 memory_manager.py 裁剪版）。

- 存储：data/memories.json {memories: [{id, content, tags, source, created_at}]}
- 检索：英文词 + 中文二元组 token 重叠打分（无外部依赖，离线可用）
- 抽取：回合结束后由 memory 角色模型抽取 0-3 条长期事实（fail-open，失败不阻断对话）
"""
from __future__ import annotations

import json
import logging
import re
import threading
import uuid
from datetime import datetime, timezone
from typing import Any

from .config import MEMORIES_PATH, load_config

logger = logging.getLogger(__name__)

_lock = threading.Lock()
_TOKEN_RE = re.compile(r"[A-Za-z0-9_]{2,}|[一-鿿]{2,}")


def _now() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def _tokens(text: str) -> set[str]:
    toks: set[str] = set()
    for m in _TOKEN_RE.finditer(text or ""):
        w = m.group(0)
        if w.isascii():
            toks.add(w.lower())
        else:
            for i in range(len(w) - 1):
                toks.add(w[i : i + 2])
    return toks


class MemoryManager:
    def __init__(self) -> None:
        self._memories: list[dict[str, Any]] = []
        self._loaded = False

    def _load(self) -> None:
        if self._loaded:
            return
        try:
            data = json.loads(MEMORIES_PATH.read_text(encoding="utf-8"))
            self._memories = [m for m in data.get("memories", []) if isinstance(m, dict)]
        except (json.JSONDecodeError, OSError):
            self._memories = []
        self._loaded = True

    def _save(self) -> None:
        MEMORIES_PATH.write_text(
            json.dumps({"memories": self._memories}, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )

    def _enforce_cap(self) -> None:
        cap = int(load_config()["memory"].get("max_items", 200))
        if len(self._memories) <= cap:
            return
        # 优先淘汰最早的自动抽取条目；仍超额时再淘汰最早的手动条目
        auto = sorted(
            (m for m in self._memories if m.get("source") == "auto"),
            key=lambda m: m.get("created_at", ""),
        )
        drop = len(self._memories) - cap
        drop_ids = {m["id"] for m in auto[:drop]}
        if len(drop_ids) < drop:
            manual = sorted(
                (m for m in self._memories if m.get("source") != "auto"),
                key=lambda m: m.get("created_at", ""),
            )
            still = drop - len(drop_ids)
            drop_ids |= {m["id"] for m in manual[:still]}
        self._memories = [m for m in self._memories if m["id"] not in drop_ids]

    # --- CRUD ---

    def add(self, content: str, tags: list[str] | None = None, source: str = "manual") -> dict[str, Any]:
        content = (content or "").strip()
        if not content:
            raise ValueError("记忆内容不能为空")
        with _lock:
            self._load()
            for m in self._memories:  # 内容去重（幂等保存）
                if m.get("content") == content[:500]:
                    return m
        item = {
            "id": uuid.uuid4().hex[:12],
            "content": content[:500],
            "tags": [str(t).strip() for t in (tags or []) if str(t).strip()][:8],
            "source": source,
            "created_at": _now(),
        }
        with _lock:
            self._load()
            self._memories.append(item)
            self._enforce_cap()
            self._save()
        return item

    def list(self) -> list[dict[str, Any]]:
        with _lock:
            self._load()
            return sorted(self._memories, key=lambda m: m.get("created_at", ""), reverse=True)

    def delete(self, memory_id: str) -> bool:
        with _lock:
            self._load()
            before = len(self._memories)
            self._memories = [m for m in self._memories if m.get("id") != memory_id]
            if len(self._memories) != before:
                self._save()
                return True
            return False

    # --- 检索（P3 注入） ---

    def retrieve(self, query: str, k: int | None = None) -> list[dict[str, Any]]:
        cfg = load_config()["memory"]
        k = k or int(cfg.get("inject_top_k", 5))
        q = _tokens(query)
        if not q:
            return []
        scored = []
        with _lock:
            self._load()
            for m in self._memories:
                t = _tokens(f"{m.get('content', '')} {' '.join(m.get('tags', []))}")
                score = len(q & t)
                if score > 0:
                    scored.append((score, m))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [m for _, m in scored[:k]]

    # --- 自动抽取（回合后后台调用，fail-open） ---

    async def auto_extract(self, user_text: str, assistant_text: str) -> int:
        from .llm import LLMError, complete_chat
        from .model_router import resolve_role

        cfg = load_config()["memory"]
        if not cfg.get("enabled", True) or not cfg.get("auto_extract", True):
            return 0
        if not (user_text or "").strip() or not (assistant_text or "").strip():
            return 0
        prompt = [
            {
                "role": "system",
                "content": (
                    "你是记忆抽取引擎。从对话中提取关于用户的长期有价值的事实/偏好/约定"
                    "（0-3 条，每条 ≤40 字，禁止临时性内容）。只输出 JSON 字符串数组，例如 "
                    '["用户偏好中文回答"]；没有则输出 []。'
                ),
            },
            {
                "role": "user",
                "content": f"用户：{user_text[:800]}\n助手：{assistant_text[:1500]}",
            },
        ]
        try:
            raw = await complete_chat(prompt, cfg=resolve_role("memory"), role="memory")
        except LLMError as e:
            logger.warning("记忆自动抽取跳过（LLM 不可用）: %s", e)
            return 0
        except Exception as e:  # noqa: BLE001 — 抽取失败绝不影响主链路
            logger.warning("记忆自动抽取异常: %s", e)
            return 0
        facts = _parse_string_array(raw)
        added = 0
        for fact in facts:
            try:
                self.add(fact, tags=["auto"], source="auto")
                added += 1
            except ValueError:
                continue
        if added:
            logger.info("自动抽取记忆 %d 条", added)
        return added


def _parse_string_array(raw: str) -> list[str]:
    raw = (raw or "").strip()
    start = raw.find("[")
    end = raw.rfind("]")
    if start < 0 or end <= start:
        return []
    try:
        data = json.loads(raw[start : end + 1])
    except json.JSONDecodeError:
        return []
    if not isinstance(data, list):
        return []
    return [str(x).strip() for x in data if str(x or "").strip()][:3]


memory_manager = MemoryManager()