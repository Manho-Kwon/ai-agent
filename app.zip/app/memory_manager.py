"""Memory Manager：长期记忆存储 / 检索 / 自动抽取（对齐原版 memory_manager.py 裁剪版）。

- 存储：data/memories.json {memories: [{id, content, tags, source, created_at, updated_at?}]}
- 检索：英文词 + 中文二元组 token 重叠打分（无外部依赖，离线可用）；
  retrieve_hybrid 在此基础上叠加向量余弦（复用 rag 的 embedding 探测，失败自动退化纯词法）
- 抽取：回合结束后由 memory 角色模型抽取 0-3 条长期事实（fail-open，失败不阻断对话）；
  与既有记忆矛盾时输出 replace 指向旧 id，替换而非并存（ch3 记忆更新）
"""
from __future__ import annotations

import json
import logging
import re
import threading
import uuid
from datetime import datetime, timezone
from typing import Any

from .config import MEMORIES_PATH, load_config

logger = logging.getLogger(__name__)

_lock = threading.Lock()
_TOKEN_RE = re.compile(r"[A-Za-z0-9_]{2,}|[一-鿿]{2,}")


def _now() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


def _tokens(text: str) -> set[str]:
    toks: set[str] = set()
    for m in _TOKEN_RE.finditer(text or ""):
        w = m.group(0)
        if w.isascii():
            toks.add(w.lower())
        else:
            for i in range(len(w) - 1):
                toks.add(w[i : i + 2])
    return toks


class MemoryManager:
    def __init__(self) -> None:
        self._memories: list[dict[str, Any]] = []
        self._loaded = False
        self._vec_cache: dict[str, tuple[str, list[float]]] = {}  # id -> (content, vector)

    def _load(self) -> None:
        if self._loaded:
            return
        try:
            data = json.loads(MEMORIES_PATH.read_text(encoding="utf-8"))
            self._memories = [m for m in data.get("memories", []) if isinstance(m, dict)]
        except (json.JSONDecodeError, OSError):
            self._memories = []
        self._loaded = True

    def _save(self) -> None:
        MEMORIES_PATH.write_text(
            json.dumps({"memories": self._memories}, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )

    def _enforce_cap(self) -> None:
        cap = int(load_config()["memory"].get("max_items", 200))
        if len(self._memories) <= cap:
            return
        # 优先淘汰最早的自动抽取条目；仍超额时再淘汰最早的手动条目
        auto = sorted(
            (m for m in self._memories if m.get("source") == "auto"),
            key=lambda m: m.get("created_at", ""),
        )
        drop = len(self._memories) - cap
        drop_ids = {m["id"] for m in auto[:drop]}
        if len(drop_ids) < drop:
            manual = sorted(
                (m for m in self._memories if m.get("source") != "auto"),
                key=lambda m: m.get("created_at", ""),
            )
            still = drop - len(drop_ids)
            drop_ids |= {m["id"] for m in manual[:still]}
        self._memories = [m for m in self._memories if m["id"] not in drop_ids]

    # --- CRUD ---

    def add(
        self,
        content: str,
        tags: list[str] | None = None,
        source: str = "manual",
        supersedes: str | None = None,
    ) -> dict[str, Any]:
        content = (content or "").strip()
        if not content:
            raise ValueError("记忆内容不能为空")
        with _lock:
            self._load()
            if supersedes:  # 记忆更新：替换矛盾旧条目而非并存（ch3）
                for m in self._memories:
                    if m.get("id") == supersedes:
                        m["content"] = content[:500]
                        m["tags"] = [
                            str(t).strip() for t in (tags or m.get("tags") or []) if str(t).strip()
                        ][:8]
                        m["source"] = source
                        m["updated_at"] = _now()
                        self._vec_cache.pop(m["id"], None)  # 内容变了，向量缓存失效
                        self._save()
                        return m
            for m in self._memories:  # 内容去重（幂等保存）
                if m.get("content") == content[:500]:
                    return m
        item = {
            "id": uuid.uuid4().hex[:12],
            "content": content[:500],
            "tags": [str(t).strip() for t in (tags or []) if str(t).strip()][:8],
            "source": source,
            "created_at": _now(),
        }
        with _lock:
            self._load()
            self._memories.append(item)
            self._enforce_cap()
            self._save()
        return item

    def list(self) -> list[dict[str, Any]]:
        with _lock:
            self._load()
            return sorted(self._memories, key=lambda m: m.get("created_at", ""), reverse=True)

    def delete(self, memory_id: str) -> bool:
        with _lock:
            self._load()
            before = len(self._memories)
            self._memories = [m for m in self._memories if m.get("id") != memory_id]
            if len(self._memories) != before:
                self._save()
                return True
            return False

    # --- 检索（P3 注入） ---

    def _lexical(self, query: str) -> list[tuple[float, dict[str, Any]]]:
        """词法检索：token 重叠计分，返回（降序）[(score, memory)]。"""
        q = _tokens(query)
        if not q:
            return []
        scored: list[tuple[float, dict[str, Any]]] = []
        with _lock:
            self._load()
            for m in self._memories:
                t = _tokens(f"{m.get('content', '')} {' '.join(m.get('tags', []))}")
                score = len(q & t)
                if score > 0:
                    scored.append((float(score), m))
        scored.sort(key=lambda x: x[0], reverse=True)
        return scored

    def retrieve(self, query: str, k: int | None = None) -> list[dict[str, Any]]:
        cfg = load_config()["memory"]
        k = k or int(cfg.get("inject_top_k", 5))
        return [m for _, m in self._lexical(query)[:k]]

    async def retrieve_hybrid(self, query: str, k: int | None = None) -> list[dict[str, Any]]:
        """混合检索：词法重叠 + 向量余弦（ch3）。

        embedding 探测/调用失败时退化为纯词法（fail-open），永不阻断主链路。
        记忆向量按 (content, vector) 缓存，内容变更自动失效。
        """
        cfg = load_config()["memory"]
        k = k or int(cfg.get("inject_top_k", 5))
        if not (query or "").strip():
            return []
        lexical = self._lexical(query)
        try:
            from .llm import embed_texts
            from .rag import _cosine, detect_embed_model

            model = await detect_embed_model()
            if not model:
                return [m for _, m in lexical[:k]]
            with _lock:
                self._load()
                items = list(self._memories)
            stale = [
                m
                for m in items
                if self._vec_cache.get(m["id"], ("", []))[0] != m.get("content", "")
            ]
            if stale:
                vecs = await embed_texts([m.get("content", "") for m in stale], model=model)
                for m, v in zip(stale, vecs):
                    self._vec_cache[m["id"]] = (m.get("content", ""), v)
            qvec = (await embed_texts([query], model=model))[0]
            scores: dict[str, float] = {m["id"]: s for s, m in lexical}
            by_id: dict[str, dict[str, Any]] = {m["id"]: m for _, m in lexical}
            for m in items:
                cvec = self._vec_cache.get(m["id"], ("", []))[1]
                if not cvec:
                    continue
                cos = max(_cosine(qvec, cvec), 0.0)
                if cos > 0:
                    scores[m["id"]] = scores.get(m["id"], 0.0) + 4.0 * cos
                    by_id[m["id"]] = m
            ranked = sorted(scores.items(), key=lambda kv: kv[1], reverse=True)
            return [by_id[mid] for mid, s in ranked[:k] if s > 0]
        except Exception as e:  # noqa: BLE001 — 检索失败退化词法，绝不影响主链路
            logger.warning("记忆向量检索退化为纯词法：%s", e)
            return [m for _, m in lexical[:k]]

    # --- 自动抽取（回合后后台调用，fail-open） ---

    async def auto_extract(self, user_text: str, assistant_text: str) -> int:
        from .llm import LLMError, complete_chat
        from .model_router import resolve_role

        cfg = load_config()["memory"]
        if not cfg.get("enabled", True) or not cfg.get("auto_extract", True):
            return 0
        if not (user_text or "").strip() or not (assistant_text or "").strip():
            return 0
        related = self.retrieve(user_text, k=8)
        existing = "\n".join(f"- id={m['id']}：{m['content']}" for m in related) or "（无）"
        prompt = [
            {
                "role": "system",
                "content": (
                    "你是记忆抽取引擎。从对话中提取关于用户的长期有价值的事实/偏好/约定"
                    "（0-3 条，每条 ≤40 字，禁止临时性内容）。输出 JSON 数组：元素为普通字符串，"
                    "或 {\"content\": \"新事实\", \"replace\": \"旧记忆id\"}——当新事实与"
                    "「既有记忆」中某条矛盾或取代它时，必须用 replace 指明被取代的旧 id，"
                    "不要让矛盾记忆并存；不能对应到既有记忆的就用普通字符串。没有则输出 []。"
                ),
            },
            {
                "role": "user",
                "content": (
                    f"既有记忆：\n{existing}\n\n用户：{user_text[:800]}\n助手：{assistant_text[:1500]}"
                ),
            },
        ]
        try:
            raw = await complete_chat(prompt, cfg=resolve_role("memory"), role="memory")
        except LLMError as e:
            logger.warning("记忆自动抽取跳过（LLM 不可用）: %s", e)
            return 0
        except Exception as e:  # noqa: BLE001 — 抽取失败绝不影响主链路
            logger.warning("记忆自动抽取异常: %s", e)
            return 0
        facts = _parse_facts(raw)
        added = 0
        for fact in facts:
            try:
                self.add(
                    fact["content"],
                    tags=["auto"],
                    source="auto",
                    supersedes=fact.get("replace"),
                )
                added += 1
            except ValueError:
                continue
        if added:
            logger.info("自动抽取记忆 %d 条", added)
        return added


def _parse_facts(raw: str) -> list[dict[str, str]]:
    """解析抽取输出：JSON 数组，元素为字符串或 {content, replace?}。"""
    raw = (raw or "").strip()
    start = raw.find("[")
    end = raw.rfind("]")
    if start < 0 or end <= start:
        return []
    try:
        data = json.loads(raw[start : end + 1])
    except json.JSONDecodeError:
        return []
    if not isinstance(data, list):
        return []
    out: list[dict[str, str]] = []
    for x in data:
        if isinstance(x, dict):
            content = str(x.get("content") or "").strip()
            if not content:
                continue
            item: dict[str, str] = {"content": content}
            rep = str(x.get("replace") or "").strip()
            if rep:
                item["replace"] = rep
            out.append(item)
        else:
            s = str(x or "").strip()
            if s:
                out.append({"content": s})
        if len(out) >= 3:
            break
    return out


memory_manager = MemoryManager()