"""多会话与消息持久化（对齐原版 session_manager.py 裁剪版）。

存储布局：
- data/sessions.json          会话元数据 {sessions: {id: {...}}}
- data/sessions/<id>.json     消息数组
消息形态面向 UI：user / assistant（assistant 附 tool_trace 工具痕迹）；
发给 LLM 时由 prepare_thread() 展开成 OpenAI 协议格式。
"""
from __future__ import annotations

import json
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path

from .config import SESSIONS_DIR, SESSIONS_PATH, load_config

# 未命名会话的占位标题，同时是 orchestrator._auto_title 的触发条件（标题仍等于它才自动概括）
DEFAULT_TITLE = "新会话"


def _now() -> str:
    return datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")


class SessionManager:
    def __init__(self) -> None:
        self._sessions: dict[str, dict] = {}
        self._lock = threading.Lock()

    def load(self) -> None:
        with self._lock:
            try:
                data = json.loads(SESSIONS_PATH.read_text(encoding="utf-8"))
                self._sessions = data.get("sessions", {})
            except (json.JSONDecodeError, OSError):
                self._sessions = {}

    def _save_meta(self) -> None:
        SESSIONS_PATH.write_text(
            json.dumps({"sessions": self._sessions}, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )

    def _messages_path(self, session_id: str) -> Path:
        return SESSIONS_DIR / f"{session_id}.json"

    # --- 元数据 ---

    def create_session(self, title: str = "") -> dict:
        sid = uuid.uuid4().hex[:12]
        now = _now()
        meta = {
            "id": sid,
            "title": title.strip() or DEFAULT_TITLE,
            "created_at": now,
            "updated_at": now,
            "message_count": 0,
            "preview": "",
        }
        with self._lock:
            self._sessions[sid] = meta
            self._save_meta()
            self._messages_path(sid).write_text("[]\n", encoding="utf-8")
        return dict(meta)

    def list_sessions(self) -> list[dict]:
        with self._lock:
            items = sorted(
                (dict(v) for v in self._sessions.values()),
                key=lambda s: s["updated_at"],
                reverse=True,
            )
        return items

    def get_session(self, session_id: str) -> dict | None:
        with self._lock:
            meta = self._sessions.get(session_id)
            return dict(meta) if meta else None

    def update_title(self, session_id: str, title: str) -> dict | None:
        with self._lock:
            meta = self._sessions.get(session_id)
            if not meta:
                return None
            meta["title"] = title.strip() or meta["title"]
            self._save_meta()
            return meta

    def delete_session(self, session_id: str) -> bool:
        with self._lock:
            if session_id not in self._sessions:
                return False
            del self._sessions[session_id]
            self._save_meta()
        path = self._messages_path(session_id)
        if path.exists():
            path.unlink()
        from . import attachments  # 局部导入避免潜在循环依赖
        attachments.delete_session_attachments(session_id)
        return True

    # --- 消息 ---

    def get_messages(self, session_id: str) -> list[dict]:
        path = self._messages_path(session_id)
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return []

    def append_messages(self, session_id: str, messages: list[dict]) -> None:
        """追加消息并刷新元数据（预览取第一条用户消息前 60 字）。"""
        with self._lock:
            meta = self._sessions.get(session_id)
            if not meta:
                raise ValueError(f"session not found: {session_id}")
            path = self._messages_path(session_id)
            try:
                msgs = json.loads(path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                msgs = []
            stamped = []
            for m in messages:
                item = dict(m)
                item.setdefault("id", uuid.uuid4().hex[:12])
                item.setdefault("timestamp", _now())
                stamped.append(item)
            msgs.extend(stamped)
            path.write_text(
                json.dumps(msgs, indent=2, ensure_ascii=False) + "\n",
                encoding="utf-8",
            )
            meta["message_count"] = len(msgs)
            meta["updated_at"] = _now()
            for m in stamped:
                if m.get("role") == "user" and not meta["preview"]:
                    text = m.get("content") or ""
                    meta["preview"] = text[:60]
            self._save_meta()


session_manager = SessionManager()


def _expand_tool_trace(messages: list[dict]) -> list[dict]:
    """UI 消息 → OpenAI 协议消息：assistant.tool_trace 展开为 tool_calls + tool 消息。"""
    out: list[dict] = []
    for m in messages:
        role = m.get("role")
        if role == "assistant":
            trace = m.get("tool_trace") or []
            if trace:
                out.append({
                    "role": "assistant",
                    "content": m.get("content") or "",
                    "tool_calls": [
                        {
                            "id": t["id"],
                            "type": "function",
                            "function": {
                                "name": f"{t['server']}__{t['tool']}",
                                "arguments": json.dumps(
                                    t.get("arguments") or {}, ensure_ascii=False
                                ),
                            },
                        }
                        for t in trace
                    ],
                })
                for t in trace:
                    out.append({
                        "role": "tool",
                        "tool_call_id": t["id"],
                        "content": (t.get("content") or "")[:8000],
                    })
            else:
                out.append({"role": "assistant", "content": m.get("content") or ""})
        elif role == "user":
            out.append({"role": "user", "content": m.get("content") or ""})
        # 其他（不应出现）忽略
    return out


BASE_SYSTEM_PROMPT = (
    "你是 Arche Agent，一个运行在用户本机的 AI 工作台助手。\n"
    "- 回答使用用户消息的语言（默认中文）。\n"
    "- 简洁、直接、结构清晰；代码用 markdown 代码块。\n"
    "- 当提供了工具时，优先使用工具获取事实，不要凭空编造；"
    "工具结果已给出时不要重复调用。\n"
)


# 历史滑窗（ch2 上下文压缩）：开头保留条数（首轮上下文）+ 默认窗口条数
_KEEP_HEAD_MESSAGES = 2
_DEFAULT_HISTORY_WINDOW = 40
_MIN_HISTORY_WINDOW = 4


def _window_history(history: list[dict], window: int) -> tuple[list[dict], int]:
    """按消息粒度滑窗：保留开头 _KEEP_HEAD_MESSAGES 条 + 最近 window 条。

    必须在 _expand_tool_trace 之前裁剪——裁消息而非展开后的协议消息，
    assistant 的工具调用与 tool 结果才不会被切成孤儿。
    """
    if len(history) <= _KEEP_HEAD_MESSAGES + window:
        return history, 0
    kept = history[:_KEEP_HEAD_MESSAGES] + history[-window:]
    return kept, len(history) - len(kept)


def prepare_thread(
    session_id: str,
    system_prompt: str | None = None,
    runtime_note: str | None = None,
) -> list[dict]:
    """构造 LLM 消息线程：system 稳定前缀 + 滑窗历史 + 尾部动态块。

    动态块（P3/P4/P5 装配结果、上下文压缩说明）以 system 消息追加在线程尾部，
    不进 system 前缀——前缀逐字节稳定才能吃到 KV cache（ch2）。
    """
    history = session_manager.get_messages(session_id)
    window = int(load_config()["llm"].get("history_max_messages", _DEFAULT_HISTORY_WINDOW))
    history, omitted = _window_history(history, max(window, _MIN_HISTORY_WINDOW))
    thread = [
        {"role": "system", "content": system_prompt or BASE_SYSTEM_PROMPT}
    ] + _expand_tool_trace(history)
    tail = runtime_note or ""
    if omitted:
        tail = (tail + "\n\n" if tail else "") + f"（上下文压缩：更早 {omitted} 条历史消息已省略）"
    if tail:
        thread.append({"role": "system", "content": tail})
    return thread