"""自动化任务管理：定时任务 CRUD + 到期真实执行（LLM 通道）+ 运行记录。

存储 data/automations.json：
{
  "automations": {id: {任务字段...}},
  "runs": [{运行记录...}],          # 上限 _MAX_RUNS 条，新的在前
  "meta": {"seeded": bool}
}

任务字段：
- name 名称 / prompt 提示词
- model_tier: balanced(均衡) | fast(快速) | precision(精准)
- workspace_id / workspace_name：绑定工作空间（名称为创建时快照，用于列表展示）
- access: full(允许完全访问) | restricted(仅工作区内访问)
- schedule: {type: once|daily|weekly, run_at(ISO, 单次), time("HH:MM"), weekday(0=周一..6=周日)}
- validity: {type: permanent} | {type: until, end: "YYYY-MM-DD"}
- push_wechat / push_wecom：推送渠道开关（偏好保存，裁剪版不实际外发）
- status: active(运行中) | paused(已暂停) | done(已完成，单次任务触发后)
- run_count / last_run_at / created_at / updated_at

执行语义（真实 LLM 通道）：
- 触发（手动/到期）→ 写 running 记录 → 后台经 task_runner 执行完整编排管道
- 执行完成后更新记录：status=success/error，detail=回答摘要，session_id=执行会话
- 无人值守安全默认：danger 工具一律拒绝；同任务并发去重；单次执行超时保护
- 暂停任务与超过有效期的任务不触发；单次任务触发后置 done
"""
from __future__ import annotations

import asyncio
import json
import logging
import threading
import uuid
from datetime import datetime
from typing import Any

from .config import AUTOMATIONS_PATH

logger = logging.getLogger(__name__)
_lock = threading.Lock()

_MAX_RUNS = 200
_TICK_S = 15

_WEEKDAYS = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"]


def _now() -> datetime:
    return datetime.now().astimezone()


def _iso(dt: datetime) -> str:
    return dt.isoformat(timespec="seconds")


def _now_iso() -> str:
    return _iso(_now())


class AutomationManager:
    def __init__(self) -> None:
        self._data: dict[str, Any] = {"automations": {}, "runs": [], "meta": {}}
        self._loaded = False
        self._task: asyncio.Task | None = None
        self._pending_exec: list[tuple[dict[str, Any], str, str]] = []

    # ── 持久化 ────────────────────────────────────────────────

    def _load(self) -> None:
        if self._loaded:
            return
        try:
            data = json.loads(AUTOMATIONS_PATH.read_text(encoding="utf-8"))
            if isinstance(data, dict):
                self._data = {
                    "automations": data.get("automations") or {},
                    "runs": data.get("runs") if isinstance(data.get("runs"), list) else [],
                    "meta": data.get("meta") or {},
                }
        except (OSError, ValueError):
            self._data = {"automations": {}, "runs": [], "meta": {}}
        if not self._data.get("meta", {}).get("seeded"):
            self._seed()
        self._loaded = True

    def _save(self) -> None:
        AUTOMATIONS_PATH.write_text(
            json.dumps(self._data, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
        )

    def _seed(self) -> None:
        """首次启动写入一条示例任务（与参考界面一致，默认已暂停，不会触发）。"""
        now = _now_iso()
        demo = {
            "id": uuid.uuid4().hex[:8],
            "name": "生成昨日 AI 重点资讯总结",
            "prompt": (
                "汇总昨日人工智能领域的重点资讯，按重要程度排序，"
                "生成一份包含标题、摘要与来源链接的中文简报。"
            ),
            "model_tier": "balanced",
            "workspace_id": "",
            "workspace_name": "项目新手指引",
            "access": "full",
            "schedule": {"type": "daily", "run_at": None, "time": "09:00", "weekday": None},
            "validity": {"type": "permanent", "end": None},
            "push_wechat": False,
            "push_wecom": False,
            "status": "paused",
            "run_count": 0,
            "last_run_at": None,
            "created_at": now,
            "updated_at": now,
        }
        self._data["automations"][demo["id"]] = demo
        self._data["meta"]["seeded"] = True
        try:
            self._save()
        except OSError as e:
            logger.warning("示例自动化任务写入失败: %s", e)

    # ── 校验与规整 ────────────────────────────────────────────

    @staticmethod
    def _normalize_schedule(sched: dict[str, Any]) -> dict[str, Any]:
        typ = (sched.get("type") or "once").strip()
        if typ not in ("once", "daily", "weekly"):
            raise ValueError("执行频率类型不合法（单次/每天/每周）")
        out: dict[str, Any] = {"type": typ, "run_at": None, "time": None, "weekday": None}
        if typ == "once":
            raw = (sched.get("run_at") or "").strip()
            if not raw:
                raise ValueError("单次任务需要选择执行时间")
            try:
                dt = datetime.fromisoformat(raw)
            except ValueError:
                raise ValueError("执行时间格式不合法")
            if dt.tzinfo is None:
                dt = dt.astimezone()
            out["run_at"] = _iso(dt)
        else:
            t = (sched.get("time") or "").strip()
            try:
                hh, mm = t.split(":")
                h, m = int(hh), int(mm)
                if not (0 <= h <= 23 and 0 <= m <= 59):
                    raise ValueError
            except (ValueError, AttributeError):
                raise ValueError("计划时间格式不合法（应为 HH:MM）")
            out["time"] = f"{h:02d}:{m:02d}"
            if typ == "weekly":
                wd = sched.get("weekday")
                if not isinstance(wd, int) or not (0 <= wd <= 6):
                    raise ValueError("每周任务需要选择星期")
                out["weekday"] = wd
        return out

    @staticmethod
    def _normalize_validity(val: dict[str, Any]) -> dict[str, Any]:
        typ = (val.get("type") or "permanent").strip()
        if typ not in ("permanent", "until"):
            raise ValueError("有效期类型不合法")
        out: dict[str, Any] = {"type": typ, "end": None}
        if typ == "until":
            end = (val.get("end") or "").strip()
            try:
                datetime.strptime(end, "%Y-%m-%d")
            except (ValueError, AttributeError):
                raise ValueError("截止日期格式不合法（应为 YYYY-MM-DD）")
            out["end"] = end
        return out

    @staticmethod
    def _normalize_fields(fields: dict[str, Any]) -> dict[str, Any]:
        name = (fields.get("name") or "").strip()
        if not name:
            raise ValueError("请填写任务名称")
        if len(name) > 80:
            raise ValueError("任务名称不能超过 80 个字符")
        prompt = (fields.get("prompt") or "").strip()
        if not prompt:
            raise ValueError("请填写提示词")
        prompt = prompt[:8000]
        tier = (fields.get("model_tier") or "balanced").strip()
        if tier not in ("balanced", "fast", "precision"):
            tier = "balanced"
        access = (fields.get("access") or "full").strip()
        if access not in ("full", "restricted"):
            access = "full"
        sched = AutomationManager._normalize_schedule(fields.get("schedule") or {})
        validity = AutomationManager._normalize_validity(fields.get("validity") or {})
        return {
            "name": name,
            "prompt": prompt,
            "model_tier": tier,
            "workspace_id": (fields.get("workspace_id") or "").strip()[:64],
            "workspace_name": (fields.get("workspace_name") or "").strip()[:120],
            "access": access,
            "schedule": sched,
            "validity": validity,
            "push_wechat": bool(fields.get("push_wechat")),
            "push_wecom": bool(fields.get("push_wecom")),
        }

    # ── CRUD ──────────────────────────────────────────────────

    def list(self) -> list[dict[str, Any]]:
        with _lock:
            self._load()
            return sorted(
                (dict(a) for a in self._data["automations"].values()),
                key=lambda a: a.get("created_at", ""),
                reverse=True,
            )

    def runs(self) -> list[dict[str, Any]]:
        with _lock:
            self._load()
            return [dict(r) for r in self._data["runs"]]

    def create(self, fields: dict[str, Any], status: str = "active") -> dict[str, Any]:
        norm = self._normalize_fields(fields)
        if status not in ("active", "paused"):
            status = "active"
        now = _now_iso()
        rec = {
            "id": uuid.uuid4().hex[:8],
            **norm,
            "status": status,
            "run_count": 0,
            "last_run_at": None,
            "created_at": now,
            "updated_at": now,
        }
        with _lock:
            self._load()
            self._data["automations"][rec["id"]] = rec
            self._save()
        return dict(rec)

    def update(self, aid: str, fields: dict[str, Any]) -> dict[str, Any] | None:
        norm = self._normalize_fields(fields)
        with _lock:
            self._load()
            rec = self._data["automations"].get(aid)
            if not rec:
                return None
            rec.update(norm)
            rec["updated_at"] = _now_iso()
            # 编辑单次已完成任务后重新待命
            if rec["status"] == "done" and rec["schedule"]["type"] == "once":
                rec["status"] = "paused"
            self._save()
            return dict(rec)

    def set_status(self, aid: str, active: bool) -> dict[str, Any] | None:
        with _lock:
            self._load()
            rec = self._data["automations"].get(aid)
            if not rec:
                return None
            if rec["status"] == "done":
                # 单次任务已完成：重新启用时回到待执行状态
                if active:
                    rec["status"] = "active"
            else:
                rec["status"] = "active" if active else "paused"
            rec["updated_at"] = _now_iso()
            self._save()
            return dict(rec)

    def delete(self, aid: str) -> bool:
        with _lock:
            self._load()
            if aid not in self._data["automations"]:
                return False
            del self._data["automations"][aid]
            self._save()
            return True

    def batch(self, action: str, ids: list[str]) -> dict[str, int]:
        if action not in ("pause", "resume", "delete"):
            raise ValueError("批量操作类型不合法")
        affected = 0
        with _lock:
            self._load()
            for aid in ids:
                rec = self._data["automations"].get(aid)
                if not rec:
                    continue
                if action == "delete":
                    del self._data["automations"][aid]
                elif action == "pause":
                    if rec["status"] != "done":
                        rec["status"] = "paused"
                        rec["updated_at"] = _now_iso()
                else:  # resume
                    if rec["status"] == "done":
                        rec["status"] = "active"
                    elif rec["status"] == "paused":
                        rec["status"] = "active"
                        rec["updated_at"] = _now_iso()
                affected += 1
            if affected:
                self._save()
        return {"affected": affected}

    def clear_runs(self) -> dict[str, int]:
        with _lock:
            self._load()
            n = len(self._data["runs"])
            self._data["runs"] = []
            self._save()
        return {"cleared": n}

    # ── 运行 / 调度 ──────────────────────────────────────────

    def _append_run_locked(
        self, rec: dict[str, Any], trigger: str, detail: str, status: str = "success"
    ) -> dict[str, Any]:
        now = _now()
        run = {
            "id": uuid.uuid4().hex[:8],
            "automation_id": rec["id"],
            "name": rec["name"],
            "trigger": trigger,  # manual | schedule
            "status": status,
            "started_at": _iso(now),
            "finished_at": _iso(now) if status != "running" else None,
            "detail": detail,
        }
        self._data["runs"].insert(0, run)
        del self._data["runs"][_MAX_RUNS:]
        rec["run_count"] = int(rec.get("run_count", 0)) + 1
        rec["last_run_at"] = run["started_at"]
        return run

    def finish_run(
        self, run_id: str, *, status: str, detail: str, session_id: str = ""
    ) -> None:
        """后台执行完成：回填运行记录结果。"""
        with _lock:
            self._load()
            for run in self._data["runs"]:
                if run.get("id") == run_id:
                    run["status"] = status
                    run["finished_at"] = _now_iso()
                    run["detail"] = detail[:2000]
                    if session_id:
                        run["session_id"] = session_id
                    self._save()
                    return

    async def _execute_run(self, rec: dict[str, Any], run_id: str, trigger: str) -> None:
        """后台真实执行：完整编排管道 → 回填运行记录。"""
        from . import task_runner

        res = await task_runner.execute_prompt(
            rec.get("prompt") or "",
            title=rec.get("name") or "",
            tier=task_runner.automation_tier(rec.get("model_tier") or "balanced"),
            dedup_key=f"automation:{rec['id']}",
        )
        prefix = "手动触发" if trigger == "manual" else "按计划触发"
        if res["ok"]:
            detail = f"{prefix}完成：{res['answer']}"
            status = "success"
        else:
            detail = f"{prefix}失败：{res['error'] or res['state']}"
            status = "error"
        self.finish_run(run_id, status=status, detail=detail, session_id=res["session_id"])
        logger.info("自动化任务执行完成: [%s] %s → %s", rec["id"], rec["name"], status)

    def _spawn_locked(self, rec: dict[str, Any], run: dict[str, Any], trigger: str) -> None:
        """登记待执行快照（_loop 异步上下文中真正 spawn）。"""
        self._pending_exec.append((dict(rec), run["id"], trigger))

    def _drain_pending(self) -> list[tuple[dict[str, Any], str, str]]:
        with _lock:
            items, self._pending_exec = self._pending_exec, []
        return items

    def trigger(self, aid: str, trigger: str = "manual") -> dict[str, Any] | None:
        """手动触发：写 running 记录并调度后台真实执行（返回执行中记录）。"""
        with _lock:
            self._load()
            rec = self._data["automations"].get(aid)
            if not rec:
                return None
            run = self._append_run_locked(
                rec, trigger, "执行中…（无人值守真实执行）", status="running"
            )
            if rec["schedule"]["type"] == "once":
                rec["status"] = "done"
            rec["updated_at"] = _now_iso()
            self._spawn_locked(rec, run, trigger)
            self._save()
            return dict(run)

    def _valid_today(self, rec: dict[str, Any], now: datetime) -> bool:
        val = rec.get("validity") or {}
        if val.get("type") == "until" and val.get("end"):
            try:
                end = datetime.strptime(val["end"], "%Y-%m-%d").date()
            except ValueError:
                return True
            if now.date() > end:
                return False
        return True

    def tick(self) -> int:
        """检查到期任务：写 running 记录并登记执行，返回本次触发数。

        只做检测与登记；真实执行由 _loop 在异步上下文 dispatch。
        """
        fired = 0
        with _lock:
            self._load()
            now = _now()
            today = now.date().isoformat()
            due: list[dict[str, Any]] = []
            for rec in self._data["automations"].values():
                if rec.get("status") != "active" or not self._valid_today(rec, now):
                    continue
                sched = rec.get("schedule") or {}
                typ = sched.get("type")
                if typ == "once":
                    raw = sched.get("run_at")
                    if not raw:
                        continue
                    try:
                        run_at = datetime.fromisoformat(raw)
                    except ValueError:
                        continue
                    last = rec.get("last_run_at")
                    if run_at <= now and not last:
                        due.append(rec)
                elif typ in ("daily", "weekly"):
                    t = sched.get("time") or ""
                    try:
                        hh, mm = t.split(":")
                        h, m = int(hh), int(mm)
                    except (ValueError, AttributeError):
                        continue
                    if (now.hour, now.minute) != (h, m):
                        continue
                    if typ == "weekly" and sched.get("weekday") != now.weekday():
                        continue
                    last = rec.get("last_run_at")
                    if last and last[:10] == today:
                        continue
                    due.append(rec)
            for rec in due:
                run = self._append_run_locked(
                    rec, "schedule", "执行中…（无人值守真实执行）", status="running"
                )
                if rec["schedule"]["type"] == "once":
                    rec["status"] = "done"
                rec["updated_at"] = _now_iso()
                self._spawn_locked(rec, run, "schedule")
                fired += 1
                logger.info("自动化任务触发: [%s] %s", rec["id"], rec["name"])
            if fired:
                self._save()
        return fired

    async def start(self) -> None:
        self._load()
        if self._task is None or self._task.done():
            self._task = asyncio.create_task(self._loop(), name="automation-scheduler")
            logger.info("自动化调度器已启动（%d 个任务）", len(self._data["automations"]))

    async def stop(self) -> None:
        if self._task:
            self._task.cancel()
            try:
                await self._task
            except asyncio.CancelledError:
                pass
            self._task = None

    async def dispatch_pending(self) -> None:
        """把登记的待执行快照投递为后台任务（异步上下文调用）。"""
        for rec, run_id, trig in self._drain_pending():
            asyncio.create_task(
                self._execute_run(rec, run_id, trig),
                name=f"automation-exec-{rec['id']}",
            )

    async def _loop(self) -> None:
        while True:
            await asyncio.sleep(_TICK_S)
            try:
                await asyncio.to_thread(self.tick)
                await self.dispatch_pending()
            except Exception as e:  # noqa: BLE001 — 调度器自身不能崩
                logger.error("automation scheduler tick 异常: %s", e)


automation_manager = AutomationManager()
