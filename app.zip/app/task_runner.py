"""无人值守任务执行器：job / automation 到期 → 进程内真实 LLM 执行通道。

- execute_prompt：创建独立会话 → 编排器完整管道（路由/计划/执行/评估）→ 收集最终回答
- 安全默认：无人值守无人工确认通道，danger 工具的 confirm_request 一律立即拒绝
- 去重：同一任务同一时刻仅一个执行实例（周期任务执行时长超过间隔时跳过本轮，防堆积）
- 超时保护：单次执行上限 EXEC_TIMEOUT_S，超时按失败处理并取消会话回合
- 结果落审计；调用方负责持久化（job.result / automation run 记录）
"""
from __future__ import annotations

import asyncio
import logging
from typing import Any

from . import audit, orchestrator
from .session_manager import session_manager

logger = logging.getLogger(__name__)

EXEC_TIMEOUT_S = 600.0  # 单次无人值守执行上限（10 分钟）

# 并发去重：{kind:id} 集合（kind = job | automation）
_inflight: set[str] = set()


def _digest(text: str, cap: int = 400) -> str:
    text = (text or "").strip()
    return text[:cap] + ("…" if len(text) > cap else "")


async def execute_prompt(
    prompt: str, *, title: str = "", tier: str | None = None, dedup_key: str = ""
) -> dict[str, Any]:
    """以完整管道执行一段任务提示词（无人值守语义）。

    tier：强制工作流层（None = 按 config workflow.mode 路由）。
    dedup_key：并发去重键（如 "automation:abc123"），空 = 不去重。
    返回 {ok, answer, state, session_id, error}。
    """
    prompt = (prompt or "").strip()
    if not prompt:
        return {"ok": False, "answer": "", "state": "error", "session_id": "", "error": "提示词为空"}
    if dedup_key:
        if dedup_key in _inflight:
            return {
                "ok": False, "answer": "", "state": "skipped", "session_id": "",
                "error": "上一轮执行尚未结束，本轮跳过（防堆积）",
            }
        _inflight.add(dedup_key)
    try:
        return await asyncio.wait_for(
            _run_prompt(prompt, title=title, tier=tier, dedup_key=dedup_key),
            timeout=EXEC_TIMEOUT_S,
        )
    except asyncio.TimeoutError:
        audit.append("task_run", task=dedup_key or "adhoc", status="error",
                     error=f"执行超时（{EXEC_TIMEOUT_S:.0f}s）")
        return {
            "ok": False, "answer": "", "state": "error", "session_id": "",
            "error": f"执行超时（{EXEC_TIMEOUT_S:.0f}s 上限）",
        }
    finally:
        _inflight.discard(dedup_key)


async def _run_prompt(prompt: str, *, title: str, tier: str | None, dedup_key: str = "") -> dict[str, Any]:
    session = session_manager.create_session(title=f"[自动] {title or _digest(prompt, 24)}")
    session_id = session["id"]
    session_manager.append_messages(session_id, [{"role": "user", "content": prompt}])

    parts: list[str] = []
    state = "done"
    error = ""
    try:
        async for ev in orchestrator.run_turn(session_id, tier_override=tier):
            typ = ev.get("type")
            if typ == "delta":
                parts.append(ev.get("content") or "")
            elif typ == "done":
                state = ev.get("state") or "done"
                parts = [ev.get("content") or "".join(parts)]
            elif typ == "error":
                state, error = "error", ev.get("message") or "执行失败"
            elif typ == "confirm_request":
                # 无人值守无人工确认通道：danger 工具一律立即拒绝
                orchestrator.resolve_confirm(session_id, str(ev.get("id")), False)
                logger.info("无人值守任务拒绝 danger 工具 %s（session=%s）", ev.get("tool"), session_id)
            elif typ == "cancelled":
                state, error = "cancelled", "执行被取消"
    except Exception as e:  # noqa: BLE001 — 后台执行绝不向上抛崩调度器
        logger.exception("无人值守任务执行异常")
        state, error = "error", str(e)

    answer = (parts[-1] if parts else "").strip()
    ok = state == "done" and bool(answer)
    audit.append(
        "task_run", task=dedup_key or "adhoc", session_id=session_id, state=state,
        ok=ok, answer=audit.digest(answer, 200), error=audit.digest(error, 200),
    )
    return {
        "ok": ok, "answer": answer, "state": state,
        "session_id": session_id, "error": error,
    }


# --- automation tier 映射 ---

_TIER_MAP = {"balanced": "standard", "fast": "fast", "precision": "deep"}


def automation_tier(model_tier: str) -> str:
    """自动化任务 model_tier → 编排器工作流层。"""
    return _TIER_MAP.get(model_tier, "standard")
