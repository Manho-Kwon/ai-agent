"""Audit Log：统一审计留痕（M10）。

- 落盘 data/audit/audit-YYYYMMDD.jsonl（按天分文件，JSONL 追加写）
- 记录类型：route（路由决策）/ tool_call（工具调用）/ llm_call（模型调用计量）/
  job_run（定时任务真实执行）/ automation_run（自动化真实执行）
- 摘要脱敏：params/result 截断存储，密钥永不入审计
- 失败静默：审计写入绝不影响主链路
"""
from __future__ import annotations

import json
import logging
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .config import DATA_DIR

logger = logging.getLogger(__name__)

AUDIT_DIR = DATA_DIR / "audit"
_DIGEST_CAP = 300  # params / result 摘要截断长度
_read_lock = threading.Lock()


def _today_path() -> Path:
    return AUDIT_DIR / f"audit-{datetime.now(timezone.utc).astimezone():%Y%m%d}.jsonl"


def digest(value: Any, cap: int = _DIGEST_CAP) -> str:
    """摘要脱敏：对象转文本并截断（审计存储用）。"""
    text = value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, default=str)
    text = (text or "").strip()
    return text[:cap] + (f"…（共 {len(text)} 字符）" if len(text) > cap else "")


def append(kind: str, **fields: Any) -> None:
    """追加一条审计记录（任何失败静默，不影响主链路）。"""
    try:
        AUDIT_DIR.mkdir(parents=True, exist_ok=True)
        record = {
            "at": datetime.now(timezone.utc).astimezone().isoformat(timespec="milliseconds"),
            "kind": kind,
            **fields,
        }
        with _today_path().open("a", encoding="utf-8") as f:
            f.write(json.dumps(record, ensure_ascii=False, default=str) + "\n")
    except Exception:  # noqa: BLE001
        logger.debug("审计写入失败 kind=%s", kind, exc_info=True)


def recent(limit: int = 50, kind: str | None = None) -> list[dict[str, Any]]:
    """按时间倒序读取最近记录（跨当天与前一日的审计文件）。"""
    if not AUDIT_DIR.exists():
        return []
    out: list[dict[str, Any]] = []
    with _read_lock:
        files = sorted(AUDIT_DIR.glob("audit-*.jsonl"), reverse=True)
        for path in files:
            if len(out) >= limit:
                break
            try:
                lines = path.read_text(encoding="utf-8").splitlines()
            except OSError:
                continue
            for line in reversed(lines):
                if len(out) >= limit:
                    break
                line = line.strip()
                if not line:
                    continue
                try:
                    rec = json.loads(line)
                except json.JSONDecodeError:
                    continue
                if kind and rec.get("kind") != kind:
                    continue
                out.append(rec)
    return out


def summarize(record: dict[str, Any]) -> dict[str, Any]:
    """公开视图：剥去潜在敏感字段（当前实现仅保留白名单键）。"""
    return {
        k: record.get(k)
        for k in ("at", "kind", "session_id", "tier", "reason", "rule",
                  "tool", "server", "params", "result", "is_error",
                  "duration_ms", "role", "model", "prompt_tokens",
                  "completion_tokens", "title", "status",
                  "layer", "passed", "failures_count", "score",
                  "fallback", "detail")
        if k in record
    }
