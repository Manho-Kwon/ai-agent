import type { Appearance } from "./types";

/** 强调色候选（与「主题与外观」页一致；indigo 为默认主色） */
export const ACCENTS: { key: string; label: string; color: string; dark: string }[] = [
  { key: "indigo", label: "靛蓝", color: "#4f6bed", dark: "#3d55c8" },
  { key: "amber", label: "琥珀", color: "#d29a2b", dark: "#a97b1a" },
  { key: "blue", label: "蓝色", color: "#2f6bff", dark: "#2456d6" },
  { key: "emerald", label: "祖母绿", color: "#18a978", dark: "#12865e" },
  { key: "violet", label: "紫罗兰", color: "#8b5cf6", dark: "#6f46d6" },
  { key: "rose", label: "玫瑰", color: "#e0446a", dark: "#c22e52" },
  { key: "cyan", label: "青色", color: "#14a5a5", dark: "#0e8585" },
];

/** 背景色调候选（浅色模式生效；暖色/冷色微调背景色相） */
export const TONES: { key: Appearance["tone"]; label: string; desc: string }[] = [
  { key: "default", label: "默认", desc: "中性" },
  { key: "warm", label: "暖色", desc: "微黄调" },
  { key: "cool", label: "冷色", desc: "冷蓝色" },
];

export const WORKFLOW_MODES: { key: string; label: string }[] = [
  { key: "auto", label: "自适应" },
  { key: "fast", label: "快速" },
  { key: "standard", label: "标准" },
  { key: "deep", label: "深入" },
];

export const DEFAULT_APPEARANCE: Appearance = {
  mode: "light",
  tone: "default",
  accent: "indigo",
  font_scale: 100,
  glow: false,
  chat_bg_kind: "none",
  chat_bg: "",
};

export function normalizeAppearance(p?: Partial<Appearance> | null): Appearance {
  return { ...DEFAULT_APPEARANCE, ...(p || {}) };
}

export function loadCachedAppearance(): Appearance {
  try {
    const raw = localStorage.getItem("appearance");
    if (raw) return normalizeAppearance(JSON.parse(raw));
  } catch {
    /* 忽略坏缓存 */
  }
  return { ...DEFAULT_APPEARANCE, mode: localStorage.getItem("theme") === "dark" ? "dark" : "light" };
}

export function cacheAppearance(a: Appearance) {
  try {
    localStorage.setItem("appearance", JSON.stringify(a));
    localStorage.setItem("theme", a.mode);
  } catch {
    /* 存储满时静默 */
  }
}

/** 把外观设置落到 <html> 的 data 属性与 CSS 变量上 */
export function applyAppearance(a: Appearance) {
  const root = document.documentElement;
  root.dataset.theme = a.mode;
  root.dataset.tone = a.tone;
  root.dataset.glow = a.glow ? "on" : "off";

  const acc = ACCENTS.find((x) => x.key === a.accent) || ACCENTS[0];
  root.style.setProperty("--primary", acc.color);
  root.style.setProperty("--primary-dark", acc.dark);

  const scale = Math.min(150, Math.max(85, a.font_scale || 100)) / 100;
  root.style.setProperty("--ui-zoom", String(scale));

  if (a.chat_bg_kind === "custom" && a.chat_bg) {
    root.style.setProperty("--chat-bg", `url("${a.chat_bg}")`);
  } else {
    root.style.setProperty("--chat-bg", "none");
  }
}
