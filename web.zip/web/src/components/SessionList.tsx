import { useState } from "react";
import type { SessionMeta } from "../types";
import type { SettingsPageKey } from "../App";
import SettingsPanel from "./SettingsPanel";
import { useI18n, LANGS, type Lang } from "../i18n";

interface Props {
  title: string;
  subtitle: string;
  theme: "light" | "dark";
  collapsed: boolean;
  sessions: SessionMeta[];
  currentId: string | null;
  disabled: boolean;
  settingsActive: boolean;
  settingsPage: SettingsPageKey;
  onToggleSettings: () => void;
  onOpenSettingsPage: (page: SettingsPageKey) => void;
  /** 设置侧边栏顶部「返回应用」：收起设置并回到主界面 */
  onBackToApp: () => void;
  navOpen: boolean;
  onCloseNav: () => void;
  onOpenLibrary: () => void;
  onOpenWorkspace: () => void;
  onOpenAutomation: () => void;
  onToggleTheme: () => void;
  onToggleCollapse: () => void;
  onSelect: (id: string) => void;
  onNew: () => void;
  onDelete: (id: string) => void;
  onRename: (id: string, title: string) => void;
}

function GearIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="17"
      height="17"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" />
    </svg>
  );
}

function GlobeIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="15"
      height="15"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <circle cx="12" cy="12" r="9" />
      <path d="M3 12h18" />
      <path d="M12 3a14 14 0 0 1 0 18a14 14 0 0 1 0-18z" />
    </svg>
  );
}

function PlusCircleIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="16"
      height="16"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <circle cx="12" cy="12" r="10" />
      <line x1="12" y1="8" x2="12" y2="16" />
      <line x1="8" y1="12" x2="16" y2="12" />
    </svg>
  );
}

function BookIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="16"
      height="16"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" />
      <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" />
    </svg>
  );
}

function FolderIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="16"
      height="16"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
    </svg>
  );
}

function CycleIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="16"
      height="16"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <polyline points="23 4 23 10 17 10" />
      <polyline points="1 20 1 14 7 14" />
      <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
    </svg>
  );
}

function PencilIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="13"
      height="13"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z" />
    </svg>
  );
}

function XIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="13"
      height="13"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      aria-hidden
    >
      <line x1="6" y1="6" x2="18" y2="18" />
      <line x1="18" y1="6" x2="6" y2="18" />
    </svg>
  );
}

function MoonIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="16"
      height="16"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z" />
    </svg>
  );
}

function SunIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="16"
      height="16"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <circle cx="12" cy="12" r="4" />
      <line x1="12" y1="2" x2="12" y2="4.5" />
      <line x1="12" y1="19.5" x2="12" y2="22" />
      <line x1="2" y1="12" x2="4.5" y2="12" />
      <line x1="19.5" y1="12" x2="22" y2="12" />
      <line x1="4.9" y1="4.9" x2="6.7" y2="6.7" />
      <line x1="17.3" y1="17.3" x2="19.1" y2="19.1" />
      <line x1="4.9" y1="19.1" x2="6.7" y2="17.3" />
      <line x1="17.3" y1="6.7" x2="19.1" y2="4.9" />
    </svg>
  );
}

function PanelIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="16"
      height="16"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <rect x="3" y="4" width="18" height="16" rx="2.5" />
      <line x1="9.5" y1="4" x2="9.5" y2="20" />
      <rect x="4.8" y="6" width="3.2" height="12" rx="1.2" fill="currentColor" stroke="none" />
    </svg>
  );
}

function ChevronIcon({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      width="14"
      height="14"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
      className={className}
    >
      <polyline points="6 9 12 15 18 9" />
    </svg>
  );
}

const DATE_LOCALE: Record<Lang, string> = {
  zh: "zh-CN",
  ko: "ko-KR",
  en: "en-US",
};

function relTime(
  iso: string,
  t: (key: string, vars?: Record<string, string | number>) => string,
  lang: Lang
): string {
  const d = new Date(iso);
  const s = (Date.now() - d.getTime()) / 1000;
  if (s < 60) return t("sidebar.justNow");
  if (s < 3600) return t("sidebar.minutesAgo", { n: Math.floor(s / 60) });
  if (s < 86400) return t("sidebar.hoursAgo", { n: Math.floor(s / 3600) });
  return d.toLocaleDateString(DATE_LOCALE[lang] || "zh-CN");
}

export default function SessionList({
  title,
  subtitle,
  theme,
  collapsed,
  sessions,
  currentId,
  disabled,
  settingsActive,
  settingsPage,
  onToggleSettings,
  onOpenSettingsPage,
  onBackToApp,
  navOpen,
  onCloseNav,
  onOpenLibrary,
  onOpenWorkspace,
  onOpenAutomation,
  onToggleTheme,
  onToggleCollapse,
  onSelect,
  onNew,
  onDelete,
  onRename,
}: Props) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState("");
  const [tasksOpen, setTasksOpen] = useState(true);
  // 任务履历默认只展示最近 5 条，其余折叠隐藏（点「显示更多」一次性展开）
  const [showAllTasks, setShowAllTasks] = useState(false);
  const { t, lang, setLang } = useI18n();

  const commitRename = (id: string) => {
    if (draft.trim()) onRename(id, draft.trim());
    setEditingId(null);
  };

  const TASK_LIMIT = 5;
  const hiddenCount = Math.max(sessions.length - TASK_LIMIT, 0);
  const visibleSessions = showAllTasks ? sessions : sessions.slice(0, TASK_LIMIT);

  return (
    <aside
      className={`sidebar${navOpen ? " open" : ""}${collapsed ? " collapsed" : ""}`}
    >
      <div className="sb-head">
        <div className="sb-brand">
          <span className="sb-title" title={title}>
            {title}
          </span>
          <span className="sb-sub">{subtitle || "Arche Agent"}</span>
        </div>
        <div className="sb-head-actions">
          <button
            className="sb-icon-btn"
            onClick={onToggleTheme}
            title={theme === "light" ? t("sidebar.themeToDark") : t("sidebar.themeToLight")}
            type="button"
            aria-label={t("sidebar.toggleTheme")}
          >
            {theme === "light" ? <MoonIcon /> : <SunIcon />}
          </button>
          <button
            className="sb-icon-btn"
            onClick={onToggleCollapse}
            title={navOpen || !collapsed ? t("sidebar.collapseSidebar") : t("sidebar.expandSidebar")}
            type="button"
            aria-label={t("sidebar.toggleSidebar")}
          >
            <PanelIcon />
          </button>
        </div>
      </div>
      {settingsActive ? (
        <SettingsPanel activeKey={settingsPage} onOpenSettings={onOpenSettingsPage} onBackToApp={onBackToApp} />
      ) : (
        <>
          <nav className="side-nav">
            <button
              className="nav-item nav-new"
              type="button"
              onClick={onNew}
              disabled={disabled}
              title={t("sidebar.newTask")}
            >
              <PlusCircleIcon />
              <span>{t("sidebar.newTask")}</span>
            </button>
            <button
              className="nav-item"
              type="button"
              onClick={onOpenLibrary}
              title={t("sidebar.openLibrary")}
            >
              <BookIcon />
              <span>{t("sidebar.library")}</span>
            </button>
            <button
              className="nav-item"
              type="button"
              onClick={onOpenWorkspace}
              title={t("sidebar.openWorkspace")}
            >
              <FolderIcon />
              <span>{t("sidebar.workspace")}</span>
            </button>
            <button
              className="nav-item"
              type="button"
              onClick={onOpenAutomation}
              title={t("sidebar.openAutomation")}
            >
              <CycleIcon />
              <span>{t("sidebar.automation")}</span>
            </button>
          </nav>
          <div
            className="nav-group-head"
            onClick={() => setTasksOpen((v) => !v)}
            title={tasksOpen ? t("sidebar.collapseTasks") : t("sidebar.expandTasks")}
          >
            <span>{t("sidebar.tasks", { count: sessions.length })}</span>
            <ChevronIcon className={`nav-chevron ${tasksOpen ? "" : "collapsed"}`} />
          </div>
          <div className={`session-list ${tasksOpen ? "" : "hidden"}`}>
            {visibleSessions.map((s) => (
              <div
                key={s.id}
                className={`session-card ${s.id === currentId ? "active" : ""}`}
                onClick={() => {
                  if (disabled) return;
                  onSelect(s.id);
                  onCloseNav();
                }}
              >
                {editingId === s.id ? (
                  <input
                    className="rename-input"
                    value={draft}
                    autoFocus
                    onChange={(e) => setDraft(e.target.value)}
                    onBlur={() => commitRename(s.id)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") commitRename(s.id);
                      if (e.key === "Escape") setEditingId(null);
                    }}
                    onClick={(e) => e.stopPropagation()}
                  />
                ) : (
                  <>
                    <div className="session-title">{s.title}</div>
                    <div className="session-meta">
                      <span className="session-preview">
                        {s.preview || t("sidebar.emptyTask")}
                      </span>
                      <span className="session-time">{relTime(s.updated_at, t, lang)}</span>
                    </div>
                    <div className="card-actions">
                      <button
                        className="session-rename"
                        title={t("common.rename")}
                        onClick={(e) => {
                          e.stopPropagation();
                          setEditingId(s.id);
                          setDraft(s.title);
                        }}
                      >
                        <PencilIcon />
                      </button>
                      <button
                        className="session-del"
                        title={t("sidebar.deleteTask")}
                        onClick={(e) => {
                          e.stopPropagation();
                          if (confirm(t("sidebar.deleteConfirm", { title: s.title }))) onDelete(s.id);
                        }}
                      >
                        <XIcon />
                      </button>
                    </div>
                  </>
                )}
              </div>
            ))}
            {sessions.length > TASK_LIMIT && (
              <button
                className="session-more"
                type="button"
                onClick={() => setShowAllTasks((v) => !v)}
                title={showAllTasks ? t("sidebar.collapseTasks") : t("sidebar.expandAll", { count: sessions.length })}
              >
                <span>{showAllTasks ? t("sidebar.collapse") : t("sidebar.showMore", { count: hiddenCount })}</span>
                <ChevronIcon className={`more-chevron ${showAllTasks ? "up" : ""}`} />
              </button>
            )}
          </div>
        </>
      )}
      <div className="sidebar-foot">
        {/* 语言选择：独立于任务履历容器，锚定在设置按钮上方 */}
        <label className="lang-select" title={t("common.language")}>
          <GlobeIcon />
          <select
            className="lang-select-input"
            value={lang}
            aria-label={t("common.language")}
            onChange={(e) => setLang(e.target.value as Lang)}
          >
            {LANGS.map((l) => (
              <option key={l.code} value={l.code}>
                {l.label}
              </option>
            ))}
          </select>
        </label>
        <button
          className={`gear-btn${settingsActive ? " active" : ""}`}
          onClick={onToggleSettings}
          title={t("common.settings")}
          type="button"
        >
          <GearIcon />
        </button>
      </div>
    </aside>
  );
}
