import { useState } from "react";
import type { SessionMeta } from "../types";
import type { SettingsPageKey } from "../App";
import SettingsPanel from "./SettingsPanel";

interface Props {
  title: string;
  subtitle: string;
  theme: "light" | "dark";
  collapsed: boolean;
  sessions: SessionMeta[];
  currentId: string | null;
  disabled: boolean;
  settingsActive: boolean;
  settingsPage: SettingsPageKey;
  onToggleSettings: () => void;
  onOpenSettingsPage: (page: SettingsPageKey) => void;
  navOpen: boolean;
  onCloseNav: () => void;
  onOpenLibrary: () => void;
  onOpenWorkspace: () => void;
  onOpenAutomation: () => void;
  onToggleTheme: () => void;
  onToggleCollapse: () => void;
  onSelect: (id: string) => void;
  onNew: () => void;
  onDelete: (id: string) => void;
  onRename: (id: string, title: string) => void;
}

function GearIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="17"
      height="17"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <circle cx="12" cy="12" r="3" />
      <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" />
    </svg>
  );
}

function PlusCircleIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="16"
      height="16"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <circle cx="12" cy="12" r="10" />
      <line x1="12" y1="8" x2="12" y2="16" />
      <line x1="8" y1="12" x2="16" y2="12" />
    </svg>
  );
}

function BookIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="16"
      height="16"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" />
      <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" />
    </svg>
  );
}

function FolderIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="16"
      height="16"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
    </svg>
  );
}

function CycleIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="16"
      height="16"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <polyline points="23 4 23 10 17 10" />
      <polyline points="1 20 1 14 7 14" />
      <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
    </svg>
  );
}

function PencilIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="13"
      height="13"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <path d="M17 3a2.828 2.828 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5L17 3z" />
    </svg>
  );
}

function XIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="13"
      height="13"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      aria-hidden
    >
      <line x1="6" y1="6" x2="18" y2="18" />
      <line x1="18" y1="6" x2="6" y2="18" />
    </svg>
  );
}

function MoonIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="16"
      height="16"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z" />
    </svg>
  );
}

function SunIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="16"
      height="16"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <circle cx="12" cy="12" r="4" />
      <line x1="12" y1="2" x2="12" y2="4.5" />
      <line x1="12" y1="19.5" x2="12" y2="22" />
      <line x1="2" y1="12" x2="4.5" y2="12" />
      <line x1="19.5" y1="12" x2="22" y2="12" />
      <line x1="4.9" y1="4.9" x2="6.7" y2="6.7" />
      <line x1="17.3" y1="17.3" x2="19.1" y2="19.1" />
      <line x1="4.9" y1="19.1" x2="6.7" y2="17.3" />
      <line x1="17.3" y1="6.7" x2="19.1" y2="4.9" />
    </svg>
  );
}

function PanelIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="16"
      height="16"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <rect x="3" y="4" width="18" height="16" rx="2.5" />
      <line x1="9.5" y1="4" x2="9.5" y2="20" />
      <rect x="4.8" y="6" width="3.2" height="12" rx="1.2" fill="currentColor" stroke="none" />
    </svg>
  );
}

function ChevronIcon({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 24 24"
      width="14"
      height="14"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
      className={className}
    >
      <polyline points="6 9 12 15 18 9" />
    </svg>
  );
}

function relTime(iso: string): string {
  const d = new Date(iso);
  const s = (Date.now() - d.getTime()) / 1000;
  if (s < 60) return "刚刚";
  if (s < 3600) return `${Math.floor(s / 60)} 分钟前`;
  if (s < 86400) return `${Math.floor(s / 3600)} 小时前`;
  return d.toLocaleDateString("zh-CN");
}

export default function SessionList({
  title,
  subtitle,
  theme,
  collapsed,
  sessions,
  currentId,
  disabled,
  settingsActive,
  settingsPage,
  onToggleSettings,
  onOpenSettingsPage,
  navOpen,
  onCloseNav,
  onOpenLibrary,
  onOpenWorkspace,
  onOpenAutomation,
  onToggleTheme,
  onToggleCollapse,
  onSelect,
  onNew,
  onDelete,
  onRename,
}: Props) {
  const [editingId, setEditingId] = useState<string | null>(null);
  const [draft, setDraft] = useState("");
  const [tasksOpen, setTasksOpen] = useState(true);

  const commitRename = (id: string) => {
    if (draft.trim()) onRename(id, draft.trim());
    setEditingId(null);
  };

  return (
    <aside
      className={`sidebar${navOpen ? " open" : ""}${collapsed ? " collapsed" : ""}`}
    >
      <div className="sb-head">
        <div className="sb-brand">
          <span className="sb-title" title={title}>
            {title}
          </span>
          <span className="sb-sub">{subtitle || "Arche Agent"}</span>
        </div>
        <div className="sb-head-actions">
          <button
            className="sb-icon-btn"
            onClick={onToggleTheme}
            title={theme === "light" ? "切换到深色模式" : "切换到浅色模式"}
            type="button"
            aria-label="切换深浅色模式"
          >
            {theme === "light" ? <MoonIcon /> : <SunIcon />}
          </button>
          <button
            className="sb-icon-btn"
            onClick={onToggleCollapse}
            title={navOpen || !collapsed ? "收起侧边栏" : "展开侧边栏"}
            type="button"
            aria-label="收起或展开侧边栏"
          >
            <PanelIcon />
          </button>
        </div>
      </div>
      {settingsActive ? (
        <SettingsPanel activeKey={settingsPage} onOpenSettings={onOpenSettingsPage} />
      ) : (
        <>
          <nav className="side-nav">
            <button
              className="nav-item nav-new"
              type="button"
              onClick={onNew}
              disabled={disabled}
              title="新任务"
            >
              <PlusCircleIcon />
              <span>新任务</span>
            </button>
            <button
              className="nav-item"
              type="button"
              onClick={onOpenLibrary}
              title="打开资料库"
            >
              <BookIcon />
              <span>资料库</span>
            </button>
            <button
              className="nav-item"
              type="button"
              onClick={onOpenWorkspace}
              title="打开工作区"
            >
              <FolderIcon />
              <span>工作区</span>
            </button>
            <button
              className="nav-item"
              type="button"
              onClick={onOpenAutomation}
              title="打开自动化"
            >
              <CycleIcon />
              <span>自动化</span>
            </button>
          </nav>
          <div
            className="nav-group-head"
            onClick={() => setTasksOpen((v) => !v)}
            title={tasksOpen ? "收起任务列表" : "展开任务列表"}
          >
            <span>任务 ({sessions.length})</span>
            <ChevronIcon className={`nav-chevron ${tasksOpen ? "" : "collapsed"}`} />
          </div>
          <div className={`session-list ${tasksOpen ? "" : "hidden"}`}>
            {sessions.map((s) => (
              <div
                key={s.id}
                className={`session-card ${s.id === currentId ? "active" : ""}`}
                onClick={() => {
                  if (disabled) return;
                  onSelect(s.id);
                  onCloseNav();
                }}
              >
                {editingId === s.id ? (
                  <input
                    className="rename-input"
                    value={draft}
                    autoFocus
                    onChange={(e) => setDraft(e.target.value)}
                    onBlur={() => commitRename(s.id)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") commitRename(s.id);
                      if (e.key === "Escape") setEditingId(null);
                    }}
                    onClick={(e) => e.stopPropagation()}
                  />
                ) : (
                  <>
                    <div className="session-title">{s.title}</div>
                    <div className="session-meta">
                      <span className="session-preview">
                        {s.preview || "（空任务）"}
                      </span>
                      <span className="session-time">{relTime(s.updated_at)}</span>
                    </div>
                    <div className="card-actions">
                      <button
                        className="session-rename"
                        title="重命名"
                        onClick={(e) => {
                          e.stopPropagation();
                          setEditingId(s.id);
                          setDraft(s.title);
                        }}
                      >
                        <PencilIcon />
                      </button>
                      <button
                        className="session-del"
                        title="删除任务"
                        onClick={(e) => {
                          e.stopPropagation();
                          if (confirm(`删除任务「${s.title}」？`)) onDelete(s.id);
                        }}
                      >
                        <XIcon />
                      </button>
                    </div>
                  </>
                )}
              </div>
            ))}
          </div>
        </>
      )}
      <div className="sidebar-foot">
        <button
          className={`gear-btn${settingsActive ? " active" : ""}`}
          onClick={onToggleSettings}
          title="设置"
          type="button"
        >
          <GearIcon />
        </button>
      </div>
    </aside>
  );
}
