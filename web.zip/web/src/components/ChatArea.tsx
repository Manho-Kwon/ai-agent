import { useEffect, useRef, useState, type ReactNode } from "react";
import type {
  Attachment,
  ConfirmRequest,
  EvalInfo,
  InFlightTool,
  Message,
  PipelineState,
  PlanInfo,
  PlanStep,
  SessionMeta,
  StageMetric,
  ToolTrace,
} from "../types";
import { api } from "../api";
import { handleCopyClick, renderMarkdown } from "./Markdown";
import { useI18n } from "../i18n";

type TFn = (key: string, vars?: Record<string, string | number>) => string;

/* 允许上传的扩展名（与后端 app/attachments.py ALLOWED_EXTS 对齐） */
const ACCEPT_EXTS =
  ".txt,.md,.markdown,.csv,.json,.xml,.yaml,.yml,.log,.html,.htm,.css,.js,.mjs,.ts,.tsx,.jsx,.svg,.pdf,.docx,.xlsx,.pptx,.png,.jpg,.jpeg,.gif,.webp,.bmp,.ico,.avif";
const MAX_FILE_MB = 15;
const MAX_ATTACH_PER_MSG = 5;

function fmtSize(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(1)} MB`;
}

/* ── 图标 ── */
function UserIcon() {
  return (
    <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor" aria-hidden>
      <path d="M12 12c2.7 0 4.8-2.1 4.8-4.8S14.7 2.4 12 2.4 7.2 4.5 7.2 7.2 9.3 12 12 12zm0 2.4c-3.2 0-9.6 1.6-9.6 4.8v2.4h19.2v-2.4c0-3.2-6.4-4.8-9.6-4.8z" />
    </svg>
  );
}

function RobotIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="15"
      height="15"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      {/* 天线：竖线 + 顶部折角 */}
      <path d="M10.5 7V5h2" />
      {/* 头部 */}
      <rect x="5" y="7" width="14" height="11" rx="2.5" />
      {/* 双眼（竖向） */}
      <path d="M9.75 11v2.5" />
      <path d="M14.25 11v2.5" />
      {/* 两侧耳朵 */}
      <path d="M5 12H3.5" />
      <path d="M19 12h1.5" />
    </svg>
  );
}

function SendIcon() {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden>
      <path d="M2.01 21 23 12 2.01 3 2 10l15 2-15 2z" />
    </svg>
  );
}

function StopIcon() {
  return (
    <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor" aria-hidden>
      <path d="M6 6h12v12H6z" />
    </svg>
  );
}

function PlusIcon() {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden>
      <path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z" />
    </svg>
  );
}

function WrenchIcon() {
  return (
    <svg viewBox="0 0 24 24" width="15" height="15" fill="currentColor" aria-hidden>
      <path d="M22.7 19l-9.1-9.1c.9-2.3.4-5-1.5-6.9-2-2-5-2.4-7.4-1.3L9 6 6 9 1.6 4.7C.4 7.1.9 10.1 2.9 12.1c1.9 1.9 4.6 2.4 6.9 1.5l9.1 9.1c.4.4 1 .4 1.4 0l2.3-2.3c.5-.4.5-1.1.1-1.4z" />
    </svg>
  );
}

function ShieldIcon() {
  return (
    <svg viewBox="0 0 24 24" width="15" height="15" fill="currentColor" aria-hidden>
      <path d="M12 1 3 5v6c0 5.55 3.84 10.74 9 12 5.16-1.26 9-6.45 9-12V5l-9-4z" />
    </svg>
  );
}

function ClockIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="16"
      height="16"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <circle cx="12" cy="12" r="9" />
      <path d="M12 7v5l3.5 2" />
    </svg>
  );
}

function ShareIcon() {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden>
      <path d="M12 2.5 16 6.5h-3v7.5h-2V6.5H8l4-4z" />
      <path d="M5 10v10h14V10h2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V10h2z" />
    </svg>
  );
}

function CheckIcon() {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden>
      <path d="M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z" />
    </svg>
  );
}

/* ── 消息行：头像 + 名称 + 内容（正文与名称左对齐） ── */
function MessageRow({
  role,
  userName,
  botName,
  userAvatar,
  botAvatar,
  children,
}: {
  role: "user" | "assistant";
  userName: string;
  botName: string;
  userAvatar?: string;
  botAvatar?: string;
  children: React.ReactNode;
}) {
  const isUser = role === "user";
  const avatar = isUser ? userAvatar : botAvatar;
  return (
    <div className={`msg msg-${role}`}>
      <div className="msg-head">
        {isUser ? (
          <>
            <div className="msg-name">{userName}</div>
            <div className="avatar avatar-user">
              {avatar ? (
                <img src={avatar} alt="" className="avatar-img" />
              ) : (
                <UserIcon />
              )}
            </div>
          </>
        ) : (
          <>
            <div className="avatar avatar-agent">
              {avatar ? (
                <img src={avatar} alt="" className="avatar-img" />
              ) : (
                <RobotIcon />
              )}
            </div>
            <div className="msg-name">{botName}</div>
          </>
        )}
      </div>
      <div className={`msg-content ${isUser ? "msg-content-user" : ""}`}>
        {children}
      </div>
    </div>
  );
}

function ToolCard({
  server,
  tool,
  args,
  content,
  isError,
  running,
  elapsedMs,
}: {
  server: string;
  tool: string;
  args?: Record<string, unknown>;
  content?: string;
  isError?: boolean;
  running?: boolean;
  elapsedMs?: number;
}) {
  const [open, setOpen] = useState(false);
  const { t } = useI18n();
  const argsStr = args ? JSON.stringify(args, null, 2) : "{}";
  return (
    <div className={`tool-card ${open ? "open" : ""}`}>
      <button className="tool-card-head" onClick={() => setOpen(!open)}>
        <span
          className={`status-dot ${running ? "dot-amber" : isError ? "dot-red" : "dot-green"}`}
        />
        <span className="tool-card-name">
          {server}__{tool}
        </span>
        {running ? (
          <span className="tool-card-state">{t("chat.toolCalling")}</span>
        ) : (
          <span className="tool-card-state">
            {elapsedMs ? `${(elapsedMs / 1000).toFixed(1)}s` : ""}
          </span>
        )}
        <span className="tool-card-chevron">{open ? "▾" : "▸"}</span>
      </button>
      {open && (
        <div className="tool-card-body">
          <div className="tool-card-section">
            <div className="tool-card-label">{t("chat.params")}</div>
            <pre>{argsStr}</pre>
          </div>
          {content !== undefined && (
            <div className="tool-card-section">
              <div className="tool-card-label">{t("chat.result")}</div>
              <pre>{content || t("chat.noOutput")}</pre>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

/** 计划步骤时间线：按 plan.steps 顺序渲染，状态由 step_update 事件驱动 */
function StepTimeline({
  steps,
  states,
}: {
  steps: PlanStep[];
  states: Record<string, string>;
}) {
  const { t } = useI18n();
  if (!steps.length) return null;
  const stateText: Record<string, string> = {
    pending: t("chat.stepPending"),
    running: t("chat.stepRunning"),
    done: t("chat.stepDone"),
    failed: t("chat.stepFailed"),
  };
  return (
    <div className="step-timeline">
      {steps.map((s, i) => {
        const st = states[s.id] || "pending";
        return (
          <div key={s.id || i} className={`step-item step-${st}`} title={s.success || ""}>
            <span className="step-dot">
              {st === "done" ? "✓" : st === "failed" ? "✕" : st === "running" ? "…"
                : i + 1}
            </span>
            <span className="step-label">
              {s.tool || s.id}
              <span className="step-state">{stateText[st] || st}</span>
            </span>
          </div>
        );
      })}
    </div>
  );
}

/** 评估器 fail-open 放行原因 → i18n key（缺失时回退原始字符串） */
const FALLBACK_REASON_KEY: Record<string, string> = {
  disabled: "chat.fbDisabled",
  llm_unavailable: "chat.fbLlmUnavailable",
  exception: "chat.fbException",
  parse_failed: "chat.fbParseFailed",
};

function reasonText(fb: string, t: TFn): string {
  const key = FALLBACK_REASON_KEY[fb];
  return key ? t(key) : fb;
}

/** 评估结果明细：放行警告 + 失败项 + 评分（title 悬浮反馈全文） */
function evalTitle(ev: EvalInfo, t: TFn) {
  const lines: string[] = [];
  if (ev.fallback) {
    lines.push(t("chat.evalDegradedNote", { reason: reasonText(ev.fallback, t) }));
  }
  if (typeof ev.score === "number") lines.push(t("chat.score", { score: ev.score }));
  if (typeof ev.ms === "number") lines.push(t("chat.elapsed", { s: (ev.ms / 1000).toFixed(1) }));
  if (ev.failures?.length) {
    lines.push(
      ...ev.failures.map(
        (f) => `✕ ${f.step ? `[${f.step}] ` : ""}${f.detail || f.type || ""}`
      )
    );
  }
  if (ev.feedback) lines.push(ev.feedback);
  return lines.join("\n");
}

function EvalStrip({ evals }: { evals: EvalInfo[] }) {
  const { t } = useI18n();
  if (!evals.length) return null;
  return (
    <>
      {evals.map((ev) => {
        // fallback 非空 = 评估器没真工作，只是放行。必须与真通过区分开，
        // 否则质量门失效时界面仍显示绿色对勾，没人会察觉回答其实没被验收。
        const degraded = !!ev.fallback;
        return (
          <span
            key={ev.attempt}
            className={`pipe-eval ${degraded ? "warn" : ev.passed ? "ok" : "fail"}`}
            title={evalTitle(ev, t)}
          >
            {degraded ? "◐" : ev.passed ? "✓" : "✗"}{" "}
            {degraded ? t("chat.notEvaluated") : t("chat.evalLabel", { n: ev.attempt })}
            {typeof ev.score === "number" ? t("chat.scoreSuffix", { score: ev.score }) : ""}
            {!degraded && !ev.passed && ev.failures?.length
              ? t("chat.failuresSuffix", { n: ev.failures.length })
              : ""}
          </span>
        );
      })}
    </>
  );
}

/** 阶段指标：各阶段的字符数与耗时（规划 / 每个执行轮 / 评估） */
function StageMetrics({ stages }: { stages: StageMetric[] }) {
  const { t } = useI18n();
  if (!stages.length) return null;
  return (
    <div className="stage-metrics">
      {stages.map((s, i) => {
        const label =
          s.stage === "planner"
            ? s.revised
              ? t("chat.revisedPlan")
              : t("chat.plan")
            : s.stage === "executor"
              ? t("chat.execRound", { n: s.round ?? i + 1 })
              : t("chat.evalLabel", { n: s.attempt ?? "" });
        const degraded = !!s.fallback;
        const hint = degraded
          ? s.stage === "planner"
            ? t("chat.plannerFallback", { fb: String(s.fallback) })
            : t("chat.evaluatorDegraded", { reason: reasonText(String(s.fallback), t) })
          : undefined;
        return (
          <span
            key={i}
            className={`stage-chip ${degraded ? "warn" : ""}`}
            title={hint}
          >
            {label}
            {typeof s.chars === "number" ? t("chat.charsSuffix", { n: s.chars }) : ""}
            {typeof s.ms === "number" ? ` · ${(s.ms / 1000).toFixed(1)}s` : ""}
            {degraded
              ? ` · ${s.stage === "planner" ? t("chat.fallbackShort") : t("chat.notEvaluatedShort")}`
              : ""}
          </span>
        );
      })}
    </div>
  );
}

/**
 * 思考链路面板：流式进行中与历史消息共用同一套渲染。
 * 此前这段 JSX 只活在流式分支，回合结束重载会话后整条推理过程就消失了。
 */
function PipelinePanel({
  tier,
  role,
  plan,
  evals,
  stages,
  stepStates,
  state,
  live,
}: {
  tier?: string | null;
  role?: string | null;
  plan?: PlanInfo | null;
  evals?: EvalInfo[];
  stages?: StageMetric[];
  stepStates?: Record<string, string>;
  state?: string;
  live?: boolean;
}) {
  const { t } = useI18n();
  if (!tier && !role && !plan && !evals?.length && !stages?.length) return null;
  return (
    <>
      <div className="pipeline-strip">
        <span className="pipe-tier">{t("chat.tier", { tier: tier || "-" })}</span>
        {["planner", "executor", "evaluator"].map((r) => (
          <span key={r} className={`pipe-role ${role === r ? "active" : ""}`}>
            {t(`chat.${r}`)}
          </span>
        ))}
        {plan?.steps?.length ? (
          <span className="pipe-plan" title={plan.intent || ""}>
            {t("chat.planLabel")}
            {plan.steps.map((s: PlanStep) => s.tool || s.id).join(" → ")}
          </span>
        ) : null}
        <EvalStrip evals={evals || []} />
        {state === "paused_human" ? (
          <span className="pipe-paused" title={t("chat.pausedTitle")}>
            {t("chat.pausedHuman")}
          </span>
        ) : null}
      </div>
      <StageMetrics stages={stages || []} />
      {plan?.steps?.length && (live || Object.keys(stepStates || {}).length > 0) ? (
        <StepTimeline steps={plan.steps} states={stepStates || {}} />
      ) : null}
    </>
  );
}

/** 历史工具调用的成败判定：后端未写 is_error 时按输出前缀兜底 */
function traceFailed(t: ToolTrace): boolean {
  return t.is_error ?? !!t.content?.startsWith("Error:");
}

/** 折叠态的一行摘要：不展开也知道这轮跑了什么、结果如何 */
function traceSummary(
  opts: {
    tier?: string | null;
    evals?: EvalInfo[];
    toolCount: number;
    failedCount: number;
    state?: string;
  },
  t: TFn
): string {
  const parts: string[] = [];
  if (opts.tier) parts.push(t("chat.tier", { tier: opts.tier }));
  if (opts.toolCount) {
    parts.push(
      t("chat.toolCount", { n: opts.toolCount }) +
        (opts.failedCount ? t("chat.failedSuffix", { n: opts.failedCount }) : "")
    );
  }
  const last = opts.evals?.length ? opts.evals[opts.evals.length - 1] : undefined;
  if (last) {
    parts.push(
      last.fallback
        ? t("chat.notEvaluated")
        : last.passed
          ? t("chat.evalPassed")
          : t("chat.evalFailed") +
            (typeof last.score === "number" ? t("chat.scoreSuffix", { score: last.score }) : "")
    );
  }
  // 转人工是必须被看见的警示，不能随折叠一起收进壳里
  if (opts.state === "paused_human") parts.push(t("chat.pausedHuman"));
  return parts.join(" · ");
}

/**
 * 思考履历外壳：执行中实时展开输出推理过程，回合结束后自动折叠成一行摘要。
 * 折叠时机无需额外状态——流式块与历史消息属于不同 React 子树，回合结束重载会话时
 * 必然重新挂载，useState(!!live) 取到的就是折叠态。
 */
function ThinkingTrace({
  live,
  summary,
  children,
}: {
  live?: boolean;
  summary: string;
  children: ReactNode;
}) {
  const [open, setOpen] = useState(!!live);
  const { t } = useI18n();
  return (
    <div className="trace-shell">
      <button className="trace-head" onClick={() => setOpen(!open)}>
        <span className="trace-chevron">{open ? "▾" : "▸"}</span>
        <span className={`trace-label ${live ? "live" : ""}`}>
          {live ? t("chat.thinking") : t("chat.thoughtProcess")}
        </span>
        {!open && summary ? (
          <span className="trace-summary">{summary}</span>
        ) : null}
      </button>
      {open ? <div className="trace-body">{children}</div> : null}
    </div>
  );
}

/** danger 高危工具人工确认弹窗（拒绝 / 120s 超时 = 不执行） */
function ConfirmDialog({
  req,
  onConfirm,
}: {
  req: ConfirmRequest;
  onConfirm: (callId: string, approved: boolean) => void;
}) {
  const hasArgs = req.arguments && Object.keys(req.arguments).length > 0;
  const { t } = useI18n();
  return (
    <div className="confirm-overlay" role="dialog" aria-modal="true">
      <div className="confirm-dialog">
        <div className="confirm-head">
          <ShieldIcon />
          {t("chat.confirmTitle")}
        </div>
        <div className="confirm-body">
          <p>{t("chat.confirmBody")}</p>
          <div className="confirm-tool">
            {req.server}__{req.tool}
          </div>
          {hasArgs && (
            <pre className="confirm-args">{JSON.stringify(req.arguments, null, 2)}</pre>
          )}
          <p className="confirm-note">{t("chat.confirmNote")}</p>
        </div>
        <div className="confirm-actions">
          <button
            type="button"
            className="btn-confirm-deny"
            onClick={() => onConfirm(req.callId, false)}
          >
            {t("chat.reject")}
          </button>
          <button
            type="button"
            className="btn-confirm-allow"
            onClick={() => onConfirm(req.callId, true)}
          >
            {t("chat.allow")}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ── 附件 chip：缩略图/类型徽标 + 名称 + 大小 + 状态 + 删除（待发与历史消息共用） ── */
function AttachmentChip({
  att,
  blobUrl,
  onRemove,
  onPreview,
}: {
  att: Attachment;
  blobUrl?: string;
  onRemove?: (id: string) => void;
  onPreview?: (url: string) => void;
}) {
  const isImage = att.kind === "image";
  const { t } = useI18n();
  const thumb = isImage ? blobUrl || att.url || "" : "";
  const failed = att.status === "parse_failed";
  const badge = (att.ext || "").replace(".", "").toUpperCase() || "FILE";
  const handleClick = () => {
    if (!isImage || !onPreview) return;
    const u = blobUrl || att.url;
    if (u) onPreview(u);
  };
  return (
    <span
      className={`attach-chip${failed ? " attach-failed" : ""}${isImage ? " attach-image" : ""}`}
      title={failed ? att.error || t("chat.parseFailed") : `${att.name} · ${fmtSize(att.size)}`}
      onClick={isImage ? handleClick : undefined}
    >
      {thumb ? (
        <img className="attach-thumb" src={thumb} alt="" />
      ) : (
        <span className="attach-badge">{badge}</span>
      )}
      <span className="attach-name">{att.name}</span>
      <span className="attach-size">{fmtSize(att.size)}</span>
      {att.status === "image" && <span className="attach-tag">{t("chat.previewOnly")}</span>}
      {failed && <span className="attach-tag attach-tag-failed">{t("chat.parseFailed")}</span>}
      {att.status === "ready" && att.chars ? (
        <span className="attach-tag attach-tag-ok">{t("chat.charsCount", { n: att.chars })}</span>
      ) : null}
      {onRemove && (
        <button
          className="attach-x"
          type="button"
          aria-label={t("chat.removeAttachment")}
          onClick={(e) => {
            e.stopPropagation();
            onRemove(att.id);
          }}
        >
          ×
        </button>
      )}
    </span>
  );
}

export default function ChatArea({
  messages,
  streaming,
  error,
  sessions,
  currentId,
  ensureSession,
  userName = "K哥",
  botName = "Agent",
  userAvatar = "",
  botAvatar = "",
  confirmReq,
  onConfirm,
  onSelectSession,
  onSend,
  onStop,
  onOpenTools,
  yoloMode,
  onToggleYolo,
}: Props) {
  const [input, setInput] = useState("");
  const [stick, setStick] = useState(true);
  const [histOpen, setHistOpen] = useState(false);
  const [shared, setShared] = useState(false);
  const [pending, setPending] = useState<Attachment[]>([]);
  const [uploading, setUploading] = useState(0);
  const [preview, setPreview] = useState<string | null>(null);
  const [attachError, setAttachError] = useState<string | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const blobUrls = useRef<Map<string, string>>(new Map());
  const busy = streaming !== null;
  const { t } = useI18n();

  const currentTitle =
    sessions.find((s) => s.id === currentId)?.title || t("chat.newSession");

  const fmtTime = (iso: string) => {
    const d = new Date(iso);
    if (isNaN(d.getTime())) return "";
    const p = (n: number) => String(n).padStart(2, "0");
    return `${d.getMonth() + 1}/${d.getDate()} ${p(d.getHours())}:${p(d.getMinutes())}`;
  };

  // 分享：把会话以 Markdown 复制到剪贴板
  const handleShare = async () => {
    if (shared || messages.length === 0) return;
    const md = messages
      .map(
        (m) =>
          `**${m.role === "user" ? userName : botName}**\n\n${m.content}`
      )
      .join("\n\n---\n\n");
    try {
      await navigator.clipboard.writeText(md);
      setShared(true);
      setTimeout(() => setShared(false), 1500);
    } catch {
      /* 剪贴板不可用时静默 */
    }
  };

  // 自动滚动（用户上翻时暂停跟随）
  useEffect(() => {
    const el = scrollRef.current;
    if (el && stick) el.scrollTop = el.scrollHeight;
  }, [messages, streaming, stick]);

  // 切换会话时清空未发送附件并释放本地预览 URL。
  // null→id 不算切换：那是草稿态被这次上传落地成真实会话，附件正是触发者
  const prevSid = useRef<string | null>(currentId);
  useEffect(() => {
    const materialized = prevSid.current === null && currentId !== null;
    prevSid.current = currentId;
    if (materialized) return;
    setPending([]);
    setAttachError(null);
    blobUrls.current.forEach((u) => URL.revokeObjectURL(u));
    blobUrls.current.clear();
  }, [currentId]);

  const onScroll = () => {
    const el = scrollRef.current;
    if (!el) return;
    setStick(el.scrollHeight - el.scrollTop - el.clientHeight < 60);
  };

  const onFiles = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    e.target.value = ""; // 复位，支持重选同名文件
    if (!files.length) return;
    setAttachError(null);
    const room = MAX_ATTACH_PER_MSG - pending.length;
    if (room <= 0) {
      setAttachError(t("chat.maxAttachPerMsg", { n: MAX_ATTACH_PER_MSG }));
      return;
    }
    const accepted = files.slice(0, room);
    if (files.length > room) {
      setAttachError(t("chat.maxAddMore", { n: room }));
    }
    // 草稿态：附件要挂在真实会话上，此刻才落地（失败提示由父组件给出）
    const sid = currentId || (await ensureSession());
    if (!sid) return;
    const allowList = ACCEPT_EXTS.split(",");
    for (const f of accepted) {
      const ext = "." + (f.name.split(".").pop() || "").toLowerCase();
      if (!allowList.includes(ext)) {
        setAttachError(t("chat.unsupportedType", { name: f.name }));
        continue;
      }
      if (f.size > MAX_FILE_MB * 1024 * 1024) {
        setAttachError(t("chat.fileTooLarge", { name: f.name, n: MAX_FILE_MB }));
        continue;
      }
      setUploading((n) => n + 1);
      try {
        const meta = await api.uploadChatAttachment(sid, f);
        if (meta.kind === "image") {
          blobUrls.current.set(meta.id, URL.createObjectURL(f));
        }
        setPending((prev) => [...prev, meta]);
      } catch (err) {
        setAttachError((err as Error).message || t("chat.uploadFailed", { name: f.name }));
      } finally {
        setUploading((n) => n - 1);
      }
    }
  };

  const removePending = (id: string) => {
    setPending((prev) => prev.filter((a) => a.id !== id));
    setAttachError(null);
    const u = blobUrls.current.get(id);
    if (u) {
      URL.revokeObjectURL(u);
      blobUrls.current.delete(id);
    }
  };

  const send = () => {
    const content = input.trim();
    if ((!content && pending.length === 0) || busy || uploading > 0) return;
    setInput("");
    const atts = pending;
    setPending([]);
    onSend(content, atts);
  };

  const onKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey && !e.nativeEvent.isComposing) {
      e.preventDefault();
      send();
    }
  };

  return (
    <main className="chat-area">
      {confirmReq && <ConfirmDialog req={confirmReq} onConfirm={onConfirm} />}
      <div className="chat-head">
        <div className="chat-head-inner">
          <div className="chat-summary" title={currentTitle}>
            {currentTitle}
          </div>
          <div className="chat-head-actions">
            <button
              className="ci-icon"
              type="button"
              title={shared ? t("chat.copied") : t("chat.share")}
              onClick={handleShare}
              disabled={messages.length === 0}
            >
              {shared ? <CheckIcon /> : <ShareIcon />}
            </button>
            <div className="history-wrap">
              <button
                className={`ci-icon ${histOpen ? "open" : ""}`}
                type="button"
                title={t("chat.history")}
                onClick={() => setHistOpen((v) => !v)}
              >
                <ClockIcon />
              </button>
              {histOpen && (
                <>
                  <div
                    className="pop-backdrop"
                    onClick={() => setHistOpen(false)}
                  />
                  <div className="history-menu">
                    {[...sessions]
                      .sort((a, b) => b.updated_at.localeCompare(a.updated_at))
                      .map((s) => (
                        <button
                          key={s.id}
                          type="button"
                          className={`history-item ${s.id === currentId ? "active" : ""}`}
                          onClick={() => {
                            onSelectSession(s.id);
                            setHistOpen(false);
                          }}
                        >
                          <span className="history-title">
                            {s.title || t("chat.untitled")}
                          </span>
                          <span className="history-time">
                            {fmtTime(s.updated_at)} · {t("chat.msgCount", { n: s.message_count })}
                          </span>
                        </button>
                      ))}
                    {sessions.length === 0 && (
                      <div className="history-empty">{t("chat.noHistory")}</div>
                    )}
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      </div>
      <div className="chat-scroll" ref={scrollRef} onScroll={onScroll}>
        <div className="chat-col">
          {error && <div className="chat-error">{error}</div>}
          {messages.length === 0 && !streaming && (
            <div className="chat-empty">
              <div className="chat-empty-icon">◆</div>
              <div>{t("chat.emptyHint")}</div>
            </div>
          )}
          {messages.map((m) => (
            <MessageRow
              key={m.id || m.timestamp}
              role={m.role}
              userName={userName}
              botName={botName}
              userAvatar={userAvatar}
              botAvatar={botAvatar}
            >
              {m.role === "assistant" && (m.meta || m.tool_trace?.length) ? (
                <ThinkingTrace
                  summary={traceSummary({
                    tier: m.meta?.tier,
                    evals: m.meta?.evals,
                    toolCount: m.tool_trace?.length || 0,
                    failedCount: (m.tool_trace || []).filter(traceFailed).length,
                    state: m.meta?.state,
                  }, t)}
                >
                  {m.meta ? (
                    <PipelinePanel
                      tier={m.meta.tier}
                      plan={m.meta.plan}
                      evals={m.meta.evals}
                      stages={m.meta.stages}
                      stepStates={m.meta.step_states}
                      state={m.meta.state}
                    />
                  ) : null}
                  {m.tool_trace?.map((t: ToolTrace) => (
                    <ToolCard
                      key={t.id}
                      server={t.server}
                      tool={t.tool}
                      args={t.arguments}
                      content={t.content}
                      isError={traceFailed(t)}
                      elapsedMs={t.ms}
                    />
                  ))}
                </ThinkingTrace>
              ) : null}
              {m.role === "assistant" ? (
                m.content ? (
                  <div
                    className="md-body"
                    onClick={handleCopyClick}
                    dangerouslySetInnerHTML={{ __html: renderMarkdown(m.content) }}
                  />
                ) : null
              ) : (
                <>
                  {m.attachments?.length ? (
                    <div className="msg-attachments">
                      {m.attachments.map((a) => (
                        <AttachmentChip
                          key={a.id}
                          att={a}
                          blobUrl={blobUrls.current.get(a.id)}
                          onPreview={setPreview}
                        />
                      ))}
                    </div>
                  ) : null}
                  {m.content ? <div className="msg-text">{m.content}</div> : null}
                </>
              )}
            </MessageRow>
          ))}
          {streaming && (
            <MessageRow
              role="assistant"
              userName={userName}
              botName={botName}
              userAvatar={userAvatar}
              botAvatar={botAvatar}
            >
              <ThinkingTrace
                live
                summary={traceSummary({
                  tier: streaming.tier,
                  evals: streaming.evals,
                  toolCount: streaming.tools.length,
                  failedCount: streaming.tools.filter((t) => !!t.is_error).length,
                }, t)}
              >
                <PipelinePanel
                  tier={streaming.tier}
                  role={streaming.role}
                  plan={streaming.plan}
                  evals={streaming.evals}
                  stages={streaming.stages}
                  stepStates={streaming.stepStates}
                  live
                />
                {streaming.tools.map((t) => (
                  <ToolCard
                    key={t.id}
                    server={t.server}
                    tool={t.tool}
                    args={t.arguments}
                    content={t.endedAt !== undefined ? t.content : undefined}
                    isError={t.is_error}
                    running={t.endedAt === undefined}
                    elapsedMs={(t.endedAt || Date.now()) - t.startedAt}
                  />
                ))}
              </ThinkingTrace>
              {streaming.text ? (
                <div
                  className="md-body streaming"
                  onClick={handleCopyClick}
                  dangerouslySetInnerHTML={{
                    __html: renderMarkdown(streaming.text),
                  }}
                />
              ) : null}
            </MessageRow>
          )}
        </div>
      </div>
      <div className="chat-bottom">
        <input
          ref={fileRef}
          type="file"
          multiple
          hidden
          accept={ACCEPT_EXTS}
          onChange={onFiles}
        />
        {(pending.length > 0 || uploading > 0 || attachError) && (
          <div className="attach-bar">
            {attachError && <div className="attach-error">{attachError}</div>}
            <div className="attach-chips">
              {pending.map((a) => (
                <AttachmentChip
                  key={a.id}
                  att={a}
                  blobUrl={blobUrls.current.get(a.id)}
                  onRemove={removePending}
                  onPreview={setPreview}
                />
              ))}
              {uploading > 0 && (
                <span className="attach-chip attach-uploading">
                  {t("chat.uploading")}{uploading > 1 ? ` (${uploading})` : ""}
                </span>
              )}
            </div>
          </div>
        )}
        <div className="chat-input">
          <div className="chat-input-tools">
            <button
              className="ci-icon"
              type="button"
              title={t("chat.uploadAttach")}
              onClick={() => fileRef.current?.click()}
              disabled={busy || uploading > 0}
            >
              <PlusIcon />
            </button>
            <button className="ci-icon" type="button" title={t("chat.toolsSkills")} onClick={onOpenTools}>
              <WrenchIcon />
            </button>
            <button
              className={`ci-icon${yoloMode ? " ci-icon--yolo" : ""}`}
              type="button"
              title={yoloMode ? t("chat.yoloOn") : t("chat.yoloOff")}
              onClick={onToggleYolo}
            >
              <ShieldIcon />
            </button>
          </div>
          <textarea
            value={input}
            placeholder={t("chat.inputPlaceholder")}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={onKeyDown}
            rows={Math.min(6, input.split("\n").length)}
          />
          {busy ? (
            <button className="btn-round btn-stop-round" onClick={onStop} title={t("chat.stop")}>
              <StopIcon />
            </button>
          ) : (
            <button
              className="btn-round btn-send-round"
              onClick={send}
              disabled={!input.trim() && pending.length === 0}
              title={t("chat.send")}
            >
              <SendIcon />
            </button>
          )}
        </div>
        <div className="chat-footnote">{t("chat.footnote")}</div>
        {preview && (
          <div className="attach-lightbox" onClick={() => setPreview(null)}>
            <img src={preview} alt={t("chat.attachPreview")} />
          </div>
        )}
      </div>
    </main>
  );
}

interface Props {
  messages: Message[];
  streaming: ({ text: string; tools: InFlightTool[] } & PipelineState) | null;
  error: string | null;
  sessions: SessionMeta[];
  currentId: string | null;
  /** 草稿态下按需落地会话（上传附件需要真实 session_id），失败返回 null */
  ensureSession: () => Promise<string | null>;
  /** 用户 / 机器人显示名称与头像（设置 → 用户资料） */
  userName?: string;
  botName?: string;
  userAvatar?: string;
  botAvatar?: string;
  /** danger 高危工具确认请求（非空时弹人工放行弹窗） */
  confirmReq: ConfirmRequest | null;
  onConfirm: (callId: string, approved: boolean) => void;
  onSelectSession: (id: string) => void;
  onSend: (content: string, attachments?: Attachment[]) => void;
  onStop: () => void;
  onOpenTools: () => void;
  /** YOLO 模式：开启后跳过 danger 高危工具确认门 */
  yoloMode: boolean;
  onToggleYolo: () => void;
}
