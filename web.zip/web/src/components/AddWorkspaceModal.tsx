import { useEffect, useState, type KeyboardEvent } from "react";
import { api } from "../api";
import type { DirBrowse } from "../types";

interface Props {
  onClose: () => void;
  onCreated: () => void;
}

function XIcon() {
  return (
    <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor"
      strokeWidth={2} strokeLinecap="round" aria-hidden>
      <line x1="6" y1="6" x2="18" y2="18" />
      <line x1="18" y1="6" x2="6" y2="18" />
    </svg>
  );
}

function FolderIcon({ size = 16 }: { size?: number }) {
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} fill="none" stroke="currentColor"
      strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
    </svg>
  );
}

/** 目录选择器（服务端列目录，浏览器拿不到本机绝对路径） */
function DirPicker({
  initialPath,
  onPick,
  onClose,
}: {
  initialPath: string;
  onPick: (path: string) => void;
  onClose: () => void;
}) {
  const [browse, setBrowse] = useState<DirBrowse | null>(null);
  const [jump, setJump] = useState(initialPath);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const load = async (path: string) => {
    setLoading(true);
    try {
      const data = await api.browseDirs(path);
      setBrowse(data);
      setJump(data.current);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "读取目录失败");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load(initialPath);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="lib-modal-mask ws-picker-mask" onClick={onClose}>
      <div className="lib-modal ws-picker" onClick={(e) => e.stopPropagation()}>
        <div className="lib-modal-head">
          <span className="lib-view-title">选择目录</span>
          <button className="sb-icon-btn" onClick={onClose} title="取消" type="button">
            <XIcon />
          </button>
        </div>
        <div className="ws-picker-path">
          <input
            value={jump}
            onChange={(e) => setJump(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") load(jump);
            }}
            placeholder="输入路径后回车跳转"
          />
          <button type="button" className="ws-btn-ghost" onClick={() => load(jump)}>
            跳转
          </button>
        </div>
        {error && <div className="apm-msg apm-msg-error">{error}</div>}
        <div className="ws-picker-list">
          {loading ? (
            <div className="ws-picker-empty">加载中…</div>
          ) : browse && browse.dirs.length > 0 ? (
            browse.dirs.map((d) => (
              <button
                key={d.path}
                type="button"
                className="ws-picker-item"
                onClick={() => load(d.path)}
                title={d.path}
              >
                <FolderIcon size={15} />
                <span>{d.name}</span>
              </button>
            ))
          ) : (
            <div className="ws-picker-empty">此目录下没有子文件夹</div>
          )}
        </div>
        <div className="ws-picker-foot">
          <button
            type="button"
            className="ws-btn-ghost"
            disabled={!browse?.parent}
            onClick={() => browse?.parent && load(browse.parent)}
          >
            上级目录
          </button>
          <button
            type="button"
            className="apm-submit ws-picker-select"
            disabled={!browse}
            onClick={() => browse && onPick(browse.current)}
          >
            <FolderIcon size={15} />
            选择当前目录
          </button>
        </div>
      </div>
    </div>
  );
}

export default function AddWorkspaceModal({ onClose, onCreated }: Props) {
  const [name, setName] = useState("");
  const [path, setPath] = useState("");
  const [desc, setDesc] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pickerOpen, setPickerOpen] = useState(false);

  /** 前端校验；返回错误信息，null = 通过 */
  const validate = (): string | null => {
    if (!name.trim()) return "请填写工作区名称";
    if (!path.trim()) return "请填写目录路径";
    // Windows（C:\…）与 POSIX（/…）绝对路径
    if (!/^([a-zA-Z]:[\\/]|\/|\\)/.test(path.trim()))
      return "目录路径必须是绝对路径（例如 C:\\Users\\you\\projects\\my-app）";
    return null;
  };

  const submit = async () => {
    if (submitting) return;
    const err = validate();
    if (err) {
      setError(err);
      return;
    }
    setError(null);
    setSubmitting(true);
    try {
      await api.createWorkspace({ name: name.trim(), path: path.trim(), description: desc.trim() });
      onCreated();
    } catch (e) {
      setError(e instanceof Error ? e.message : "添加失败，请重试");
    } finally {
      setSubmitting(false);
    }
  };

  const onKeyDown = (e: KeyboardEvent) => {
    if (e.key === "Enter" && (e.target as HTMLElement).tagName !== "BUTTON") {
      e.preventDefault();
      void submit();
    }
  };

  return (
    <div className="lib-modal-mask" onClick={() => !submitting && onClose()}>
      <div
        className="lib-modal aw-modal"
        onClick={(e) => e.stopPropagation()}
        onKeyDown={onKeyDown}
      >
        <div className="lib-modal-head">
          <div>
            <div className="apm-title">添加工作区</div>
            <div className="apm-subtitle">将本地目录注册为 AI 代理的工作区。</div>
          </div>
          <button
            className="sb-icon-btn"
            onClick={onClose}
            title="取消"
            type="button"
            disabled={submitting}
            aria-label="关闭"
          >
            <XIcon />
          </button>
        </div>

        <label className="field">
          <span>工作区名称</span>
          <input
            value={name}
            autoFocus
            onChange={(e) => setName(e.target.value)}
            placeholder="例如：我的项目"
          />
        </label>

        <label className="field">
          <span>目录路径</span>
          <div className="aw-path-row">
            <input
              value={path}
              onChange={(e) => setPath(e.target.value)}
              placeholder="例如 C:\Users\you\projects\my-app"
              className="aw-path-input"
            />
            <button
              type="button"
              className="aw-path-btn"
              title="选择文件夹"
              aria-label="选择文件夹"
              onClick={() => setPickerOpen(true)}
            >
              <FolderIcon size={16} />
            </button>
          </div>
        </label>
        <div className="aw-field-hint">输入项目目录的绝对路径，或使用文件夹按钮选择。</div>

        <label className="field">
          <span>说明（可选）</span>
          <input
            value={desc}
            onChange={(e) => setDesc(e.target.value)}
            placeholder="项目简要说明"
          />
        </label>

        {error && <div className="apm-msg apm-msg-error">{error}</div>}

        <button
          type="button"
          className="apm-submit"
          onClick={submit}
          disabled={submitting}
        >
          {submitting ? (
            <span className="apm-spinner" aria-hidden />
          ) : (
            <FolderIcon size={15} />
          )}
          <span>{submitting ? "处理中…" : "添加工作区"}</span>
        </button>
      </div>

      {pickerOpen && (
        <DirPicker
          initialPath={path.trim()}
          onPick={(p) => {
            setPath(p);
            setPickerOpen(false);
            setError(null);
          }}
          onClose={() => setPickerOpen(false)}
        />
      )}
    </div>
  );
}
