import { marked } from "marked";

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

const renderer = new marked.Renderer();
renderer.code = ({ text, lang }: { text: string; lang?: string }) => {
  const language = lang || "text";
  return `<div class="codeblock"><div class="codeblock-head"><span>${escapeHtml(
    language
  )}</span><button class="copy-btn" type="button">复制</button></div><pre><code>${escapeHtml(
    text
  )}</code></pre></div>`;
};
marked.use({ renderer, breaks: true, gfm: true });

/** 轻量 Markdown 渲染（marked + 代码块复制按钮，事件委托） */
export function renderMarkdown(text: string): string {
  return marked.parse(text || "", { async: false }) as string;
}

export function handleCopyClick(e: React.MouseEvent): void {
  const target = e.target as HTMLElement;
  if (!target.classList.contains("copy-btn")) return;
  const block = target.closest(".codeblock");
  const code = block?.querySelector("code");
  if (code) {
    navigator.clipboard.writeText(code.textContent || "").then(() => {
      target.textContent = "已复制";
      setTimeout(() => (target.textContent = "复制"), 1200);
    });
  }
}
