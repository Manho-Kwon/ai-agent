import { useEffect, useMemo, useState } from "react";
import { api } from "../api";
import type { PageMeta } from "../types";
import { handleCopyClick, renderMarkdown } from "./Markdown";
import AddPageModal from "./AddPageModal";

interface Props {
  onClose: () => void;
}

function BookIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="16"
      height="16"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" />
      <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" />
    </svg>
  );
}

function SearchIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="15"
      height="15"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      aria-hidden
    >
      <circle cx="11" cy="11" r="7" />
      <line x1="21" y1="21" x2="16.2" y2="16.2" />
    </svg>
  );
}

function HomeIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="14"
      height="14"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <path d="M3 10.5 12 3l9 7.5" />
      <path d="M5 9.5V21h14V9.5" />
    </svg>
  );
}

function FileIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="16"
      height="16"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <rect x="5" y="3" width="14" height="18" rx="2" />
      <line x1="9" y1="8" x2="15" y2="8" />
      <line x1="9" y1="12" x2="15" y2="12" />
      <line x1="9" y1="16" x2="12" y2="16" />
    </svg>
  );
}

function FolderIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="17"
      height="17"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
    </svg>
  );
}

function GlobeIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="16"
      height="16"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <circle cx="12" cy="12" r="9" />
      <path d="M3 12h18" />
      <path d="M12 3a14 14 0 0 1 0 18 14 14 0 0 1 0-18z" />
    </svg>
  );
}

function ChevronIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="13"
      height="13"
      fill="none"
      stroke="currentColor"
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <polyline points="9 6 15 12 9 18" />
    </svg>
  );
}

function ExternalIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="13"
      height="13"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <path d="M15 4h5v5" />
      <path d="M10 14 20 4" />
      <path d="M20 13v5a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h5" />
    </svg>
  );
}

function TrashIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="13"
      height="13"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <polyline points="3 6 5 6 21 6" />
      <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
    </svg>
  );
}

function XIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="13"
      height="13"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.8}
      strokeLinecap="round"
      aria-hidden
    >
      <line x1="6" y1="6" x2="18" y2="18" />
      <line x1="18" y1="6" x2="6" y2="18" />
    </svg>
  );
}

const IMAGE_EXTS = [".png", ".jpg", ".jpeg", ".gif", ".webp", ".ico", ".bmp", ".avif", ".svg"];

function fmtSize(bytes: number): string {
  if (!Number.isFinite(bytes) || bytes < 0) return "—";
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

function hostOf(url?: string): string {
  if (!url) return "";
  try {
    return new URL(url, window.location.origin).host;
  } catch {
    return url;
  }
}

export default function LibraryPanel({ onClose }: Props) {
  const [pages, setPages] = useState<PageMeta[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [adding, setAdding] = useState(false);
  const [viewing, setViewing] = useState<PageMeta | null>(null);
  const [currentFolder, setCurrentFolder] = useState("");
  const [folderPath, setFolderPath] = useState<PageMeta[]>([]);

  const refresh = async () => {
    try {
      const { pages: list } = await api.listPages();
      setPages(list);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "加载资料库失败");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refresh();
  }, []);

  const kindOf = (p: PageMeta) => p.kind || "page";

  const childCount = useMemo(() => {
    const m = new Map<string, number>();
    for (const p of pages) {
      const pid = p.parent_id || "";
      m.set(pid, (m.get(pid) || 0) + 1);
    }
    return m;
  }, [pages]);

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (q) {
      // 搜索时跨文件夹匹配（标题 / 说明 / URL）
      return pages.filter(
        (p) =>
          p.title.toLowerCase().includes(q) ||
          (p.description || "").toLowerCase().includes(q) ||
          (p.url || "").toLowerCase().includes(q)
      );
    }
    return pages.filter((p) => (p.parent_id || "") === currentFolder);
  }, [pages, query, currentFolder]);

  const enterFolder = (f: PageMeta) => {
    setQuery("");
    setCurrentFolder(f.id);
    setFolderPath((prev) => [...prev, f]);
  };

  const goToFolder = (index: number) => {
    // index = -1 → 根目录；否则进入路径中第 index 个文件夹
    setQuery("");
    if (index < 0) {
      setCurrentFolder("");
      setFolderPath([]);
    } else {
      setCurrentFolder(folderPath[index].id);
      setFolderPath(folderPath.slice(0, index + 1));
    }
  };

  const removePage = async (p: PageMeta) => {
    const isFolder = kindOf(p) === "folder";
    const n = isFolder ? childCount.get(p.id) || 0 : 0;
    const msg = isFolder
      ? n > 0
        ? `删除文件夹「${p.title}」？其中的 ${n} 个页面/子文件夹将一并删除。`
        : `删除空文件夹「${p.title}」？`
      : `删除页面「${p.title}」？`;
    if (!confirm(msg)) return;
    try {
      await api.deletePage(p.id);
      // 计算被删子树（文件夹级联），同步从本地列表移除（后端已实际删除）
      const ids = new Set<string>([p.id]);
      if (isFolder) {
        let grew = true;
        while (grew) {
          grew = false;
          for (const x of pages) {
            if (x.parent_id && ids.has(x.parent_id) && !ids.has(x.id)) {
              ids.add(x.id);
              grew = true;
            }
          }
        }
      }
      // 若当前正处在被删文件夹内部，退回根目录
      if (isFolder && (currentFolder === p.id || folderPath.some((f) => f.id === p.id))) {
        setCurrentFolder("");
        setFolderPath([]);
      }
      setPages((prev) => prev.filter((x) => !ids.has(x.id)));
      setViewing((v) => (v && (ids.has(v.id) || ids.has(v.parent_id || "")) ? null : v));
    } catch (e) {
      setError(e instanceof Error ? e.message : "删除失败");
    }
  };

  const openView = async (p: PageMeta) => {
    try {
      const full = await api.getPage(p.id);
      setViewing(full);
    } catch (e) {
      setError(e instanceof Error ? e.message : "加载页面失败");
    }
  };

  const handleCreated = (page: PageMeta) => {
    setAdding(false);
    setPages((prev) => [page, ...prev]);
    // 新建文件夹后直接进入
    if (kindOf(page) === "folder" && (page.parent_id || "") === currentFolder) {
      setFolderPath((prev) => [...prev, page]);
      setCurrentFolder(page.id);
    }
  };

  const viewingIsImage =
    viewing && kindOf(viewing) === "file" &&
    IMAGE_EXTS.some((e) => (viewing.file_name || viewing.url || "").toLowerCase().includes(e));
  const viewingIsFrame =
    viewing &&
    (kindOf(viewing) === "bookmark" ||
      (kindOf(viewing) === "file" && /\.html?$/i.test(viewing.url || viewing.file_name || "")));

  return (
    <main className="library-panel">
      <div className="lib-head">
        <div className="lib-title-wrap">
          <div className="lib-title">
            <span className="lib-title-icon">
              <BookIcon />
            </span>
            资料库
          </div>
          <div className="lib-sub">HTML 页面、URL 书签和文件夹管理</div>
        </div>
        <button
          className="sb-icon-btn"
          onClick={onClose}
          title="返回对话"
          type="button"
          aria-label="返回对话"
        >
          <XIcon />
        </button>
      </div>

      <div className="lib-toolbar">
        <div className="lib-search">
          <SearchIcon />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="搜索页面名称、说明或 URL..."
            aria-label="搜索页面"
          />
        </div>
        <button className="lib-add" onClick={() => setAdding(true)} type="button">
          + 添加页面
        </button>
      </div>

      <div className="lib-root lib-crumbs">
        <button type="button" className="lib-crumb" onClick={() => goToFolder(-1)}>
          <HomeIcon />
          <span>根目录</span>
        </button>
        {folderPath.map((f, i) => (
          <span key={f.id} className="lib-crumb-seg">
            <ChevronIcon />
            <button
              type="button"
              className="lib-crumb"
              onClick={() => goToFolder(i)}
            >
              {f.title}
            </button>
          </span>
        ))}
      </div>

      {error && <div className="lib-error">{error}</div>}

      <div className="lib-list">
        {loading ? (
          <div className="lib-empty">加载中…</div>
        ) : visible.length === 0 ? (
          <div className="lib-empty">
            {query
              ? "没有匹配的页面"
              : currentFolder
                ? "此文件夹为空：点击右上角「+ 添加页面」在此创建内容"
                : "暂无页面：新会话产生的输出结果文件会自动保存到这里，也可点击右上角「+ 添加页面」手动添加"}
          </div>
        ) : (
          visible.map((p) => {
            const kind = kindOf(p);
            const isFolder = kind === "folder";
            return (
              <div
                key={p.id}
                className="lib-item"
                onClick={() => (isFolder ? enterFolder(p) : openView(p))}
                title={
                  isFolder
                    ? `文件夹 · ${childCount.get(p.id) || 0} 项`
                    : p.url
                      ? p.url
                      : p.source
                        ? `来自：${p.source}`
                        : p.title
                }
              >
                <span className={`lib-dot${isFolder ? " lib-dot-folder" : ""}`} />
                <span
                  className={`lib-file-icon ${
                    isFolder ? "lib-icon-folder" : kind === "bookmark" ? "lib-icon-link" : ""
                  }`}
                >
                  {isFolder ? <FolderIcon /> : kind === "bookmark" ? <GlobeIcon /> : <FileIcon />}
                </span>
                <span className="lib-name">{p.title}</span>
                {kind === "bookmark" && <span className="lib-host">{hostOf(p.url)}</span>}
                {isFolder && (
                  <span className="lib-size">{childCount.get(p.id) || 0} 项</span>
                )}
                {!isFolder && kind !== "bookmark" && (
                  <span className="lib-size">{fmtSize(p.size)}</span>
                )}
                {isFolder && <span className="lib-chevron"><ChevronIcon /></span>}
                <button
                  className="lib-del"
                  title={isFolder ? "删除文件夹" : "删除页面"}
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation();
                    removePage(p);
                  }}
                >
                  <TrashIcon />
                </button>
              </div>
            );
          })
        )}
      </div>

      {adding && (
        <AddPageModal
          parentId={currentFolder}
          parentName={folderPath.length ? folderPath[folderPath.length - 1].title : ""}
          onClose={() => setAdding(false)}
          onCreated={handleCreated}
        />
      )}

      {viewing && (
        <div className="lib-modal-mask" onClick={() => setViewing(null)}>
          <div className="lib-modal lib-view" onClick={(e) => e.stopPropagation()}>
            <div className="lib-modal-head">
              <span className="lib-view-title">{viewing.title}</span>
              <button
                className="sb-icon-btn"
                onClick={() => setViewing(null)}
                title="关闭"
                type="button"
              >
                <XIcon />
              </button>
            </div>
            <div className="lib-view-meta">
              {kindOf(viewing) === "folder"
                ? "文件夹"
                : kindOf(viewing) === "bookmark"
                  ? viewing.hosted
                    ? "托管页面"
                    : "URL 书签"
                  : fmtSize(viewing.size)}
              {viewing.description ? ` · ${viewing.description}` : ""}
              {viewing.source ? ` · 来自 ${viewing.source}` : ""}
            </div>

            {(viewingIsFrame || viewing?.url) && (
              <div className="lib-view-bar">
                <a
                  className="lib-view-open"
                  href={viewing.url}
                  target="_blank"
                  rel="noreferrer"
                >
                  <ExternalIcon />
                  在新标签页打开
                </a>
              </div>
            )}

            {viewingIsFrame ? (
              <iframe
                className="lib-view-frame"
                src={viewing.url}
                title={viewing.title}
                sandbox="allow-scripts allow-same-origin allow-forms allow-popups allow-downloads"
              />
            ) : viewingIsImage ? (
              <div className="lib-view-img-wrap">
                <img className="lib-view-img" src={viewing.url} alt={viewing.title} />
              </div>
            ) : kindOf(viewing) === "file" ? (
              <div className="lib-view-file">
                <p>该文件类型不支持在线预览。</p>
                <a
                  className="lib-view-open"
                  href={viewing.url}
                  target="_blank"
                  rel="noreferrer"
                >
                  <ExternalIcon />
                  打开 / 下载文件（{viewing.file_name}）
                </a>
              </div>
            ) : (
              <div
                className="lib-view-body md-body"
                onClick={handleCopyClick}
                dangerouslySetInnerHTML={{
                  __html: renderMarkdown(viewing.content || ""),
                }}
              />
            )}
          </div>
        </div>
      )}
    </main>
  );
}
