import type { ReactNode } from "react";

interface Props {
  title: string;
  subtitle: string;
  onClose: () => void;
  children: ReactNode;
  /** 底部操作条（如 LLM 配置的保存栏） */
  footer?: ReactNode;
}

/** 设置子页面共用外壳：左上角返回箭头 + 标题/副标题 + 内容区 */
export default function SettingsShell({ title, subtitle, onClose, children, footer }: Props) {
  return (
    <main className="setpage">
      <div className="sp-head">
        <button
          className="sp-back"
          onClick={onClose}
          title="返回"
          type="button"
          aria-label="返回"
        >
          <svg
            viewBox="0 0 24 24"
            width="18"
            height="18"
            fill="none"
            stroke="currentColor"
            strokeWidth={2}
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden
          >
            <polyline points="15 18 9 12 15 6" />
          </svg>
        </button>
        <div className="sp-head-text">
          <div className="sp-title">{title}</div>
          <div className="sp-sub">{subtitle}</div>
        </div>
      </div>
      <div className="sp-body">{children}</div>
      {footer}
    </main>
  );
}
