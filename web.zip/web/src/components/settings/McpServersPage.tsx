import { useCallback, useEffect, useState } from "react";
import { api } from "../../api";
import type { McpServer } from "../../types";
import SettingsShell from "./SettingsShell";

interface Props {
  onClose: () => void;
  /** 增删/开关后同步 App 的 ToolPanel 状态 */
  onChanged?: () => void;
}

const FolderIcon = () => (
  <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <path d="M4 20h16a1 1 0 0 0 1-1V8a1 1 0 0 0-1-1h-8L10 4H4a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1z" />
  </svg>
);

const RefreshIcon = () => (
  <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <polyline points="23 4 23 10 17 10" />
    <polyline points="1 20 1 14 7 14" />
    <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
  </svg>
);

const PlusIcon = () => (
  <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor" aria-hidden>
    <path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z" />
  </svg>
);

const SearchIcon = () => (
  <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" aria-hidden>
    <circle cx="11" cy="11" r="7" />
    <path d="m20 20-3.5-3.5" />
  </svg>
);

const CloseIcon = () => (
  <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" aria-hidden>
    <line x1="6" y1="6" x2="18" y2="18" />
    <line x1="18" y1="6" x2="6" y2="18" />
  </svg>
);

/** 状态点：已连接绿 / 启用未连琥珀 / 停用灰 */
function dotClass(s: McpServer): string {
  if (!s.enabled) return "dot-gray";
  return s.status === "connected" ? "dot-green" : "dot-amber";
}

export default function McpServersPage({ onClose, onChanged }: Props) {
  const [servers, setServers] = useState<McpServer[]>([]);
  const [configPath, setConfigPath] = useState("");
  const [configError, setConfigError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  // 添加服务器弹窗
  const [addOpen, setAddOpen] = useState(false);
  const [name, setName] = useState("");
  const [transport, setTransport] = useState("stdio");
  const [command, setCommand] = useState("");
  const [argsStr, setArgsStr] = useState("");
  const [url, setUrl] = useState("");
  const [formErr, setFormErr] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      const data = await api.mcpServers();
      setServers(data.servers);
      setConfigPath(data.config_path || "");
      setConfigError(data.config_error);
    } catch (e) {
      setNotice((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  // 添加/开关后的热重载在后台进行，延迟再刷一次让状态落定
  const refreshSoon = useCallback(() => {
    const t = setTimeout(() => {
      refresh();
    }, 2500);
    return () => clearTimeout(t);
  }, [refresh]);

  const toggle = async (s: McpServer) => {
    setBusy(true);
    setNotice(null);
    try {
      await api.setMcpEnabled(s.name, !s.enabled);
      await refresh();
      refreshSoon();
      onChanged?.();
    } catch (e) {
      setNotice((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const reload = async () => {
    setBusy(true);
    setNotice(null);
    try {
      await api.mcpReload();
      await refresh();
      onChanged?.();
      setNotice("已重新加载配置");
    } catch (e) {
      setNotice((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const openFolder = async () => {
    try {
      await api.mcpOpenConfigFolder();
    } catch (e) {
      setNotice((e as Error).message);
    }
  };

  const submitAdd = async () => {
    setFormErr(null);
    if (!name.trim()) {
      setFormErr("请输入服务器名称");
      return;
    }
    if (transport === "stdio" && !command.trim()) {
      setFormErr("stdio 传输必须填写启动命令");
      return;
    }
    if (transport !== "stdio" && !url.trim()) {
      setFormErr("该传输方式必须填写 URL");
      return;
    }
    setBusy(true);
    try {
      await api.mcpAddServer({
        name: name.trim(),
        transport,
        command: command.trim() || undefined,
        args: argsStr
          .split(/\s+/)
          .map((a) => a.trim())
          .filter(Boolean),
        url: url.trim() || undefined,
      });
      setAddOpen(false);
      setName("");
      setCommand("");
      setArgsStr("");
      setUrl("");
      setTransport("stdio");
      await refresh();
      refreshSoon();
      onChanged?.();
      setNotice(`已添加服务器「${name.trim()}」`);
    } catch (e) {
      setFormErr((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const q = query.trim().toLowerCase();
  const filtered = servers.filter(
    (s) =>
      !q ||
      s.name.toLowerCase().includes(q) ||
      (s.transport || "").toLowerCase().includes(q)
  );

  return (
    <SettingsShell
      title="MCP 服务器"
      subtitle="Model Context Protocol 服务器注册与管理"
      onClose={onClose}
    >
      <div className="sl-toolbar">
        <div className="sl-search">
          <SearchIcon />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="搜索服务器名称或传输方式..."
          />
        </div>
        <div className="sl-actions">
          <button type="button" className="sp-btn-ghost" onClick={reload} disabled={busy}>
            <RefreshIcon />
            重新加载配置
          </button>
          <button type="button" className="sp-btn-primary" onClick={() => setAddOpen(true)}>
            <PlusIcon />
            添加服务器
          </button>
        </div>
      </div>

      <div className="sl-cfg-card">
        <span className="sl-cfg-icon">
          <FolderIcon />
        </span>
        <span className="sl-cfg-label">配置</span>
        <span className="sl-cfg-path cn-mono">{configPath || "…"}</span>
        <button type="button" className="sp-btn-ghost" onClick={openFolder}>
          <FolderIcon />
          打开配置文件夹
        </button>
      </div>

      {configError && <div className="sp-err-inline sl-block">{configError}</div>}
      {notice && <div className="sp-ok-inline sl-block">{notice}</div>}

      <div className="sl-list">
        {loading ? (
          <div className="sl-empty">
            <div className="sl-empty-title">正在加载服务器…</div>
          </div>
        ) : filtered.length === 0 ? (
          <div className="sl-empty">
            <span className="sl-empty-icon">
              <svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" strokeWidth={1.6} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
                <rect x="2" y="3" width="20" height="8" rx="2" />
                <rect x="2" y="13" width="20" height="8" rx="2" />
                <line x1="6" y1="7" x2="6.01" y2="7" />
                <line x1="6" y1="17" x2="6.01" y2="17" />
              </svg>
            </span>
            <div className="sl-empty-title">
              {servers.length === 0 ? "没有 MCP 服务器" : "没有匹配的服务器"}
            </div>
            <div className="sl-empty-desc">
              {servers.length === 0
                ? "添加一个 MCP 服务器以扩展智能体的工具能力。"
                : "尝试其他搜索关键词。"}
            </div>
          </div>
        ) : (
          filtered.map((s) => (
            <div className="sl-row" key={s.name}>
              <span className={`status-dot ${dotClass(s)}`} />
              <span className="sl-name">{s.name}</span>
              <span className="sl-badge cn-mono">
                <span className="sl-badge-gt">&gt;_</span> {s.transport}
              </span>
              <span className="sl-meta cn-mono">工具： {s.tools.length}</span>
              <span className="sl-row-right">
                <button
                  type="button"
                  className={`set-toggle ${s.enabled ? "on" : ""}`}
                  role="switch"
                  aria-checked={s.enabled}
                  aria-label={`开关 ${s.name}`}
                  disabled={busy}
                  onClick={() => toggle(s)}
                >
                  <span className="set-toggle-thumb" />
                </button>
              </span>
            </div>
          ))
        )}
      </div>

      {addOpen && (
        <>
          <div className="pop-backdrop" onClick={() => setAddOpen(false)} />
          <div className="slm-backdrop" onClick={() => setAddOpen(false)}>
            <div className="slm-panel" onClick={(e) => e.stopPropagation()}>
              <div className="slm-head">
                <div className="slm-title">添加 MCP 服务器</div>
                <button type="button" className="icon-btn" onClick={() => setAddOpen(false)} aria-label="关闭">
                  <CloseIcon />
                </button>
              </div>
              <div className="slm-body">
                <label className="sp-field">
                  <span className="sp-field-label">名称 *</span>
                  <input
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="例如 filesystem"
                    autoFocus
                  />
                </label>
                <label className="sp-field">
                  <span className="sp-field-label">传输方式</span>
                  <select value={transport} onChange={(e) => setTransport(e.target.value)}>
                    <option value="stdio">stdio（本地进程）</option>
                    <option value="http">http（远程 URL）</option>
                    <option value="sse">sse（远程 URL）</option>
                  </select>
                </label>
                {transport === "stdio" ? (
                  <>
                    <label className="sp-field">
                      <span className="sp-field-label">启动命令 *</span>
                      <input
                        value={command}
                        onChange={(e) => setCommand(e.target.value)}
                        placeholder="例如 npx"
                      />
                    </label>
                    <label className="sp-field">
                      <span className="sp-field-label">参数（空格分隔）</span>
                      <input
                        value={argsStr}
                        onChange={(e) => setArgsStr(e.target.value)}
                        placeholder="例如 -y @modelcontextprotocol/server-filesystem /tmp"
                      />
                    </label>
                  </>
                ) : (
                  <label className="sp-field">
                    <span className="sp-field-label">URL *</span>
                    <input
                      value={url}
                      onChange={(e) => setUrl(e.target.value)}
                      placeholder="例如 http://127.0.0.1:8000/mcp"
                    />
                  </label>
                )}
                {formErr && <div className="sp-err-inline">{formErr}</div>}
              </div>
              <div className="slm-foot">
                <button type="button" className="sp-btn-ghost" onClick={() => setAddOpen(false)}>
                  取消
                </button>
                <button type="button" className="sp-btn-primary" onClick={submitAdd} disabled={busy}>
                  添加
                </button>
              </div>
            </div>
          </div>
        </>
      )}
    </SettingsShell>
  );
}
