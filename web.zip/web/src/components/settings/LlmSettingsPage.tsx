import { useEffect, useMemo, useRef, useState } from "react";
import { api } from "../../api";
import type { ConnectionsState, Settings } from "../../types";
import SettingsShell from "./SettingsShell";
import ModelConnectionsModal from "./ModelConnectionsModal";

interface Props {
  settings: Settings;
  onClose: () => void;
  /** 保存成功后由 App 重新拉取设置 */
  onSaved: () => Promise<void> | void;
}

/** 共享模型覆盖的角色（与后端 ROLE_ORDER 一致，面包屑顺序） */
const SHARED_KEYS = ["planner", "executor", "evaluator", "doc_compose", "doc_parse", "multimodal"];
const SHARED_LABELS = ["规划代理", "执行代理", "评估代理", "文档 AI · Compose", "文档解析", "多模态后备"];

/** 「按角色分配模型」行定义（顺序与文案严格对齐设计稿） */
interface RoleRow {
  key: string;
  name: string;
  desc: string;
  field: string;
  toggle?: boolean;
}
const ROLE_ROWS: RoleRow[] = [
  { key: "planner", name: "Planner · 规划", desc: "制定计划", field: "Planner 模型 *" },
  { key: "executor", name: "Executor · 执行", desc: "运行工具", field: "Executor 模型 *" },
  {
    key: "executor_recovery",
    name: "Executor · 恢复",
    desc: "工具反复失败后使用",
    field: "恢复 Executor 模型 *",
  },
  { key: "evaluator", name: "Evaluator · 评估", desc: "验证质量", field: "Evaluator 模型 *", toggle: true },
  {
    key: "doc_compose",
    name: "文档 AI · Compose",
    desc: "整理文本、表格结构化、摘要、校对、自定义指令和文档重构",
    field: "文档 AI 模型 *",
  },
  {
    key: "doc_parse",
    name: "文档解析",
    desc: "将文档页面和图像转换为 Markdown",
    field: "解析模型 *",
  },
  {
    key: "multimodal",
    name: "多模态后备",
    desc: "处理主要解析模型无法读取的图像",
    field: "多模态后备模型 *",
  },
];

/** 选择器选项："" = 跟随默认；cm_xxx = 自定义模型；gw:<model> = 网关指定模型 */
interface PickerOpt {
  value: string;
  title: string;
  sub: string;
  group?: string;
}

interface FormState {
  shared: string;
  roles: Record<string, string>;
  evaluatorEnabled: boolean;
  temperature: number;
  instructions: string;
}

function roleValue(s: Settings, conn: ConnectionsState | null, key: string): string {
  const spec = s.roles?.[key];
  const prov = spec?.provider || "default";
  if (prov !== "default") {
    const exists = conn?.providers
      .find((p) => p.kind === "custom")
      ?.models?.some((m) => m.id === prov);
    return exists ? prov : "";
  }
  const m = spec?.model;
  return m && m !== "(未配置)" ? `gw:${m}` : "";
}

function deriveShared(s: Settings, conn: ConnectionsState | null): string {
  const roles = SHARED_KEYS.map((k) => s.roles?.[k]);
  const providers = roles.map((r) => r?.provider || "default");
  const models = roles.map((r) => (r?.model && r.model !== "(未配置)" ? r.model : ""));
  if (!providers.every((p) => p === providers[0])) return "";
  if (providers[0] !== "default") {
    const custom = conn?.providers.find((p) => p.kind === "custom");
    if (custom?.models?.some((m) => m.id === providers[0])) return providers[0];
    return "";
  }
  const m = models[0];
  if (m && models.every((x) => x === m)) return `gw:${m}`;
  return "";
}

function formFrom(s: Settings, conn: ConnectionsState | null): FormState {
  const roles: Record<string, string> = {};
  for (const row of ROLE_ROWS) roles[row.key] = roleValue(s, conn, row.key);
  return {
    shared: deriveShared(s, conn),
    roles,
    evaluatorEnabled: s.evaluator?.enabled ?? true,
    temperature: s.llm.temperature,
    instructions: s.ui.executor_instructions || "",
  };
}

/** 值 → 后端 roles 条目 */
function specOf(value: string): { provider: string; model: string } {
  if (value.startsWith("gw:")) return { provider: "default", model: value.slice(3) };
  if (value) return { provider: value, model: "" };
  return { provider: "default", model: "" };
}

const LinkIcon = () => (
  <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor"
    strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" />
    <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" />
  </svg>
);

const ChevronIcon = ({ className = "" }: { className?: string }) => (
  <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor"
    strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden>
    <polyline points="6 9 12 15 18 9" />
  </svg>
);

/** 双行模型选择器（闭合态显示模型名 + 端点·模型ID，展开为分组下拉） */
function ModelPicker({
  value,
  options,
  onPick,
}: {
  value: string;
  options: PickerOpt[];
  onPick: (v: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const selected = options.find((o) => o.value === value);
  const groups = useMemo(() => {
    const map = new Map<string, PickerOpt[]>();
    for (const o of options) {
      if (!o.group) continue;
      if (!map.has(o.group)) map.set(o.group, []);
      map.get(o.group)!.push(o);
    }
    return [...map.entries()];
  }, [options]);
  const plain = options.filter((o) => !o.group);

  return (
    <div className="mc-picker">
      <button
        type="button"
        className={`mc-picker-btn${open ? " open" : ""}`}
        onClick={() => setOpen((v) => !v)}
        aria-haspopup="listbox"
        aria-expanded={open}
      >
        <span className="mc-picker-text">
          <span className="mc-picker-title">{selected?.title || value || "未配置"}</span>
          <span className="mc-picker-sub">{selected?.sub || " "}</span>
        </span>
        <ChevronIcon className="mc-picker-chevron" />
      </button>
      {open && (
        <>
          <div className="pop-backdrop" onClick={() => setOpen(false)} />
          <div className="mc-picker-pop" role="listbox">
            {plain.map((o) => (
              <button
                type="button"
                key={o.value || "__default"}
                className={`mc-picker-opt${o.value === value ? " sel" : ""}`}
                onClick={() => {
                  onPick(o.value);
                  setOpen(false);
                }}
              >
                <span className="mc-picker-opt-title">{o.title}</span>
                <span className="mc-picker-opt-sub">{o.sub}</span>
              </button>
            ))}
            {groups.map(([g, items]) => (
              <div key={g} className="mc-picker-group">
                <div className="mc-picker-group-label">{g}</div>
                {items.map((o) => (
                  <button
                    type="button"
                    key={o.value}
                    className={`mc-picker-opt${o.value === value ? " sel" : ""}`}
                    onClick={() => {
                      onPick(o.value);
                      setOpen(false);
                    }}
                  >
                    <span className="mc-picker-opt-title">{o.title}</span>
                    <span className="mc-picker-opt-sub">{o.sub}</span>
                  </button>
                ))}
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

export default function LlmSettingsPage({ settings, onClose, onSaved }: Props) {
  const [conn, setConn] = useState<ConnectionsState | null>(null);
  const [form, setForm] = useState<FormState>(() => formFrom(settings, null));
  const [snapshot, setSnapshot] = useState<string>(() => JSON.stringify(formFrom(settings, null)));
  const [assignMode, setAssignMode] = useState<"shared" | "perrole">("shared");
  const [models, setModels] = useState<string[]>([]);
  const [probing, setProbing] = useState(false);
  const [probeMsg, setProbeMsg] = useState<string | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [savedOk, setSavedOk] = useState(false);
  const [errMsg, setErrMsg] = useState<string | null>(null);
  const loadErrRef = useRef(false);

  const dirty = useMemo(() => JSON.stringify(form) !== snapshot, [form, snapshot]);

  const loadConn = async () => {
    try {
      const data = await api.connections();
      setConn(data);
      setForm((f) => ({
        ...f,
        shared: f.shared || deriveShared(settings, data),
        roles: Object.fromEntries(
          ROLE_ROWS.map((r) => [r.key, f.roles[r.key] || roleValue(settings, data, r.key)]),
        ),
      }));
    } catch {
      /* 连接状态加载失败不阻塞页面 */
    }
  };

  // 进入页面：拉连接状态 + 静默探测网关模型
  useEffect(() => {
    loadConn();
    let alive = true;
    setProbing(true);
    api
      .probeGateway()
      .then((r) => {
        if (!alive) return;
        if (r.ok && r.models) {
          setModels(r.models);
          setProbeMsg(`默认网关已发现 ${r.models.length} 个模型`);
        } else {
          loadErrRef.current = true;
          setProbeMsg(r.error || "默认网关尚未连接，可在「管理模型连接」中配置");
        }
      })
      .catch(() => alive && setProbeMsg("默认网关探测失败，可在「管理模型连接」中配置"))
      .finally(() => alive && setProbing(false));
    return () => {
      alive = false;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const custom = conn?.providers.find((p) => p.kind === "custom");
  const customModels = custom?.models ?? [];
  const connectedCount = custom?.connected_count ?? 0;

  /** 模型选择器选项（共享 / 逐角色共用） */
  const pickerOptions = useMemo<PickerOpt[]>(() => {
    const opts: PickerOpt[] = [
      {
        value: "",
        title: settings.llm.model ? `跟随默认（${settings.llm.model}）` : "跟随默认网关模型",
        sub: settings.llm.base_url || "—",
      },
    ];
    for (const m of customModels) {
      opts.push({
        value: m.id,
        title: m.label,
        sub: `${m.base_url} · 自定义 · ${m.model}${m.status !== "connected" ? " · 未连接" : ""}`,
        group: "自定义 / 自托管",
      });
    }
    for (const m of models) {
      opts.push({
        value: `gw:${m}`,
        title: m,
        sub: `${settings.llm.base_url} · 默认网关`,
        group: "默认网关",
      });
    }
    return opts;
  }, [customModels, models, settings.llm.base_url, settings.llm.model]);

  const discard = () => {
    const f = formFrom(settings, conn);
    setForm(f);
    setSnapshot(JSON.stringify(f));
    setSavedOk(false);
    setErrMsg(null);
  };

  const save = async () => {
    setSaving(true);
    setErrMsg(null);
    try {
      const rolesPayload: Record<string, { provider: string; model: string }> = {};
      if (assignMode === "shared") {
        // 共享模型：6 个应用角色统一；恢复执行者保持其独立配置
        for (const k of SHARED_KEYS) rolesPayload[k] = specOf(form.shared);
      } else {
        for (const row of ROLE_ROWS) rolesPayload[row.key] = specOf(form.roles[row.key] || "");
      }
      await api.saveSettings({
        temperature: form.temperature,
        roles: rolesPayload,
        evaluator_enabled: form.evaluatorEnabled,
        ui: { executor_instructions: form.instructions },
      });
      await onSaved();
      await loadConn();
      setSnapshot(JSON.stringify(form));
      setSavedOk(true);
      setTimeout(() => setSavedOk(false), 2000);
    } catch (e) {
      setErrMsg((e as Error).message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <SettingsShell
      title="LLM 设置"
      subtitle="管理模型连接和各角色的执行方式。"
      onClose={onClose}
      footer={
        <div className="sp-footer sp-footer-bar">
          <span className="sp-footer-note">
            {saving ? "保存中…" : savedOk ? "更改已保存。" : dirty ? "更改尚未保存。" : "所有更改已保存。"}
          </span>
          <div className="sp-footer-actions">
            <button type="button" className="sp-btn-ghost" onClick={discard} disabled={!dirty || saving}>
              放弃更改
            </button>
            <button type="button" className="sp-btn-primary mc-save-btn" onClick={save} disabled={!dirty || saving}>
              {saving ? "保存中…" : "保存 LLM 设置"}
            </button>
          </div>
        </div>
      }
    >
      {errMsg && <div className="sp-err-inline sl-block">{errMsg}</div>}

      {/* ── 1 模型连接 ── */}
      <div className="sp-card sp-pad mc-step-card">
        <div className="mc-step-head">
          <span className="mc-step-badge">1</span>
          <div>
            <div className="sp-card-title">模型连接</div>
            <div className="llm-role-desc">连接 API 密钥或内部端点后，即可把模型分配给角色。</div>
          </div>
        </div>

        <div className="mc-conn-pill">
          <span className={`status-dot ${connectedCount > 0 ? "dot-green" : "dot-gray"}`} />
          <span className="mc-conn-pill-text">
            {connectedCount > 0
              ? `自定义 / 自托管 已连接 · ${connectedCount} 个模型`
              : settings.llm.api_key_set
                ? "默认网关密钥已配置，尚未验证"
                : "尚未连接任何模型提供商"}
          </span>
          <button type="button" className="sp-btn-ghost mc-manage-btn" onClick={() => setModalOpen(true)}>
            <LinkIcon />
            管理模型连接
          </button>
        </div>
        <div className="mc-conn-time">
          {conn?.last_checked
            ? `最近检查：${new Date(conn.last_checked).toLocaleString("zh-CN", { hour12: false })}`
            : "最近检查：尚未检查"}
        </div>
      </div>

      {/* ── 2 模型分配 ── */}
      <div className="sp-card sp-pad mc-step-card">
        <div className="mc-step-head">
          <span className="mc-step-badge">2</span>
          <div>
            <div className="sp-card-title">模型分配</div>
            <div className="llm-role-desc">选择用于智能体、文档 AI 和多模态解析的模型。</div>
          </div>
        </div>

        {/* 分段切换：共享模型 / 按角色分配模型 */}
        <div className="mc-tabs" role="tablist">
          <button
            type="button"
            role="tab"
            aria-selected={assignMode === "shared"}
            className={`mc-tab${assignMode === "shared" ? " active" : ""}`}
            onClick={() => setAssignMode("shared")}
          >
            共享模型
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={assignMode === "perrole"}
            className={`mc-tab${assignMode === "perrole" ? " active" : ""}`}
            onClick={() => setAssignMode("perrole")}
          >
            按角色分配模型
          </button>
        </div>

        <p className="mc-tab-desc">
          {assignMode === "shared"
            ? "智能体、文档 AI 和解析使用同一模型，同时保留各任务的执行方式。"
            : "为智能体和文档工作流分配不同模型。"}
        </p>

        <div className="mc-info-strip">推理深度和质量检查会根据请求的复杂度与风险自动调整。</div>

        {assignMode === "shared" ? (
          <div className="mc-tab-panel">
            <label className="sp-field">
              <span className="sp-field-label">共享模型 *</span>
              <ModelPicker
                value={form.shared}
                options={pickerOptions}
                onPick={(v) => setForm({ ...form, shared: v })}
              />
            </label>
            <div className="mc-assign-roles">
              <span className="mc-assign-roles-label">应用角色</span>
              {SHARED_LABELS.map((r, i) => (
                <span className="mc-crumb" key={r}>
                  {r}
                  {i < SHARED_LABELS.length - 1 && <span className="mc-crumb-sep">›</span>}
                </span>
              ))}
            </div>
            {probeMsg && <div className="mc-probe-hint">{probing ? "正在探测默认网关…" : probeMsg}</div>}
          </div>
        ) : (
          <div className="mc-tab-panel">
            <div className="mc-role-list">
              {ROLE_ROWS.map((row) => (
                <div className="mc-role-row" key={row.key}>
                  <div className="mc-role-id">
                    <div className="mc-role-name">{row.name}</div>
                    <div className="mc-role-desc">{row.desc}</div>
                  </div>
                  <div className="mc-role-main">
                    <div className="mc-role-field-label">{row.field}</div>
                    <div className="mc-role-field">
                      <ModelPicker
                        value={form.roles[row.key] || ""}
                        options={pickerOptions}
                        onPick={(v) => setForm({ ...form, roles: { ...form.roles, [row.key]: v } })}
                      />
                      {row.toggle && (
                        <div className="mc-eval-toggle">
                          <button
                            type="button"
                            className={`set-toggle ${form.evaluatorEnabled ? "on" : ""}`}
                            role="switch"
                            aria-checked={form.evaluatorEnabled}
                            aria-label="启用评估"
                            onClick={() => setForm({ ...form, evaluatorEnabled: !form.evaluatorEnabled })}
                          >
                            <span className="set-toggle-thumb" />
                          </button>
                          <span className="mc-eval-toggle-label">启用评估</span>
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
            {probeMsg && <div className="mc-probe-hint">{probing ? "正在探测默认网关…" : probeMsg}</div>}
          </div>
        )}
      </div>

      {/* ── 3 高级设置 ── */}
      <div className="sp-card sp-pad">
        <div className="llm-adv-head">
          <span className="llm-adv-badge">3</span>
          <div>
            <div className="sp-card-title">高级设置</div>
            <div className="llm-role-desc">
              执行预算、推理深度和上下文管理均为自动。这里只保留响应偏好。
            </div>
          </div>
        </div>

        <div className="llm-temp-head">
          <div>
            <div className="llm-temp-title">响应多样性</div>
            <div className="llm-role-desc">数值越低越一致，越高则响应越多样。</div>
          </div>
          <span className="sp-font-value">{Number(form.temperature.toFixed(2))}</span>
        </div>
        <input
          className="sp-slider"
          type="range"
          min={0}
          max={2}
          step={0.05}
          value={form.temperature}
          onChange={(e) => setForm({ ...form, temperature: Number(e.target.value) })}
          aria-label="响应多样性"
        />

        <label className="sp-field">
          <span className="sp-field-label">Executor 系统指令</span>
          <textarea
            rows={4}
            value={form.instructions}
            placeholder="添加到 Executor 默认系统指令之前。"
            onChange={(e) => setForm({ ...form, instructions: e.target.value })}
          />
        </label>
      </div>

      {modalOpen && (
        <ModelConnectionsModal
          gatewayBaseUrl={settings.llm.base_url}
          onClose={() => setModalOpen(false)}
          onChanged={async () => {
            await loadConn();
            await onSaved();
          }}
        />
      )}
    </SettingsShell>
  );
}
