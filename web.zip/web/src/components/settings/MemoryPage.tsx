import { useEffect, useState } from "react";
import { api } from "../../api";
import SettingsShell from "./SettingsShell";

interface Props {
  enabled: boolean;
  onClose: () => void;
  /** 保存成功后由 App 重新拉取设置 */
  onSaved: () => Promise<void> | void;
}

const SaveIcon = () => (
  <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" />
    <path d="M17 21v-8H7v8" />
    <path d="M7 3v5h8" />
  </svg>
);

export default function MemoryPage({ enabled, onClose, onSaved }: Props) {
  const [on, setOn] = useState(enabled);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // 外部设置刷新后同步（如另一处修改）
  useEffect(() => {
    setOn(enabled);
  }, [enabled]);

  const save = async () => {
    setSaving(true);
    setError(null);
    try {
      await api.saveSettings({ memory_enabled: on });
      await onSaved();
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <SettingsShell
      title="记忆"
      subtitle="只需选择是否使用对话记忆。容量和上下文用量会自动管理。"
      onClose={onClose}
    >
      <div className="sp-card sp-row-card mm-card">
        <div className="sp-row-text">
          <div className="sp-row-title">自动记忆</div>
          <div className="sp-row-desc">自动从对话中提取记忆并注入系统提示词</div>
        </div>
        <button
          type="button"
          className={`set-toggle mm-toggle ${on ? "on" : ""}`}
          role="switch"
          aria-checked={on}
          aria-label="自动记忆"
          onClick={() => setOn((v) => !v)}
        >
          <span className="set-toggle-thumb" />
        </button>
      </div>

      <div className="mm-actions">
        <button type="button" className="mm-save-btn" onClick={save} disabled={saving}>
          <SaveIcon />
          {saving ? "保存中…" : "保存记忆设置"}
        </button>
        {saved && <span className="sp-ok-inline">已保存</span>}
        {error && <span className="sp-err-inline">{error}</span>}
      </div>
    </SettingsShell>
  );
}
