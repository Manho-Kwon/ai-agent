import { useCallback, useEffect, useState } from "react";
import { api } from "../../api";
import type { RetrievalStatus } from "../../types";
import SettingsShell from "./SettingsShell";

interface Props {
  onClose: () => void;
}

const CheckIcon = () => (
  <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <path d="M5 12.5 10 17.5 19 7" />
  </svg>
);

/** 与后端 _MODES 对齐 */
const MODE_LABEL: Record<string, string> = {
  auto: "自适应",
  fast: "快速",
  precise: "精确",
};

export default function WorkspaceRetrievalPage({ onClose }: Props) {
  const [status, setStatus] = useState<RetrievalStatus | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [modeOpen, setModeOpen] = useState(false);
  const [modeSaving, setModeSaving] = useState(false);

  const refresh = useCallback(async () => {
    setError(null);
    try {
      setStatus(await api.retrievalStatus());
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const setMode = async (mode: string) => {
    setModeOpen(false);
    if (!status || mode === status.mode) return;
    setModeSaving(true);
    setNotice(null);
    try {
      await api.setRetrievalMode(mode);
      await refresh();
      setNotice(`检索模式已切换为「${MODE_LABEL[mode] || mode}」`);
    } catch (e) {
      setNotice((e as Error).message);
    } finally {
      setModeSaving(false);
    }
  };

  const modeLabel = status ? MODE_LABEL[status.mode] || status.mode : "…";

  return (
    <SettingsShell
      title="工作区检索"
      subtitle="系统会自动选择可靠的搜索路径，并在此显示当前生效的策略。"
      onClose={onClose}
    >
      {/* 搜索运行模式 */}
      <div className="sp-card sp-pad">
        <div className="rt-mode-row">
          <div className="sp-row-text">
            <div className="sp-row-title">搜索运行模式</div>
            <div className="sp-row-desc">
              系统会根据文档规模和测得的质量自动选择检索深度、查询转换、嵌入、重排序与深度读取。
            </div>
          </div>
          <div className="rs-mode-wrap">
            <button
              type="button"
              className="rs-mode-badge"
              onClick={() => setModeOpen((v) => !v)}
              disabled={modeSaving || !status}
              aria-haspopup="listbox"
              aria-expanded={modeOpen}
            >
              <span className="rs-mode-check">
                <CheckIcon />
              </span>
              {modeLabel}
            </button>
            {modeOpen && status && (
              <>
                <div className="pop-backdrop" onClick={() => setModeOpen(false)} />
                <div className="rs-mode-menu" role="listbox">
                  {Object.entries(MODE_LABEL).map(([key, label]) => (
                    <button
                      key={key}
                      type="button"
                      role="option"
                      aria-selected={key === status.mode}
                      className={`rs-mode-item ${key === status.mode ? "active" : ""}`}
                      onClick={() => setMode(key)}
                    >
                      {label}
                      {key === status.mode && (
                        <span className="rs-mode-item-check">
                          <CheckIcon />
                        </span>
                      )}
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* 自动质量门控 */}
      <div className="sp-card sp-pad">
        <div className="rt-gate-head">
          <div className="sp-row-text">
            <div className="sp-row-title">自动质量门控</div>
            <div className="sp-row-desc">
              普通用户查询不视为答案。仅使用不含原文的 gold-set 评估指标来决定是否启用。
            </div>
          </div>
          <span className="rt-gate-badge">安全默认值</span>
        </div>

        {loading && <div className="rs-loading">正在读取语料库统计…</div>}
        {error && <div className="sp-err-inline sl-block">{error}</div>}
        {notice && <div className="sp-ok-inline sl-block">{notice}</div>}

        {status && (
          <>
            <div className="rt-grid2">
              <div className="rt-stat">
                <div className="rt-stat-label">当前语料库</div>
                <div className="rt-stat-value cn-mono">
                  {status.documents} 个文档 · {status.paragraphs} 个 passage
                </div>
              </div>
              <div className="rt-stat">
                <div className="rt-stat-label">有效深度</div>
                <div className="rt-stat-value cn-mono">
                  K{status.effective.k} · evidence {status.effective.evidence}
                </div>
                {status.effective.small_corpus && (
                  <div className="rt-stat-note">已应用小语料库的默认深度。</div>
                )}
              </div>
            </div>

            <div className="rt-grid2">
              <div className="rt-mini">
                <div className="rt-mini-head">
                  <span className="rt-mini-title">稠密向量投入</span>
                  <span className="rt-mini-state">{status.dense.enabled ? "开启" : "关闭"}</span>
                </div>
                <div className="rt-mini-desc">{status.dense.reason}</div>
              </div>
              <div className="rt-mini">
                <div className="rt-mini-head">
                  <span className="rt-mini-title">交叉编码器重排</span>
                  <span className="rt-mini-state">{status.reranker.enabled ? "开启" : "关闭"}</span>
                </div>
                <div className="rt-mini-desc">{status.reranker.reason}</div>
              </div>
            </div>

            <div className="rt-mini rt-wide">
              <div className="rt-mini-head">
                <span className="rt-mini-title">查询译解超时</span>
                <span className="rt-mini-state">默认值</span>
              </div>
              <div className="rt-stat-value cn-mono">
                {status.compile.timeout_s.toFixed(1)}秒 · 样本 {status.compile.samples} 个
              </div>
              <div className="rt-mini-desc">
                根据实测编译延迟的 p95 加余量确定 — 跟随随机与模型，而非固定值。
              </div>
            </div>

            <div className="rt-mini rt-wide">
              <div className="rt-mini-head">
                <span className="rt-mini-title">文档深度读取</span>
              </div>
              <div className="rt-stat-value">
                {status.deep_read === "adaptive" ? "自适应" : status.deep_read}
              </div>
              <div className="rt-mini-desc">
                对于复杂问题或 passage coverage 不足的情况，以 line evidence 重新选取相关文档。
              </div>
            </div>
          </>
        )}
      </div>
    </SettingsShell>
  );
}
