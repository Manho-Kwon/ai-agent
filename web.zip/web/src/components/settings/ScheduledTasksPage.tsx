import { useCallback, useEffect, useState } from "react";
import { api, type AutomationPayload } from "../../api";
import type { AutomationMeta } from "../../types";
import SettingsShell from "./SettingsShell";

interface Props {
  onClose: () => void;
}

const TimerIcon = () => (
  <svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" strokeWidth={1.6} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <line x1="10" y1="2" x2="14" y2="2" />
    <line x1="12" y1="14" x2="15" y2="11" />
    <circle cx="12" cy="14" r="8" />
  </svg>
);

const PlusIcon = () => (
  <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor" aria-hidden>
    <path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z" />
  </svg>
);

const SearchIcon = () => (
  <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" aria-hidden>
    <circle cx="11" cy="11" r="7" />
    <path d="m20 20-3.5-3.5" />
  </svg>
);

const CloseIcon = () => (
  <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" aria-hidden>
    <line x1="6" y1="6" x2="18" y2="18" />
    <line x1="18" y1="6" x2="6" y2="18" />
  </svg>
);

/** 调度描述：单次 / 每天 / 每周 */
function scheduleDesc(a: AutomationMeta): string {
  const s = a.schedule;
  if (s.type === "daily") return `每天 ${s.time || "00:00"}`;
  if (s.type === "weekly") {
    const wd = ["一", "二", "三", "四", "五", "六", "日"][(s.weekday ?? 0) % 7];
    return `每周${wd} ${s.time || "00:00"}`;
  }
  const at = s.run_at ? new Date(s.run_at) : null;
  return at && !isNaN(at.getTime())
    ? `单次 · ${at.toLocaleString("zh-CN", { hour12: false })}`
    : "单次";
}

export default function ScheduledTasksPage({ onClose }: Props) {
  const [tasks, setTasks] = useState<AutomationMeta[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const [addOpen, setAddOpen] = useState(false);
  const [name, setName] = useState("");
  const [prompt, setPrompt] = useState("");
  const [freq, setFreq] = useState<"once" | "daily">("daily");
  const [time, setTime] = useState("09:00");
  const [formErr, setFormErr] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      setTasks((await api.listAutomations()).automations);
    } catch (e) {
      setNotice((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const toggle = async (t: AutomationMeta) => {
    setBusy(true);
    setNotice(null);
    try {
      await api.toggleAutomation(t.id, t.status !== "active");
      await refresh();
    } catch (e) {
      setNotice((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const remove = async (t: AutomationMeta) => {
    if (!confirm(`确定删除任务「${t.name}」？`)) return;
    setBusy(true);
    setNotice(null);
    try {
      await api.deleteAutomation(t.id);
      await refresh();
      setNotice("任务已删除");
    } catch (e) {
      setNotice((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const submitAdd = async () => {
    setFormErr(null);
    if (!name.trim()) {
      setFormErr("请输入任务名称");
      return;
    }
    if (!prompt.trim()) {
      setFormErr("请输入任务提示词");
      return;
    }
    setBusy(true);
    try {
      const payload: AutomationPayload = {
        name: name.trim(),
        prompt: prompt.trim(),
        model_tier: "balanced",
        access: "full",
        schedule:
          freq === "daily"
            ? { type: "daily", time }
            : { type: "once", run_at: new Date().toISOString() },
        validity: { type: "permanent" },
        push_wechat: false,
        push_wecom: false,
      };
      await api.createAutomation(payload);
      setAddOpen(false);
      setName("");
      setPrompt("");
      await refresh();
      setNotice(`已添加任务「${name.trim()}」`);
    } catch (e) {
      setFormErr((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const q = query.trim().toLowerCase();
  const filtered = tasks.filter(
    (t) =>
      !q ||
      t.name.toLowerCase().includes(q) ||
      t.prompt.toLowerCase().includes(q) ||
      scheduleDesc(t).toLowerCase().includes(q)
  );

  return (
    <SettingsShell title="计划任务" subtitle="计划任务自动化与管理" onClose={onClose}>
      <div className="sl-toolbar">
        <div className="sl-search">
          <SearchIcon />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="搜索任务名称、说明或提示词..."
          />
        </div>
        <div className="sl-actions">
          <button type="button" className="sp-btn-primary" onClick={() => setAddOpen(true)}>
            <PlusIcon />
            添加任务
          </button>
        </div>
      </div>

      {notice && <div className="sp-ok-inline sl-block">{notice}</div>}

      <div className="sl-list">
        {loading ? (
          <div className="sl-empty">
            <div className="sl-empty-title">正在加载任务…</div>
          </div>
        ) : filtered.length === 0 ? (
          <div className="sl-empty">
            <span className="sl-empty-icon">
              <TimerIcon />
            </span>
            <div className="sl-empty-title">
              {tasks.length === 0 ? "没有计划任务" : "没有匹配的任务"}
            </div>
            <div className="sl-empty-desc">
              {tasks.length === 0
                ? "创建由 AI 代理自动执行的计划任务。"
                : "尝试其他搜索关键词。"}
            </div>
          </div>
        ) : (
          filtered.map((t) => (
            <div className="sl-row" key={t.id}>
              <span
                className={`status-dot ${
                  t.status === "active"
                    ? "dot-green"
                    : t.status === "paused"
                      ? "dot-amber"
                      : "dot-gray"
                }`}
              />
              <span className="sl-name">{t.name}</span>
              <span className="sl-meta">
                {scheduleDesc(t)}
                <span className="sl-meta-sep">·</span>
                <span className="sl-prompt" title={t.prompt}>
                  {t.prompt}
                </span>
              </span>
              <span className="sl-row-right">
                <button
                  type="button"
                  className="sl-del"
                  title="删除任务"
                  disabled={busy}
                  onClick={() => remove(t)}
                >
                  <CloseIcon />
                </button>
                <button
                  type="button"
                  className={`set-toggle ${t.status === "active" ? "on" : ""}`}
                  role="switch"
                  aria-checked={t.status === "active"}
                  aria-label={`开关 ${t.name}`}
                  disabled={busy}
                  onClick={() => toggle(t)}
                >
                  <span className="set-toggle-thumb" />
                </button>
              </span>
            </div>
          ))
        )}
      </div>

      {addOpen && (
        <>
          <div className="pop-backdrop" onClick={() => setAddOpen(false)} />
          <div className="slm-backdrop" onClick={() => setAddOpen(false)}>
            <div className="slm-panel" onClick={(e) => e.stopPropagation()}>
              <div className="slm-head">
                <div className="slm-title">添加计划任务</div>
                <button type="button" className="icon-btn" onClick={() => setAddOpen(false)} aria-label="关闭">
                  <CloseIcon />
                </button>
              </div>
              <div className="slm-body">
                <label className="sp-field">
                  <span className="sp-field-label">任务名称 *</span>
                  <input
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="例如 每日资讯总结"
                    autoFocus
                  />
                </label>
                <label className="sp-field">
                  <span className="sp-field-label">任务提示词 *</span>
                  <textarea
                    rows={3}
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    placeholder="描述代理执行该任务时要做什么"
                  />
                </label>
                <div className="sp-field-row">
                  <label className="sp-field" style={{ flex: 1 }}>
                    <span className="sp-field-label">执行频率</span>
                    <select value={freq} onChange={(e) => setFreq(e.target.value as "once" | "daily")}>
                      <option value="daily">每天</option>
                      <option value="once">单次（立即）</option>
                    </select>
                  </label>
                  {freq === "daily" && (
                    <label className="sp-field" style={{ width: 140 }}>
                      <span className="sp-field-label">执行时间</span>
                      <input
                        type="time"
                        value={time}
                        onChange={(e) => setTime(e.target.value)}
                      />
                    </label>
                  )}
                </div>
                {formErr && <div className="sp-err-inline">{formErr}</div>}
              </div>
              <div className="slm-foot">
                <button type="button" className="sp-btn-ghost" onClick={() => setAddOpen(false)}>
                  取消
                </button>
                <button type="button" className="sp-btn-primary" onClick={submitAdd} disabled={busy}>
                  添加
                </button>
              </div>
            </div>
          </div>
        </>
      )}
    </SettingsShell>
  );
}
