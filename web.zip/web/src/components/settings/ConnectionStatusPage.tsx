import { useCallback, useEffect, useState } from "react";
import { api } from "../../api";
import type { Settings } from "../../types";
import SettingsShell from "./SettingsShell";

interface Props {
  settings: Settings;
  onClose: () => void;
}

const ActivityIcon = () => (
  <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <path d="M22 12h-4l-3 9L9 3l-3 9H2" />
  </svg>
);

interface ApiState {
  ok: boolean;
  ms: number | null;
}

interface LlmState {
  ok: boolean;
  ms: number | null;
  model: string;
  error: string | null;
}

/** 角色模型展示行（严格对应参考图：规划 / 执行 / 评估） */
const ROLE_ROWS: { key: string; label: string }[] = [
  { key: "planner", label: "规划代理" },
  { key: "executor", label: "执行代理" },
  { key: "evaluator", label: "评估代理" },
];

export default function ConnectionStatusPage({ settings, onClose }: Props) {
  const [checking, setChecking] = useState(false);
  const [apiState, setApiState] = useState<ApiState | null>(null);
  const [llm, setLlm] = useState<LlmState | null>(null);

  const runChecks = useCallback(async () => {
    setChecking(true);
    // API 服务器：同源 /api/health，前端计时
    const t0 = performance.now();
    const apiProbe = fetch("/api/health", { cache: "no-store" })
      .then((r) => ({ ok: r.ok, ms: Math.round(performance.now() - t0) }))
      .catch(() => ({ ok: false, ms: null }));
    const llmProbe = api
      .probeGateway()
      .then((r) => ({
        ok: r.ok,
        ms: r.latency_ms ?? null,
        model: r.model || settings.llm.model,
        error: r.error || null,
      }))
      .catch((e) => ({
        ok: false,
        ms: null,
        model: settings.llm.model,
        error: (e as Error).message,
      }));
    const [a, l] = await Promise.all([apiProbe, llmProbe]);
    setApiState(a);
    setLlm(l);
    setChecking(false);
  }, [settings.llm.model]);

  useEffect(() => {
    runChecks();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const roleModel = (key: string) =>
    settings.roles?.[key]?.model || settings.llm.model || "（未配置）";

  return (
    <SettingsShell title="连接状态" subtitle="后端服务器连接状态" onClose={onClose}>
      {/* API 服务器 */}
      <div className="sp-card sp-pad">
        <div className="cn-row">
          <div className="sp-row-text">
            <div className="cn-title">API 服务器</div>
            <div className="cn-sub">（同源）</div>
          </div>
          <div className={`cn-status ${apiState?.ok ? "ok" : apiState ? "bad" : ""}`}>
            <span className="status-dot dot-green" />
            {checking && !apiState
              ? "检查中…"
              : apiState?.ok
                ? `运行中${apiState.ms != null ? ` · ${apiState.ms} ms` : ""}`
                : "未连接"}
          </div>
        </div>
      </div>

      {/* 执行代理 · LLM 连接 */}
      <div className="sp-card sp-pad">
        <div className="cn-row">
          <div className="sp-row-text">
            <div className="cn-title">执行代理 · LLM 连接</div>
            <div className="cn-sub cn-mono">
              {llm?.model || settings.llm.model || "（未配置模型）"}
              {llm?.ms != null ? `  ·  ${llm.ms} ms` : ""}
            </div>
            {llm && !llm.ok && llm.error && (
              <div className="cn-error">{llm.error}</div>
            )}
          </div>
          <div className={`cn-status ${llm?.ok ? "ok" : llm ? "bad" : ""}`}>
            <span className={`status-dot ${llm?.ok ? "dot-green" : llm ? "dot-red" : "dot-amber"}`} />
            {checking && !llm ? "检查中…" : llm?.ok ? "已连接" : llm ? "未连接" : "待检查"}
          </div>
        </div>
      </div>

      {/* 角色模型 */}
      <div className="sp-card sp-pad">
        <div className="cn-title">角色模型</div>
        <div className="cn-roles">
          {ROLE_ROWS.map((r) => (
            <div className="cn-role-row" key={r.key}>
              <div className="cn-role-label">{r.label}</div>
              <div className="cn-role-model cn-mono">{roleModel(r.key)}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="cn-actions">
        <button
          type="button"
          className="cn-check-btn"
          onClick={runChecks}
          disabled={checking}
        >
          <ActivityIcon />
          {checking ? "检查中…" : "检查连接"}
        </button>
      </div>
    </SettingsShell>
  );
}
