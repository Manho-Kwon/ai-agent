import { useCallback, useEffect, useState } from "react";
import { api } from "../../api";
import type { ConnProvider, ConnectionsState } from "../../types";

interface Props {
  onClose: () => void;
  /** 连接/模型增删后通知 LLM 设置页刷新共享模型下拉 */
  onChanged?: () => void;
  /** 内部提供商配置表单预填的网关地址 */
  gatewayBaseUrl: string;
}

/* ── 图标 ── */

const CloseIcon = () => (
  <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor"
    strokeWidth={1.8} strokeLinecap="round" aria-hidden>
    <line x1="6" y1="6" x2="18" y2="18" />
    <line x1="18" y1="6" x2="6" y2="18" />
  </svg>
);

const RefreshIcon = ({ spinning }: { spinning?: boolean }) => (
  <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor"
    strokeWidth={2} strokeLinecap="round" strokeLinejoin="round"
    className={spinning ? "mc-spin" : ""} aria-hidden>
    <polyline points="23 4 23 10 17 10" />
    <polyline points="1 20 1 14 7 14" />
    <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
  </svg>
);

const KeyIcon = () => (
  <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor"
    strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <path d="m15.5 7.5 2.3 2.3a1 1 0 0 0 1.4 0l2.1-2.1a1 1 0 0 0 0-1.4L19 4" />
    <path d="m21 2-9.6 9.6" />
    <circle cx="7.5" cy="15.5" r="5.5" />
  </svg>
);

const StackIcon = () => (
  <svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor"
    strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <rect x="3" y="3" width="18" height="7" rx="2" />
    <rect x="3" y="14" width="18" height="7" rx="2" />
    <line x1="7" y1="6.5" x2="7.01" y2="6.5" />
    <line x1="7" y1="17.5" x2="7.01" y2="17.5" />
  </svg>
);

const TrashIcon = () => (
  <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor"
    strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <polyline points="3 6 5 6 21 6" />
    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
    <line x1="10" y1="11" x2="10" y2="17" />
    <line x1="14" y1="11" x2="14" y2="17" />
  </svg>
);

const CheckIcon = () => (
  <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor"
    strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <polyline points="20 6 9 17 4 12" />
  </svg>
);

const EyeIcon = ({ off }: { off?: boolean }) => (
  <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor"
    strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    {off ? (
      <>
        <path d="M9.88 9.88a3 3 0 1 0 4.24 4.24" />
        <path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68" />
        <path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61" />
        <line x1="2" y1="2" x2="22" y2="22" />
      </>
    ) : (
      <>
        <path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z" />
        <circle cx="12" cy="12" r="3" />
      </>
    )}
  </svg>
);

const PlusIcon = () => (
  <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor" aria-hidden>
    <path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z" />
  </svg>
);

/* ── 状态展示 ── */

function StatusTag({ p }: { p: ConnProvider }) {
  if (p.status === "connected") {
    return (
      <span className="mc-status mc-status-ok">
        <CheckIcon />
        {p.status_text}
      </span>
    );
  }
  const cls =
    p.status === "error"
      ? "mc-status mc-status-err"
      : p.status === "unverified"
        ? "mc-status mc-status-warn"
        : "mc-status mc-status-off";
  return <span className={cls}>{p.status_text}</span>;
}

function fmtTime(iso: string | null): string {
  if (!iso) return "尚未检查";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "尚未检查";
  const pad = (n: number) => String(n).padStart(2, "0");
  return `最近检查：${d.getMonth() + 1}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

/* ── 主组件 ── */

export default function ModelConnectionsModal({ onClose, onChanged, gatewayBaseUrl }: Props) {
  const [state, setState] = useState<ConnectionsState | null>(null);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState<{ ok: boolean; text: string } | null>(null);

  // 内置提供商密钥表单
  const [formKey, setFormKey] = useState<string | null>(null);
  const [keyVal, setKeyVal] = useState("");
  const [baseUrlVal, setBaseUrlVal] = useState("");
  const [showKey, setShowKey] = useState(false);
  const [formErr, setFormErr] = useState<string | null>(null);
  const [savingKey, setSavingKey] = useState(false);

  // 自定义模型添加表单
  const [addOpen, setAddOpen] = useState(false);
  const [aLabel, setALabel] = useState("");
  const [aModel, setAModel] = useState("");
  const [aBase, setABase] = useState("");
  const [aKey, setAKey] = useState("");
  const [aShowKey, setAShowKey] = useState(false);
  const [addErr, setAddErr] = useState<string | null>(null);
  const [savingAdd, setSavingAdd] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      setState(await api.connections());
    } catch (e) {
      setNotice({ ok: false, text: (e as Error).message });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const refreshAll = async () => {
    setBusy(true);
    setNotice(null);
    try {
      setState(await api.connectionsRefresh());
      setNotice({ ok: true, text: "已重新验证全部连接" });
      onChanged?.();
    } catch (e) {
      setNotice({ ok: false, text: (e as Error).message });
    } finally {
      setBusy(false);
    }
  };

  const openKeyForm = (p: ConnProvider) => {
    setFormKey(p.key);
    setKeyVal("");
    setBaseUrlVal(gatewayBaseUrl || "");
    setShowKey(false);
    setFormErr(null);
  };

  const submitKey = async (p: ConnProvider) => {
    setFormErr(null);
    if (!keyVal.trim()) {
      setFormErr("请输入 API 密钥");
      return;
    }
    if (baseUrlVal.trim() && !/^https?:\/\//.test(baseUrlVal.trim())) {
      setFormErr("网关地址必须以 http:// 或 https:// 开头");
      return;
    }
    setSavingKey(true);
    try {
      const next = await api.connectionSaveKey(
        p.key,
        keyVal.trim(),
        baseUrlVal.trim() || undefined
      );
      setState(next);
      setFormKey(null);
      setNotice({ ok: true, text: `「${p.title}」连接成功` });
      onChanged?.();
    } catch (e) {
      setFormErr((e as Error).message);
    } finally {
      setSavingKey(false);
    }
  };

  const submitAdd = async () => {
    setAddErr(null);
    if (!aLabel.trim()) return setAddErr("请填写显示名称");
    if (!aModel.trim()) return setAddErr("请填写模型 ID");
    if (!aBase.trim()) return setAddErr("请填写 API Base URL");
    if (!/^https?:\/\//.test(aBase.trim())) return setAddErr("API Base URL 必须以 http:// 或 https:// 开头");
    setSavingAdd(true);
    try {
      const next = await api.customModelAdd({
        label: aLabel.trim(),
        model: aModel.trim(),
        base_url: aBase.trim(),
        api_key: aKey.trim(),
      });
      setState(next);
      setAddOpen(false);
      setALabel("");
      setAModel("");
      setABase("");
      setAKey("");
      setNotice({ ok: true, text: `已添加模型「${aLabel.trim()}」` });
      onChanged?.();
    } catch (e) {
      setAddErr((e as Error).message);
    } finally {
      setSavingAdd(false);
    }
  };

  const removeModel = async (id: string, label: string) => {
    if (!window.confirm(`确定删除模型「${label}」吗？使用该模型的角色将回退到默认网关。`)) return;
    setDeletingId(id);
    try {
      await api.customModelDelete(id);
      await refresh();
      setNotice({ ok: true, text: `已删除模型「${label}」` });
      onChanged?.();
    } catch (e) {
      setNotice({ ok: false, text: (e as Error).message });
    } finally {
      setDeletingId(null);
    }
  };

  const custom = state?.providers.find((p) => p.kind === "custom");
  const builtins = state?.providers.filter((p) => p.kind === "builtin") ?? [];

  return (
    <div className="mc-mask" onClick={() => !busy && onClose()}>
      <div className="mc-panel" onClick={(e) => e.stopPropagation()} role="dialog" aria-label="管理模型连接">
        {/* 头部 */}
        <div className="mc-head">
          <div className="mc-head-text">
            <div className="mc-title">管理模型连接</div>
            <div className="mc-subtitle">只能将已连接提供商的模型分配给角色。</div>
          </div>
          <div className="mc-head-actions">
            <button type="button" className="mc-btn mc-btn-refresh" onClick={refreshAll} disabled={busy}>
              <RefreshIcon spinning={busy} />
              {busy ? "验证中…" : "全部刷新"}
            </button>
            <button type="button" className="mc-close" onClick={onClose} aria-label="关闭" disabled={busy}>
              <CloseIcon />
            </button>
          </div>
        </div>

        {/* 提示条 */}
        {notice && (
          <div className={notice.ok ? "mc-notice mc-notice-ok" : "mc-notice mc-notice-err"}>
            {notice.text}
          </div>
        )}

        {/* 提供商列表 */}
        <div className="mc-body">
          {loading ? (
            <div className="mc-loading">正在加载连接…</div>
          ) : (
            <>
              {builtins.map((p) => (
                <div className="mc-prov" key={p.key}>
                  <div className="mc-prov-main">
                    <span className="mc-prov-icon">
                      <KeyIcon />
                    </span>
                    <div className="mc-prov-info">
                      <div className="mc-prov-title">{p.title}</div>
                      <div className="mc-prov-env cn-mono">{p.env}</div>
                    </div>
                    <div className="mc-prov-right">
                      <StatusTag p={p} />
                      <button
                        type="button"
                        className="mc-btn"
                        onClick={() => (formKey === p.key ? setFormKey(null) : openKeyForm(p))}
                        disabled={busy}
                      >
                        配置
                      </button>
                    </div>
                  </div>

                  {p.note && formKey !== p.key && <div className="mc-note">{p.note}</div>}
                  {p.status === "error" && p.error && formKey !== p.key && (
                    <div className="mc-note mc-note-line-err">{p.error}</div>
                  )}

                  {/* 密钥录入表单 */}
                  {formKey === p.key && (
                    <div className="mc-form">
                      <label className="mc-field">
                        <span className="mc-field-label">API 密钥 *</span>
                        <div className="mc-pw-row">
                          <input
                            type={showKey ? "text" : "password"}
                            value={keyVal}
                            autoFocus
                            onChange={(e) => setKeyVal(e.target.value)}
                            placeholder={`粘贴 ${p.env} 密钥`}
                            autoComplete="off"
                          />
                          <button
                            type="button"
                            className="mc-eye"
                            onClick={() => setShowKey(!showKey)}
                            aria-label={showKey ? "隐藏密钥" : "显示密钥"}
                            title={showKey ? "隐藏密钥" : "显示密钥"}
                          >
                            <EyeIcon off={showKey} />
                          </button>
                        </div>
                      </label>
                      <label className="mc-field">
                        <span className="mc-field-label">网关地址（OpenAI 兼容）</span>
                        <input
                          value={baseUrlVal}
                          onChange={(e) => setBaseUrlVal(e.target.value)}
                          placeholder="http://192.168.1.128:9800/v1"
                        />
                      </label>
                      {formErr && <div className="mc-form-err">{formErr}</div>}
                      <div className="mc-form-actions">
                        <button type="button" className="mc-btn" onClick={() => setFormKey(null)} disabled={savingKey}>
                          取消
                        </button>
                        <button
                          type="button"
                          className="mc-btn mc-btn-primary"
                          onClick={() => submitKey(p)}
                          disabled={savingKey}
                        >
                          {savingKey ? "验证中…" : "保存并验证"}
                        </button>
                      </div>
                    </div>
                  )}
                </div>
              ))}

              {/* 自定义 / 自托管 */}
              {custom && (
                <div className="mc-prov mc-prov-custom">
                  <div className="mc-prov-main">
                    <span className="mc-prov-icon">
                      <StackIcon />
                    </span>
                    <div className="mc-prov-info">
                      <div className="mc-prov-title">{custom.title}</div>
                      <div className="mc-prov-sub">{custom.subtitle}</div>
                    </div>
                    <div className="mc-prov-right">
                      <StatusTag p={custom} />
                      <button
                        type="button"
                        className="mc-btn"
                        onClick={() => {
                          setAddOpen(!addOpen);
                          setAddErr(null);
                        }}
                        disabled={busy}
                      >
                        <PlusIcon />
                        添加
                      </button>
                    </div>
                  </div>

                  {/* 添加自定义模型表单 */}
                  {addOpen && (
                    <div className="mc-form mc-add-form">
                      <div className="mc-form-title">添加自定义模型</div>
                      <div className="mc-grid-2">
                        <label className="mc-field">
                          <span className="mc-field-label">显示名称 *</span>
                          <input
                            value={aLabel}
                            autoFocus
                            onChange={(e) => setALabel(e.target.value)}
                            placeholder="例如 Qwen"
                          />
                        </label>
                        <label className="mc-field">
                          <span className="mc-field-label">模型 ID *</span>
                          <input
                            value={aModel}
                            onChange={(e) => setAModel(e.target.value)}
                            placeholder="例如 openai/qwen3.8-flash"
                          />
                        </label>
                      </div>
                      <label className="mc-field">
                        <span className="mc-field-label">API Base URL *</span>
                        <input
                          value={aBase}
                          onChange={(e) => setABase(e.target.value)}
                          placeholder="https://api.deepseek.com（或任意 OpenAI 兼容端点）"
                        />
                      </label>
                      <label className="mc-field">
                        <span className="mc-field-label">API 密钥（可选，公开端点可留空）</span>
                        <div className="mc-pw-row">
                          <input
                            type={aShowKey ? "text" : "password"}
                            value={aKey}
                            onChange={(e) => setAKey(e.target.value)}
                            placeholder="粘贴 API 密钥，保存后不回显"
                            autoComplete="off"
                          />
                          <button
                            type="button"
                            className="mc-eye"
                            onClick={() => setAShowKey(!aShowKey)}
                            aria-label={aShowKey ? "隐藏密钥" : "显示密钥"}
                            title={aShowKey ? "隐藏密钥" : "显示密钥"}
                          >
                            <EyeIcon off={aShowKey} />
                          </button>
                        </div>
                      </label>
                      {addErr && <div className="mc-form-err">{addErr}</div>}
                      <div className="mc-form-actions">
                        <button type="button" className="mc-btn" onClick={() => setAddOpen(false)} disabled={savingAdd}>
                          取消
                        </button>
                        <button type="button" className="mc-btn mc-btn-primary" onClick={submitAdd} disabled={savingAdd}>
                          {savingAdd ? "验证中…" : "验证并添加"}
                        </button>
                      </div>
                    </div>
                  )}

                  {/* 已添加的模型卡片 */}
                  {custom.models && custom.models.length > 0 && (
                    <div className="mc-models">
                      {custom.models.map((m) => (
                        <div className="mc-model" key={m.id}>
                          <div className="mc-model-main">
                            <div className="mc-model-head">
                              <span className="mc-model-label">{m.label}</span>
                              <span
                                className={`mc-model-dot ${
                                  m.status === "connected"
                                    ? "dot-green"
                                    : m.status === "error"
                                      ? "dot-red"
                                      : "dot-amber"
                                }`}
                              />
                            </div>
                            <div className="mc-model-id cn-mono">{m.model}</div>
                            <div className="mc-model-url cn-mono">{m.base_url}</div>
                            {m.status === "error" && m.error && (
                              <div className="mc-note mc-note-line-err">{m.error}</div>
                            )}
                            {m.in_use.length > 0 && (
                              <div className="mc-inuse">
                                使用中：{m.in_use.join("，")}
                              </div>
                            )}
                          </div>
                          <button
                            type="button"
                            className="mc-del"
                            title="删除模型"
                            aria-label={`删除 ${m.label}`}
                            disabled={deletingId === m.id}
                            onClick={() => removeModel(m.id, m.label)}
                          >
                            <TrashIcon />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </>
          )}
        </div>

        <div className="mc-foot">
          <span className="mc-foot-time">{fmtTime(state?.last_checked ?? null)}</span>
        </div>
      </div>
    </div>
  );
}
