import { useRef, useState } from "react";
import { api } from "../../api";
import type { UIConfig } from "../../types";
import SettingsShell from "./SettingsShell";

interface Props {
  ui: UIConfig;
  onClose: () => void;
  /** 保存成功后回调（App 重新拉取设置，侧边栏 / 聊天即时生效） */
  onSaved: () => Promise<void> | void;
}

const UploadIcon = () => (
  <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" strokeWidth={1.6} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <path d="M12 16V5" />
    <path d="m7.5 9 4.5-4.5L16.5 9" />
    <path d="M4.5 15v3.5a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2V15" />
  </svg>
);

const UserCircleIcon = () => (
  <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <circle cx="12" cy="12" r="9.5" />
    <circle cx="12" cy="10" r="3" />
    <path d="M6.5 19.5a6.5 6.5 0 0 1 11 0" />
  </svg>
);

const BotIcon = () => (
  <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <path d="M10.5 7V5h2" />
    <rect x="5" y="7" width="14" height="11" rx="2.5" />
    <path d="M9.75 11v2.5" />
    <path d="M14.25 11v2.5" />
    <path d="M5 12H3.5" />
    <path d="M19 12h1.5" />
  </svg>
);

const TextIcon = () => (
  <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <path d="M5 6V4h14v2" />
    <path d="M12 4v16" />
    <path d="M9 20h6" />
  </svg>
);

const SaveIcon = () => (
  <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" />
    <path d="M17 21v-8H7v8" />
    <path d="M7 3v5h8" />
  </svg>
);

/** 头像上传框：虚线框 + 预览 + 「点击更改」 */
function AvatarBox({
  value,
  onPick,
}: {
  value: string;
  onPick: () => void;
}) {
  return (
    <div className="pb-avatar-wrap">
      <button type="button" className="pb-avatar-box" onClick={onPick} title="更换头像">
        {value ? (
          <img src={value} alt="头像预览" />
        ) : (
          <span className="pb-avatar-icon">
            <UploadIcon />
          </span>
        )}
      </button>
      <div className="pb-avatar-hint">点击更改</div>
    </div>
  );
}

export default function ProfileBrandPage({ ui, onClose, onSaved }: Props) {
  const [userName, setUserName] = useState(ui.user_name || "");
  const [userAvatar, setUserAvatar] = useState(ui.user_avatar || "");
  const [botName, setBotName] = useState(ui.bot_name || "");
  const [botAvatar, setBotAvatar] = useState(ui.bot_avatar || "");
  const [title, setTitle] = useState(ui.title || "");
  const [subtitle, setSubtitle] = useState(ui.subtitle || "");
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(false);

  const userFileRef = useRef<HTMLInputElement>(null);
  const botFileRef = useRef<HTMLInputElement>(null);

  const readImage = (file: File, apply: (dataUrl: string) => void) => {
    if (file.size > 1024 * 1024) {
      setError("头像图片过大（超过 1MB），请换一张较小的图片");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      apply(String(reader.result || ""));
      setError(null);
    };
    reader.readAsDataURL(file);
  };

  const save = async () => {
    if (!userName.trim()) {
      setError("显示名称不能为空");
      return;
    }
    if (!botName.trim()) {
      setError("机器人名称不能为空");
      return;
    }
    setSaving(true);
    setError(null);
    try {
      await api.saveSettings({
        ui: {
          user_name: userName.trim(),
          user_avatar: userAvatar,
          bot_name: botName.trim(),
          bot_avatar: botAvatar,
          title: title.trim() || "A R C H E",
          subtitle: subtitle.trim(),
        },
      });
      await onSaved();
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setSaving(false);
    }
  };

  return (
    <SettingsShell
      title="资料与品牌"
      subtitle="用户资料和平台品牌设置"
      onClose={onClose}
      footer={
        <div className="sp-footer">
          <button type="button" className="sp-btn-primary" onClick={save} disabled={saving}>
            <SaveIcon />
            {saving ? "保存中…" : "保存资料"}
          </button>
          {saved && <span className="sp-ok-inline">资料已保存</span>}
          {error && <span className="sp-err-inline">{error}</span>}
        </div>
      }
    >
      {/* 用户资料 */}
      <div className="pb-section-label">
        <UserCircleIcon />
        用户资料
      </div>
      <div className="pb-row">
        <AvatarBox value={userAvatar} onPick={() => userFileRef.current?.click()} />
        <input
          ref={userFileRef}
          type="file"
          accept="image/*"
          style={{ display: "none" }}
          onChange={(e) => {
            const f = e.target.files?.[0];
            e.target.value = "";
            if (f) readImage(f, setUserAvatar);
          }}
        />
        <div className="pb-row-main">
          <label className="sp-field">
            <span className="sp-field-label">显示名称</span>
            <input
              value={userName}
              onChange={(e) => setUserName(e.target.value)}
              placeholder="K哥"
            />
            <span className="sp-field-hint">显示在聊天消息中。</span>
          </label>
        </div>
      </div>

      <hr className="sp-divider" />

      {/* AI 机器人资料 */}
      <div className="pb-section-label">
        <BotIcon />
        AI 机器人资料
      </div>
      <div className="pb-row">
        <AvatarBox value={botAvatar} onPick={() => botFileRef.current?.click()} />
        <input
          ref={botFileRef}
          type="file"
          accept="image/*"
          style={{ display: "none" }}
          onChange={(e) => {
            const f = e.target.files?.[0];
            e.target.value = "";
            if (f) readImage(f, setBotAvatar);
          }}
        />
        <div className="pb-row-main">
          <label className="sp-field">
            <span className="sp-field-label">机器人名称</span>
            <input
              value={botName}
              onChange={(e) => setBotName(e.target.value)}
              placeholder="Agent"
            />
            <span className="sp-field-hint">显示在聊天中的 AI 回复下方。</span>
          </label>
        </div>
      </div>

      <hr className="sp-divider" />

      {/* 平台品牌 */}
      <div className="pb-section-label">
        <TextIcon />
        平台品牌
      </div>
      <label className="sp-field sp-field-wide">
        <span className="sp-field-label">平台名称</span>
        <input
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          placeholder="A R C H E"
        />
        <span className="sp-field-hint">显示在侧边栏顶部</span>
      </label>
      <label className="sp-field sp-field-wide">
        <span className="sp-field-label">平台副标题</span>
        <input
          value={subtitle}
          onChange={(e) => setSubtitle(e.target.value)}
          placeholder="Arche Agent"
        />
        <span className="sp-field-hint">显示在侧边栏顶部的平台名称下方</span>
      </label>
    </SettingsShell>
  );
}
