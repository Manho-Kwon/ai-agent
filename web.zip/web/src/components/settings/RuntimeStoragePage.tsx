import { useCallback, useEffect, useMemo, useState } from "react";
import { api } from "../../api";
import { WORKFLOW_MODES } from "../../appearance";
import type { SettingsPut, StorageStats } from "../../types";
import SettingsShell from "./SettingsShell";

interface Props {
  workflowMode: string;
  allowExport: boolean;
  onClose: () => void;
  /** 配置变更后由 App 刷新设置 */
  onConfigChange: () => Promise<void> | void;
}

const GaugeIcon = () => (
  <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <path d="M12 15l3.5-3.5" />
    <path d="M20.2 18a9 9 0 1 0-16.4 0" />
  </svg>
);

const FolderOutIcon = () => (
  <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <path d="M4 20h16a1 1 0 0 0 1-1V8a1 1 0 0 0-1-1h-8L10 4H4a1 1 0 0 0-1 1v14a1 1 0 0 0 1 1z" />
    <path d="M12 16v-5" />
    <path d="m9.5 13.5 2.5-2.5 2.5 2.5" />
  </svg>
);

const ArchiveIcon = () => (
  <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <rect x="2.5" y="4" width="19" height="5" rx="1" />
    <path d="M4.5 9v10a1 1 0 0 0 1 1h13a1 1 0 0 0 1-1V9" />
    <path d="M10 13h4" />
  </svg>
);

const RefreshIcon = () => (
  <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <polyline points="23 4 23 10 17 10" />
    <polyline points="1 20 1 14 7 14" />
    <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
  </svg>
);

const CheckIcon = () => (
  <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor" strokeWidth={2.4} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <path d="M5 12.5 10 17.5 19 7" />
  </svg>
);

function fmtBytes(n: number): string {
  if (!n) return "0 B";
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(n < 10 * 1024 ? 1 : 0)} KB`;
  if (n < 1024 * 1024 * 1024) return `${(n / 1024 / 1024).toFixed(1)} MB`;
  return `${(n / 1024 / 1024 / 1024).toFixed(2)} GB`;
}

function fmtCount(n: number): string {
  return n.toLocaleString("en-US");
}

export default function RuntimeStoragePage({
  workflowMode,
  allowExport,
  onClose,
  onConfigChange,
}: Props) {
  const [stats, setStats] = useState<StorageStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [cleaning, setCleaning] = useState(false);
  const [notice, setNotice] = useState<string | null>(null);
  const [modeOpen, setModeOpen] = useState(false);
  const [modeSaving, setModeSaving] = useState(false);

  const refresh = useCallback(async () => {
    setLoading(true);
    setLoadError(null);
    try {
      setStats(await api.storageStats());
    } catch (e) {
      setLoadError((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const modeLabel =
    WORKFLOW_MODES.find((m) => m.key === workflowMode)?.label || "自适应";

  const setMode = async (key: string) => {
    setModeOpen(false);
    if (key === workflowMode) return;
    setModeSaving(true);
    try {
      await api.saveSettings({ workflow_mode: key } as SettingsPut);
      await onConfigChange();
    } catch (e) {
      setNotice((e as Error).message);
    } finally {
      setModeSaving(false);
    }
  };

  const toggleExport = async () => {
    try {
      await api.saveSettings({ allow_export: !allowExport });
      await onConfigChange();
    } catch (e) {
      setNotice((e as Error).message);
    }
  };

  const toggleSelect = (key: string, cleanable: boolean) => {
    if (!cleanable) return;
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key);
      else next.add(key);
      return next;
    });
  };

  const cleanSelected = async () => {
    const keys = Array.from(selected);
    if (keys.length === 0) return;
    const labels = keys
      .map((k) => stats?.categories.find((c) => c.key === k)?.label || k)
      .join("、");
    if (!confirm(`确定清理「${labels}」？此操作不可恢复。`)) return;
    setCleaning(true);
    setNotice(null);
    try {
      const r = await api.storageClean(keys);
      setStats(r);
      setSelected(new Set());
      setNotice(`已清理完成，共移除 ${fmtCount(r.removed)} 项`);
    } catch (e) {
      setNotice((e as Error).message);
    } finally {
      setCleaning(false);
    }
  };

  const allCleanableSelected = useMemo(() => {
    if (!stats) return false;
    const cleanable = stats.categories.filter((c) => c.cleanable);
    return cleanable.length > 0 && cleanable.every((c) => selected.has(c.key));
  }, [stats, selected]);

  const toggleAll = () => {
    if (!stats) return;
    const cleanable = stats.categories.filter((c) => c.cleanable);
    if (allCleanableSelected) setSelected(new Set());
    else setSelected(new Set(cleanable.map((c) => c.key)));
  };

  return (
    <SettingsShell
      title="运行与存储"
      subtitle="自动执行策略、写入工作区之外、磁盘用量"
      onClose={onClose}
    >
      {/* 自动运行策略 */}
      <div className="sp-card sp-pad">
        <div className="rs-strategy">
          <span className="rs-strategy-icon">
            <GaugeIcon />
          </span>
          <div className="sp-row-text">
            <div className="sp-row-title">自动运行策略</div>
            <div className="sp-row-desc">
              系统会针对每个请求自动调整规划深度、评估、超时与工作预算。
            </div>
          </div>
          <div className="rs-mode-wrap">
            <button
              type="button"
              className="rs-mode-badge"
              onClick={() => setModeOpen((v) => !v)}
              disabled={modeSaving}
              aria-haspopup="listbox"
              aria-expanded={modeOpen}
            >
              <span className="rs-mode-check">
                <CheckIcon />
              </span>
              {modeLabel}
            </button>
            {modeOpen && (
              <>
                <div className="pop-backdrop" onClick={() => setModeOpen(false)} />
                <div className="rs-mode-menu" role="listbox">
                  {WORKFLOW_MODES.map((m) => (
                    <button
                      key={m.key}
                      type="button"
                      role="option"
                      aria-selected={m.key === workflowMode}
                      className={`rs-mode-item ${m.key === workflowMode ? "active" : ""}`}
                      onClick={() => setMode(m.key)}
                    >
                      {m.label}
                      {m.key === workflowMode && (
                        <span className="rs-mode-item-check">
                          <CheckIcon />
                        </span>
                      )}
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>
        </div>
      </div>

      {/* 写入工作区之外 */}
      <div className="sp-card sp-pad">
        <div className="rs-card-head">
          <span className="rs-strategy-icon">
            <FolderOutIcon />
          </span>
          <div className="sp-row-text">
            <div className="sp-row-title">写入工作区之外</div>
            <div className="sp-row-desc">
              决定 Shell 命令是否可以写入工作区之外。写入仍需逐条批准，凭据和智能体文件夹始终被拒绝。
            </div>
          </div>
        </div>
        <div className="rs-export-row">
          <div className="sp-row-text">
            <div className="rs-export-title">允许经批准的导出</div>
            <div className="sp-row-desc">
              开启后，请求中写明的文件夹即可使用，每条命令仍需批准。关闭后，工作区外的所有路径都会被阻止。
              主目录本身、文件系统根目录以及智能体和凭据文件夹始终被拒绝。
            </div>
          </div>
          <button
            type="button"
            className={`set-toggle ${allowExport ? "on" : ""}`}
            role="switch"
            aria-checked={allowExport}
            aria-label="允许经批准的导出"
            onClick={toggleExport}
          >
            <span className="set-toggle-thumb" />
          </button>
        </div>
      </div>

      {/* 代理存储 */}
      <div className="sp-card sp-pad">
        <div className="rs-store-head">
          <div className="rs-card-head">
            <span className="rs-strategy-icon">
              <ArchiveIcon />
            </span>
            <div className="sp-row-text">
              <div className="sp-row-title">代理存储</div>
              <div className="sp-row-desc">
                代理自身数据占用的空间。运行过程中创建的工作文件保存在这里，而不是您的文件夹。
              </div>
            </div>
          </div>
          <button
            type="button"
            className="rs-refresh-btn"
            onClick={refresh}
            disabled={loading}
            title="重新扫描磁盘用量"
          >
            <RefreshIcon />
            刷新
          </button>
        </div>

        {loading && !stats && <div className="rs-loading">正在扫描磁盘用量…</div>}
        {loadError && <div className="sp-err-inline">{loadError}</div>}

        {stats && (
          <>
            <div className="rs-list">
              <label className="rs-row rs-row-head">
                <input
                  type="checkbox"
                  checked={allCleanableSelected}
                  onChange={toggleAll}
                  aria-label="全选可清理项"
                />
                <span className="rs-row-name">全选</span>
              </label>
              {stats.categories.map((c) => (
                <label
                  key={c.key}
                  className={`rs-row ${c.cleanable ? "" : "disabled"} ${
                    selected.has(c.key) ? "checked" : ""
                  }`}
                >
                  <input
                    type="checkbox"
                    checked={selected.has(c.key)}
                    disabled={!c.cleanable}
                    onChange={() => toggleSelect(c.key, c.cleanable)}
                    aria-label={c.label}
                  />
                  <span className="rs-row-name">{c.label}</span>
                  <span className="rs-row-files">{fmtCount(c.files)} 个文件</span>
                  <span className="rs-row-size">{fmtBytes(c.bytes)}</span>
                </label>
              ))}
            </div>

            <div className="rs-descs">
              {stats.categories
                .filter((c) => c.desc)
                .map((c) => (
                  <p key={c.key}>{c.desc}</p>
                ))}
            </div>

            <div className="rs-retain-block">
              <div className="rs-retain-label">保留</div>
              {stats.retained.map((c) => (
                <div className="rs-row rs-row-static" key={c.key}>
                  <span className="rs-row-name">{c.label}</span>
                  <span className="rs-row-files">{fmtCount(c.files)} 个文件</span>
                  <span className="rs-row-size">{fmtBytes(c.bytes)}</span>
                </div>
              ))}
            </div>

            <div className="rs-clean-bar">
              <button
                type="button"
                className="sp-btn-danger"
                onClick={cleanSelected}
                disabled={selected.size === 0 || cleaning}
              >
                {cleaning ? "清理中…" : `清理所选项${selected.size ? `（${selected.size}）` : ""}`}
              </button>
              {notice && <span className="sp-ok-inline">{notice}</span>}
            </div>
          </>
        )}
      </div>
    </SettingsShell>
  );
}
