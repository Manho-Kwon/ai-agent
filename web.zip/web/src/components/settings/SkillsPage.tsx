import { useCallback, useEffect, useState } from "react";
import { api } from "../../api";
import type { SkillInfo } from "../../types";
import SettingsShell from "./SettingsShell";

interface Props {
  onClose: () => void;
}

const RefreshIcon = () => (
  <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <polyline points="23 4 23 10 17 10" />
    <polyline points="1 20 1 14 7 14" />
    <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
  </svg>
);

const PlusIcon = () => (
  <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor" aria-hidden>
    <path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z" />
  </svg>
);

const SearchIcon = () => (
  <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" aria-hidden>
    <circle cx="11" cy="11" r="7" />
    <path d="m20 20-3.5-3.5" />
  </svg>
);

const BookIcon = () => (
  <svg viewBox="0 0 24 24" width="26" height="26" fill="none" stroke="currentColor" strokeWidth={1.6} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" />
    <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" />
  </svg>
);

const CloseIcon = () => (
  <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" aria-hidden>
    <line x1="6" y1="6" x2="18" y2="18" />
    <line x1="18" y1="6" x2="6" y2="18" />
  </svg>
);

export default function SkillsPage({ onClose }: Props) {
  const [skills, setSkills] = useState<SkillInfo[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [notice, setNotice] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const [addOpen, setAddOpen] = useState(false);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [body, setBody] = useState("");
  const [formErr, setFormErr] = useState<string | null>(null);

  const refresh = useCallback(async () => {
    try {
      setSkills((await api.listSkills()).skills);
    } catch (e) {
      setNotice((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refresh();
  }, [refresh]);

  const toggle = async (s: SkillInfo) => {
    setBusy(true);
    setNotice(null);
    try {
      await api.setSkillEnabled(s.name, !s.enabled);
      await refresh();
    } catch (e) {
      setNotice((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const reload = async () => {
    setBusy(true);
    setNotice(null);
    try {
      const r = await api.reloadSkills();
      await refresh();
      setNotice(`已重新加载 ${r.count} 个技能`);
    } catch (e) {
      setNotice((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const submitAdd = async () => {
    setFormErr(null);
    if (!name.trim()) {
      setFormErr("请输入技能名称");
      return;
    }
    if (!description.trim()) {
      setFormErr("请输入技能说明");
      return;
    }
    setBusy(true);
    try {
      await api.createSkill({
        name: name.trim(),
        description: description.trim(),
        body: body.trim(),
      });
      setAddOpen(false);
      setName("");
      setDescription("");
      setBody("");
      await refresh();
      setNotice(`已添加技能「${name.trim()}」`);
    } catch (e) {
      setFormErr((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const q = query.trim().toLowerCase();
  const filtered = skills.filter(
    (s) =>
      !q ||
      s.name.toLowerCase().includes(q) ||
      s.description.toLowerCase().includes(q)
  );

  return (
    <SettingsShell title="代理技能" subtitle="代理技能注册与管理" onClose={onClose}>
      <div className="sl-toolbar">
        <div className="sl-search">
          <SearchIcon />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="搜索技能名称或说明..."
          />
        </div>
        <div className="sl-actions">
          <button type="button" className="sp-btn-ghost" onClick={reload} disabled={busy}>
            <RefreshIcon />
            重新加载技能
          </button>
          <button type="button" className="sp-btn-primary" onClick={() => setAddOpen(true)}>
            <PlusIcon />
            添加技能
          </button>
        </div>
      </div>

      {notice && <div className="sp-ok-inline sl-block">{notice}</div>}

      <div className="sl-list">
        {loading ? (
          <div className="sl-empty">
            <div className="sl-empty-title">正在加载技能…</div>
          </div>
        ) : filtered.length === 0 ? (
          <div className="sl-empty">
            <span className="sl-empty-icon">
              <BookIcon />
            </span>
            <div className="sl-empty-title">
              {skills.length === 0 ? "没有代理技能" : "没有匹配的技能"}
            </div>
            <div className="sl-empty-desc">
              {skills.length === 0
                ? "技能是可复用的工作流指令卡，添加后自动注入执行者。"
                : "尝试其他搜索关键词。"}
            </div>
          </div>
        ) : (
          filtered.map((s) => (
            <div className="sl-row" key={s.name} title={s.description}>
              <span className={`status-dot ${s.enabled ? "dot-green" : "dot-gray"}`} />
              <span className="sl-name">{s.name}</span>
              <span className="sl-meta">
                脚本： {s.scripts}
                <span className="sl-meta-sep">·</span>参考资料： {s.references}
              </span>
              <span className="sl-row-right">
                <button
                  type="button"
                  className={`set-toggle ${s.enabled ? "on" : ""}`}
                  role="switch"
                  aria-checked={s.enabled}
                  aria-label={`开关 ${s.name}`}
                  disabled={busy}
                  onClick={() => toggle(s)}
                >
                  <span className="set-toggle-thumb" />
                </button>
              </span>
            </div>
          ))
        )}
      </div>

      {addOpen && (
        <>
          <div className="pop-backdrop" onClick={() => setAddOpen(false)} />
          <div className="slm-backdrop" onClick={() => setAddOpen(false)}>
            <div className="slm-panel" onClick={(e) => e.stopPropagation()}>
              <div className="slm-head">
                <div className="slm-title">添加技能</div>
                <button type="button" className="icon-btn" onClick={() => setAddOpen(false)} aria-label="关闭">
                  <CloseIcon />
                </button>
              </div>
              <div className="slm-body">
                <label className="sp-field">
                  <span className="sp-field-label">技能名称 *</span>
                  <input
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="例如 my-skill（字母、数字、连字符）"
                    autoFocus
                  />
                </label>
                <label className="sp-field">
                  <span className="sp-field-label">一句话说明 *</span>
                  <input
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="描述技能的用途，会注入技能索引"
                  />
                </label>
                <label className="sp-field">
                  <span className="sp-field-label">指令正文（可选）</span>
                  <textarea
                    rows={5}
                    value={body}
                    onChange={(e) => setBody(e.target.value)}
                    placeholder="加载该技能时注入执行者的完整指令"
                  />
                </label>
                {formErr && <div className="sp-err-inline">{formErr}</div>}
              </div>
              <div className="slm-foot">
                <button type="button" className="sp-btn-ghost" onClick={() => setAddOpen(false)}>
                  取消
                </button>
                <button type="button" className="sp-btn-primary" onClick={submitAdd} disabled={busy}>
                  添加
                </button>
              </div>
            </div>
          </div>
        </>
      )}
    </SettingsShell>
  );
}
