import { useRef } from "react";
import { ACCENTS, TONES } from "../../appearance";
import type { Appearance } from "../../types";
import SettingsShell from "./SettingsShell";

interface Props {
  appearance: Appearance;
  onChange: (patch: Partial<Appearance>) => void;
  onClose: () => void;
}

const MoonIcon = () => (
  <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z" />
  </svg>
);

const SunIcon = () => (
  <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <circle cx="12" cy="12" r="4" />
    <line x1="12" y1="2" x2="12" y2="4.5" />
    <line x1="12" y1="19.5" x2="12" y2="22" />
    <line x1="2" y1="12" x2="4.5" y2="12" />
    <line x1="19.5" y1="12" x2="22" y2="12" />
    <line x1="4.9" y1="4.9" x2="6.7" y2="6.7" />
    <line x1="17.3" y1="17.3" x2="19.1" y2="19.1" />
    <line x1="4.9" y1="19.1" x2="6.7" y2="17.3" />
    <line x1="17.3" y1="6.7" x2="19.1" y2="4.9" />
  </svg>
);

const XIcon = () => (
  <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth={1.7} strokeLinecap="round" aria-hidden>
    <line x1="6" y1="6" x2="18" y2="18" />
    <line x1="18" y1="6" x2="6" y2="18" />
  </svg>
);

const ImageIcon = () => (
  <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <rect x="3" y="3" width="18" height="18" rx="2.5" />
    <circle cx="8.8" cy="8.8" r="1.8" />
    <path d="m21 15-4.4-4.4L6 21" />
  </svg>
);

const CheckIcon = () => (
  <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <path d="M5 12.5 10 17.5 19 7" />
  </svg>
);

/** 背景色调卡片里的色块预览 */
const TONE_SWATCH: Record<Appearance["tone"], string> = {
  default: "#f3f4f8",
  warm: "#f3ecdc",
  cool: "#e9eef6",
};

export default function ThemeAppearancePage({ appearance, onChange, onClose }: Props) {
  const fileRef = useRef<HTMLInputElement>(null);
  const maxFont = 150;
  const minFont = 85;

  const pickChatBg = () => {
    fileRef.current?.click();
  };

  const onFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const f = e.target.files?.[0];
    e.target.value = "";
    if (!f) return;
    if (f.size > 3 * 1024 * 1024) {
      alert("图片过大（超过 3MB），请换一张较小的图片");
      return;
    }
    const reader = new FileReader();
    reader.onload = () =>
      onChange({ chat_bg_kind: "custom", chat_bg: String(reader.result || "") });
    reader.readAsDataURL(f);
  };

  return (
    <SettingsShell title="主题与外观" subtitle="强调色和背景设置" onClose={onClose}>
      {/* 模式 */}
      <section className="sp-section">
        <div className="sp-label">模式</div>
        <div className="sp-mode-row">
          <button
            type="button"
            className={`sp-mode-btn ${appearance.mode === "dark" ? "active" : ""}`}
            onClick={() => onChange({ mode: "dark" })}
          >
            <MoonIcon />
            <span>深色</span>
          </button>
          <button
            type="button"
            className={`sp-mode-btn ${appearance.mode === "light" ? "active" : ""}`}
            onClick={() => onChange({ mode: "light" })}
          >
            <SunIcon />
            <span>浅色</span>
          </button>
        </div>
      </section>

      {/* 背景色调 */}
      <section className="sp-section">
        <div className="sp-label">背景色调</div>
        <div className="sp-tone-row">
          {TONES.map((t) => (
            <button
              key={t.key}
              type="button"
              className={`sp-tone-card ${appearance.tone === t.key ? "active" : ""}`}
              onClick={() => onChange({ tone: t.key })}
            >
              <span
                className="sp-tone-swatch"
                style={{ background: TONE_SWATCH[t.key] }}
              />
              <span className="sp-tone-name">{t.label}</span>
              <span className="sp-tone-desc">{t.desc}</span>
            </button>
          ))}
        </div>
      </section>

      {/* 强调色 */}
      <section className="sp-section">
        <div className="sp-label">强调色</div>
        <div className="sp-accent-row">
          {ACCENTS.map((a) => (
            <button
              key={a.key}
              type="button"
              className={`sp-accent ${appearance.accent === a.key ? "active" : ""}`}
              title={a.label}
              onClick={() => onChange({ accent: a.key })}
            >
              <span className="sp-accent-chip" style={{ background: a.color }}>
                {appearance.accent === a.key && (
                  <span className="sp-accent-check">
                    <CheckIcon />
                  </span>
                )}
              </span>
              <span className="sp-accent-name">{a.label}</span>
            </button>
          ))}
        </div>
      </section>

      {/* 字体大小 */}
      <section className="sp-section">
        <div className="sp-font-head">
          <span className="sp-label">字体大小</span>
          <span className="sp-font-value">{appearance.font_scale}%</span>
        </div>
        <input
          className="sp-slider"
          type="range"
          min={minFont}
          max={maxFont}
          step={5}
          value={appearance.font_scale}
          onChange={(e) => onChange({ font_scale: Number(e.target.value) })}
          aria-label="字体大小"
        />
        <div className="sp-slider-ticks">
          <span>{minFont}%</span>
          <button
            type="button"
            className="sp-reset-link"
            onClick={() => onChange({ font_scale: 100 })}
          >
            重置（100%）
          </button>
          <span>{maxFont}%</span>
        </div>
        <div className="sp-hint">调整菜单、聊天、标签及整个界面的文字大小。</div>
      </section>

      {/* 背景光晕 */}
      <div className="sp-card sp-row-card">
        <div className="sp-row-text">
          <div className="sp-row-title">背景光晕</div>
          <div className="sp-row-desc">显示柔和的背景光效</div>
        </div>
        <button
          type="button"
          className={`set-toggle ${appearance.glow ? "on" : ""}`}
          role="switch"
          aria-checked={appearance.glow}
          aria-label="背景光晕"
          onClick={() => onChange({ glow: !appearance.glow })}
        >
          <span className="set-toggle-thumb" />
        </button>
      </div>

      {/* 聊天背景图片 */}
      <section className="sp-section">
        <div className="sp-label">聊天背景图片</div>
        <div className="sp-bgimg-row">
          <button
            type="button"
            className={`sp-bgimg-card ${appearance.chat_bg_kind === "none" ? "active" : ""}`}
            onClick={() => onChange({ chat_bg_kind: "none" })}
          >
            <span className="sp-bgimg-box">
              <XIcon />
            </span>
            <span className="sp-tone-name">无</span>
          </button>
          <button
            type="button"
            className={`sp-bgimg-card ${appearance.chat_bg_kind === "custom" ? "active" : ""}`}
            onClick={pickChatBg}
            title="选择自定义背景图片"
          >
            <span className="sp-bgimg-box">
              {appearance.chat_bg_kind === "custom" && appearance.chat_bg ? (
                <img src={appearance.chat_bg} alt="自定义背景预览" />
              ) : (
                <ImageIcon />
              )}
            </span>
            <span className="sp-tone-name">自定义</span>
          </button>
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            style={{ display: "none" }}
            onChange={onFile}
          />
        </div>
        {appearance.chat_bg_kind === "custom" && appearance.chat_bg && (
          <button
            type="button"
            className="sp-link-danger"
            onClick={() => onChange({ chat_bg_kind: "none", chat_bg: "" })}
          >
            移除自定义背景
          </button>
        )}
      </section>
    </SettingsShell>
  );
}
