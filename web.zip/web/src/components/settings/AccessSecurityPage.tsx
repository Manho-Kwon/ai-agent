import { useEffect, useState } from "react";
import { api, getAuthToken } from "../../api";
import SettingsShell from "./SettingsShell";

interface Props {
  onClose: () => void;
}

const ShieldIcon = () => (
  <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
  </svg>
);

const CopyIcon = () => (
  <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
    <rect x="9" y="9" width="13" height="13" rx="2" />
    <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
  </svg>
);

/** 设置 → 访问安全：API 访问认证开关（共享给团队前必须开启）。
 *  enable/disable 仅允许本机回环调用；token 前端存 localStorage 随请求携带。 */
export default function AccessSecurityPage({ onClose }: Props) {
  const [status, setStatus] = useState<{ enabled: boolean; token_configured: boolean } | null>(null);
  const [customToken, setCustomToken] = useState("");
  const [newToken, setNewToken] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const refresh = async () => {
    try {
      setStatus(await api.authStatus());
    } catch (e) {
      setError((e as Error).message);
    }
  };

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const enable = async () => {
    setBusy(true);
    setError(null);
    try {
      const r = await api.authEnable(customToken.trim() || undefined);
      setNewToken(r.token);
      localStorage.setItem("auth-token", r.token);
      setCustomToken("");
      await refresh();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const disable = async () => {
    setBusy(true);
    setError(null);
    try {
      await api.authDisable();
      localStorage.removeItem("auth-token");
      setNewToken(null);
      await refresh();
    } catch (e) {
      setError((e as Error).message);
    } finally {
      setBusy(false);
    }
  };

  const copyToken = async () => {
    if (!newToken) return;
    try {
      await navigator.clipboard.writeText(newToken);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      /* 剪贴板不可用时静默 */
    }
  };

  const enabled = status?.enabled ?? false;
  const localToken = getAuthToken();

  return (
    <SettingsShell
      title="访问安全"
      subtitle="为 API 与对话接口开启访问令牌认证，共享给团队前建议开启。"
      onClose={onClose}
    >
      <div className="sp-card sp-row-card mm-card">
        <div className="sp-row-text">
          <div className="sp-row-title">访问认证</div>
          <div className="sp-row-desc">
            {enabled
              ? "已开启：所有 /api 请求需携带 Authorization: Bearer <token>（本页保存后自动携带）"
              : "未开启：任何能访问到本服务的人都可以直接使用 API"}
          </div>
        </div>
        <span className={`auth-badge ${enabled ? "on" : "off"}`}>
          {enabled ? "已开启" : "未开启"}
        </span>
      </div>

      {!enabled && (
        <div className="sp-card sec-card">
          <div className="sp-row-title">开启认证</div>
          <div className="sp-row-desc">
            留空则自动生成安全随机 token；也可填入自定义 token（至少 8 位）。
          </div>
          <input
            className="sec-token-input"
            type="text"
            placeholder="自定义 token（可选）"
            value={customToken}
            onChange={(e) => setCustomToken(e.target.value)}
          />
          <div className="mm-actions">
            <button type="button" className="mm-save-btn" onClick={enable} disabled={busy}>
              <ShieldIcon />
              {busy ? "处理中…" : "开启认证"}
            </button>
          </div>
        </div>
      )}

      {enabled && (
        <div className="sp-card sec-card">
          <div className="sp-row-title">关闭认证</div>
          <div className="sp-row-desc">
            关闭后接口恢复开放访问（开关操作仅允许本机执行）。
          </div>
          <div className="mm-actions">
            <button type="button" className="btn-confirm-deny" onClick={disable} disabled={busy}>
              {busy ? "处理中…" : "关闭认证"}
            </button>
          </div>
        </div>
      )}

      {newToken && (
        <div className="sp-card sec-card sec-token-reveal">
          <div className="sp-row-title">你的访问令牌（仅展示这一次）</div>
          <div className="sec-token-row">
            <code className="sec-token-value">{newToken}</code>
            <button type="button" className="ci-icon" title="复制" onClick={copyToken}>
              {copied ? "✓" : <CopyIcon />}
            </button>
          </div>
          <div className="sp-row-desc">
            已自动保存到本浏览器；其他设备访问时在各自浏览器保存该 token。
          </div>
        </div>
      )}

      {enabled && localToken && (
        <div className="sp-row-desc sec-local-note">
          本浏览器已保存访问令牌，请求将自动携带。
        </div>
      )}
      {error && <div className="sp-err-inline sec-error">{error}</div>}
    </SettingsShell>
  );
}
