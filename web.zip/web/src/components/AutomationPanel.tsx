import { useEffect, useMemo, useState } from "react";
import { api } from "../api";
import type { AutomationMeta, AutomationRun } from "../types";
import AddAutomationModal from "./AddAutomationModal";

interface Props {
  onClose: () => void;
}

const WEEKDAYS = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"];

/* ── 图标（线性风格，与全站一致） ── */

function ClockCheckIcon() {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor"
      strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <circle cx="12" cy="12" r="9" />
      <polyline points="12 7 12 12 15.5 14" />
      <path d="M17.5 4.5l1.8-1.8 1.8 1.8" />
    </svg>
  );
}

/* 自动化模块标题图标（与侧边栏「自动化」菜单项完全一致：双循环箭头） */
function CycleIcon() {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor"
      strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <polyline points="23 4 23 10 17 10" />
      <polyline points="1 20 1 14 7 14" />
      <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
    </svg>
  );
}

function RunRecordIcon() {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor"
      strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
      <polyline points="14 2 14 8 20 8" />
      <line x1="8" y1="13" x2="16" y2="13" />
      <line x1="8" y1="17" x2="13" y2="17" />
    </svg>
  );
}

function FunnelIcon() {
  return (
    <svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor"
      strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M22 3H2l8 9.46V19l4 2v-8.54z" />
    </svg>
  );
}

function SearchIcon() {
  return (
    <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor"
      strokeWidth={1.8} strokeLinecap="round" aria-hidden>
      <circle cx="11" cy="11" r="7" />
      <line x1="21" y1="21" x2="16.2" y2="16.2" />
    </svg>
  );
}

function RefreshIcon({ spinning }: { spinning: boolean }) {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor"
      strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden
      style={spinning ? { animation: "au-spin 0.8s linear infinite" } : undefined}>
      <polyline points="23 4 23 10 17 10" />
      <polyline points="1 20 1 14 7 14" />
      <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
    </svg>
  );
}

function ChevronDownIcon({ size = 14 }: { size?: number }) {
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} fill="none" stroke="currentColor"
      strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <polyline points="6 9 12 15 18 9" />
    </svg>
  );
}

function PlayIcon() {
  return (
    <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor" stroke="none" aria-hidden>
      <path d="M7 4.5v15c0 .8.9 1.3 1.6.9l12-7.5c.6-.4.6-1.4 0-1.8l-12-7.5C7.9 3.2 7 3.7 7 4.5z" />
    </svg>
  );
}

function PauseIcon() {
  return (
    <svg viewBox="0 0 24 24" width="14" height="14" fill="currentColor" stroke="none" aria-hidden>
      <rect x="6" y="4" width="4" height="16" rx="1" />
      <rect x="14" y="4" width="4" height="16" rx="1" />
    </svg>
  );
}

function PencilIcon() {
  return (
    <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor"
      strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M12 20h9" />
      <path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z" />
    </svg>
  );
}

function TrashIcon() {
  return (
    <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor"
      strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <polyline points="3 6 5 6 21 6" />
      <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
    </svg>
  );
}

function XIcon() {
  return (
    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor"
      strokeWidth={2} strokeLinecap="round" aria-hidden>
      <line x1="6" y1="6" x2="18" y2="18" />
      <line x1="18" y1="6" x2="6" y2="18" />
    </svg>
  );
}

/* ── 展示 helpers ── */

export function scheduleText(s: AutomationMeta["schedule"]): string {
  const p = (n: number) => String(n).padStart(2, "0");
  if (s.type === "once") {
    if (!s.run_at) return "单次";
    const d = new Date(s.run_at);
    if (Number.isNaN(d.getTime())) return "单次";
    return `单次 ${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(
      d.getHours()
    )}:${p(d.getMinutes())}`;
  }
  if (s.type === "weekly") {
    return `每${WEEKDAYS[s.weekday ?? 0]} ${s.time || ""}`;
  }
  return `每天 ${s.time || ""}`;
}

function statusMeta(status: AutomationMeta["status"]): { label: string; cls: string } {
  if (status === "active") return { label: "运行中", cls: "au-st-active" };
  if (status === "paused") return { label: "已暂停", cls: "au-st-paused" };
  return { label: "已完成", cls: "au-st-done" };
}

function fmtTime(iso: string | null | undefined): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}/${p(d.getMonth() + 1)}/${p(d.getDate())} ${p(d.getHours())}:${p(
    d.getMinutes()
  )}:${p(d.getSeconds())}`;
}

const STATUS_FILTERS = [
  { key: "all", label: "全部状态" },
  { key: "active", label: "运行中" },
  { key: "paused", label: "已暂停" },
  { key: "done", label: "已完成" },
] as const;

const TEMPLATE = {
  name: "生成昨日 AI 重点资讯总结",
  prompt:
    "汇总昨日人工智能领域的重点资讯，按重要程度排序，生成一份包含标题、摘要与来源链接的中文简报，控制在 10 条以内。",
};

export default function AutomationPanel({ onClose }: Props) {
  const [tab, setTab] = useState<"tasks" | "runs">("tasks");
  const [items, setItems] = useState<AutomationMeta[]>([]);
  const [runs, setRuns] = useState<AutomationRun[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<(typeof STATUS_FILTERS)[number]["key"]>("all");
  const [filterMenu, setFilterMenu] = useState(false);
  const [addMenu, setAddMenu] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [batchMode, setBatchMode] = useState(false);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [busy, setBusy] = useState(false);
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<AutomationMeta | null>(null);
  const [template, setTemplate] = useState<{ name?: string; prompt?: string } | null>(null);

  const flashNotice = (msg: string) => {
    setNotice(msg);
    setTimeout(() => setNotice((v) => (v === msg ? null : v)), 2600);
  };

  const refresh = async () => {
    setRefreshing(true);
    try {
      const data = await api.listAutomations();
      setItems(data.automations);
      setRuns(data.runs);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "加载自动化任务失败");
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    refresh();
  }, []);

  const visibleItems = useMemo(() => {
    const q = query.trim().toLowerCase();
    return items.filter((a) => {
      if (statusFilter !== "all" && a.status !== statusFilter) return false;
      if (!q) return true;
      return (
        a.name.toLowerCase().includes(q) ||
        a.prompt.toLowerCase().includes(q) ||
        (a.workspace_name || "").toLowerCase().includes(q)
      );
    });
  }, [items, query, statusFilter]);

  const visibleRuns = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return runs;
    return runs.filter(
      (r) => r.name.toLowerCase().includes(q) || (r.detail || "").toLowerCase().includes(q)
    );
  }, [runs, query]);

  const toggleSelect = (id: string) => {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const exitBatch = () => {
    setBatchMode(false);
    setSelected(new Set());
  };

  const handleToggle = async (a: AutomationMeta) => {
    const nextActive = a.status !== "active";
    try {
      const rec = await api.toggleAutomation(a.id, nextActive);
      setItems((prev) => prev.map((x) => (x.id === a.id ? rec : x)));
      flashNotice(nextActive ? `已启用「${a.name}」` : `已暂停「${a.name}」`);
    } catch (e) {
      setError(e instanceof Error ? e.message : "操作失败");
    }
  };

  const handleRun = async (a: AutomationMeta) => {
    if (busy) return;
    setBusy(true);
    try {
      const run = await api.runAutomation(a.id);
      await refresh();
      flashNotice(`已手动触发「${a.name}」，运行记录 #${run.id.slice(0, 6)}`);
    } catch (e) {
      setError(e instanceof Error ? e.message : "触发失败");
    } finally {
      setBusy(false);
    }
  };

  const handleDelete = async (a: AutomationMeta) => {
    if (!confirm(`删除自动化任务「${a.name}」？\n该任务的运行记录会保留。`)) return;
    try {
      await api.deleteAutomation(a.id);
      setItems((prev) => prev.filter((x) => x.id !== a.id));
      setSelected((prev) => {
        const next = new Set(prev);
        next.delete(a.id);
        return next;
      });
      flashNotice("任务已删除");
    } catch (e) {
      setError(e instanceof Error ? e.message : "删除失败");
    }
  };

  const handleBatch = async (action: "pause" | "resume" | "delete") => {
    const ids = [...selected];
    if (ids.length === 0) return;
    if (action === "delete" && !confirm(`确认删除选中的 ${ids.length} 个自动化任务？`)) return;
    setBusy(true);
    try {
      const r = await api.batchAutomations(action, ids);
      await refresh();
      exitBatch();
      flashNotice(
        action === "delete"
          ? `已删除 ${r.affected} 个任务`
          : action === "pause"
            ? `已暂停 ${r.affected} 个任务`
            : `已启用 ${r.affected} 个任务`
      );
    } catch (e) {
      setError(e instanceof Error ? e.message : "批量操作失败");
    } finally {
      setBusy(false);
    }
  };

  const handleClearRuns = async () => {
    if (runs.length === 0) return;
    if (!confirm("清空全部运行记录？")) return;
    try {
      await api.clearAutomationRuns();
      setRuns([]);
      flashNotice("运行记录已清空");
    } catch (e) {
      setError(e instanceof Error ? e.message : "清空失败");
    }
  };

  const openCreate = (tpl: boolean) => {
    setEditing(null);
    setTemplate(tpl ? TEMPLATE : null);
    setAddMenu(false);
    setModalOpen(true);
  };

  const openEdit = (a: AutomationMeta) => {
    setTemplate(null);
    setEditing(a);
    setModalOpen(true);
  };

  const handleSaved = async () => {
    setModalOpen(false);
    setEditing(null);
    setTemplate(null);
    await refresh();
    flashNotice(editing ? "自动化任务已更新" : "自动化任务已创建");
  };

  const filterLabel = STATUS_FILTERS.find((f) => f.key === statusFilter)?.label ?? "全部状态";

  return (
    <main className="library-panel au-panel">
      {/* 左上角标题区域（与资料库/工作区完全一致的布局与视觉规范） */}
      <div className="lib-head">
        <div className="lib-title-wrap">
          <div className="lib-title">
            <span className="lib-title-icon">
              <CycleIcon />
            </span>
            自动化
          </div>
          <div className="lib-sub">定时任务与运行记录管理</div>
        </div>
        <button
          className="sb-icon-btn"
          onClick={onClose}
          title="返回对话"
          type="button"
          aria-label="返回对话"
        >
          <XIcon />
        </button>
      </div>

      {/* 顶部：Tab + 工具条（对齐参考图） */}
      <div className="au-topbar">
        <div className="au-tabs" role="tablist">
          <button
            type="button"
            role="tab"
            aria-selected={tab === "tasks"}
            className={`au-tab${tab === "tasks" ? " active" : ""}`}
            onClick={() => setTab("tasks")}
          >
            <ClockCheckIcon />
            定时任务
          </button>
          <button
            type="button"
            role="tab"
            aria-selected={tab === "runs"}
            className={`au-tab${tab === "runs" ? " active" : ""}`}
            onClick={() => setTab("runs")}
          >
            <RunRecordIcon />
            运行记录
            {runs.length > 0 && <span className="au-tab-count">{runs.length}</span>}
          </button>
        </div>

        <div className="au-tools">
          <div className="au-filter-wrap">
            <button
              type="button"
              className="au-icon-square"
              title="按状态筛选"
              aria-label="按状态筛选"
              onClick={() => setFilterMenu((v) => !v)}
            >
              <FunnelIcon />
            </button>
            {filterMenu && (
              <>
                <div className="au-popover-mask" onClick={() => setFilterMenu(false)} />
                <div className="au-popover">
                  {STATUS_FILTERS.map((f) => (
                    <button
                      key={f.key}
                      type="button"
                      className={`au-pop-item${statusFilter === f.key ? " checked" : ""}`}
                      onClick={() => {
                        setStatusFilter(f.key);
                        setFilterMenu(false);
                      }}
                    >
                      {f.label}
                      {statusFilter === f.key && <span className="au-pop-tick">✓</span>}
                    </button>
                  ))}
                </div>
              </>
            )}
          </div>

          <div className="lib-search au-search">
            <SearchIcon />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="搜索自动化/记录"
              aria-label="搜索自动化或运行记录"
            />
          </div>

          <button
            type="button"
            className="au-icon-square"
            title="刷新"
            aria-label="刷新"
            onClick={refresh}
            disabled={refreshing}
          >
            <RefreshIcon spinning={refreshing} />
          </button>

          {tab === "tasks" && (
            <button
              type="button"
              className={`au-btn-outline${batchMode ? " active" : ""}`}
              onClick={() => (batchMode ? exitBatch() : setBatchMode(true))}
            >
              {batchMode ? "完成" : "批量管理"}
            </button>
          )}
          {tab === "runs" && (
            <button type="button" className="au-btn-outline" onClick={handleClearRuns}>
              清空记录
            </button>
          )}

          <div className="au-add-wrap">
            <button
              type="button"
              className="au-btn-primary"
              onClick={() => openCreate(false)}
            >
              添加自动化
            </button>
            <button
              type="button"
              className="au-btn-primary-caret"
              aria-label="更多添加方式"
              title="更多添加方式"
              onClick={() => setAddMenu((v) => !v)}
            >
              <ChevronDownIcon size={15} />
            </button>
            {addMenu && (
              <>
                <div className="au-popover-mask" onClick={() => setAddMenu(false)} />
                <div className="au-popover au-popover-right">
                  <button type="button" className="au-pop-item" onClick={() => openCreate(false)}>
                    空白任务
                  </button>
                  <button type="button" className="au-pop-item" onClick={() => openCreate(true)}>
                    从示例模板创建
                  </button>
                </div>
              </>
            )}
          </div>

          <button
            type="button"
            className="sb-icon-btn au-close-btn"
            onClick={onClose}
            title="返回对话"
            aria-label="返回对话"
          >
            <XIcon />
          </button>
        </div>
      </div>

      {error && (
        <div className="apm-msg apm-msg-error au-msg" role="alert">
          {error}
          <button type="button" className="ws-msg-close" onClick={() => setError(null)}>
            <XIcon />
          </button>
        </div>
      )}
      {notice && <div className="apm-msg apm-msg-ok au-msg">{notice}</div>}

      {tab === "tasks" ? (
        <div className="au-body">
          {/* 状态筛选行（参考图「已暂停 ⌄」） */}
          <div className="au-filter-row">
            <button
              type="button"
              className="au-status-select"
              onClick={() => setFilterMenu((v) => !v)}
            >
              {filterLabel}
              <ChevronDownIcon size={13} />
            </button>
            {batchMode && (
              <div className="au-batchbar">
                <span className="au-batch-count">已选 {selected.size} 项</span>
                <button
                  type="button"
                  className="au-btn-outline au-batch-btn"
                  disabled={selected.size === 0 || busy}
                  onClick={() => handleBatch("resume")}
                >
                  批量启用
                </button>
                <button
                  type="button"
                  className="au-btn-outline au-batch-btn"
                  disabled={selected.size === 0 || busy}
                  onClick={() => handleBatch("pause")}
                >
                  批量暂停
                </button>
                <button
                  type="button"
                  className="au-btn-outline au-batch-btn au-batch-danger"
                  disabled={selected.size === 0 || busy}
                  onClick={() => handleBatch("delete")}
                >
                  批量删除
                </button>
              </div>
            )}
          </div>

          <div className="au-list">
            {loading ? (
              <div className="au-empty">加载中…</div>
            ) : visibleItems.length === 0 ? (
              <div className="au-empty">
                <div className="au-empty-title">
                  {query || statusFilter !== "all" ? "没有匹配的自动化任务" : "暂无自动化任务"}
                </div>
                <div className="au-empty-desc">
                  {query || statusFilter !== "all"
                    ? "换个关键词或筛选条件试试"
                    : "点击右上角「添加自动化」创建你的第一个定时任务。"}
                </div>
              </div>
            ) : (
              visibleItems.map((a) => {
                const st = statusMeta(a.status);
                return (
                  <div key={a.id} className="au-item">
                    {batchMode && (
                      <label className="au-check" onClick={(e) => e.stopPropagation()}>
                        <input
                          type="checkbox"
                          checked={selected.has(a.id)}
                          onChange={() => toggleSelect(a.id)}
                          aria-label={`选择 ${a.name}`}
                        />
                        <span className="au-check-box" />
                      </label>
                    )}
                    <div className="au-item-main">
                      <div className="au-item-name">{a.name}</div>
                      <div className="au-item-meta">
                        <span className="au-item-ws">
                          {a.workspace_name ? `项目 · ${a.workspace_name}` : "未绑定工作空间"}
                        </span>
                        <span>{scheduleText(a.schedule)}</span>
                        {a.validity.type === "until" && a.validity.end && (
                          <span className="au-tag au-tag-dim">有效期至 {a.validity.end}</span>
                        )}
                        {a.push_wechat && <span className="au-tag au-tag-dim">微信推送</span>}
                        {a.push_wecom && <span className="au-tag au-tag-dim">企微推送</span>}
                        {a.run_count > 0 && (
                          <span className="au-item-last">
                            上次运行 {fmtTime(a.last_run_at)}
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="au-item-right">
                      <span className={`au-status ${st.cls}`}>{st.label}</span>
                      {!batchMode && (
                        <div className="au-item-actions">
                          <button
                            type="button"
                            className="au-act"
                            title={a.status === "active" ? "暂停" : "启用"}
                            onClick={() => handleToggle(a)}
                          >
                            {a.status === "active" ? <PauseIcon /> : <PlayIcon />}
                          </button>
                          <button
                            type="button"
                            className="au-act"
                            title="立即运行"
                            disabled={busy}
                            onClick={() => handleRun(a)}
                          >
                            <PlayIcon />
                          </button>
                          <button
                            type="button"
                            className="au-act"
                            title="编辑"
                            onClick={() => openEdit(a)}
                          >
                            <PencilIcon />
                          </button>
                          <button
                            type="button"
                            className="au-act au-act-danger"
                            title="删除"
                            onClick={() => handleDelete(a)}
                          >
                            <TrashIcon />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      ) : (
        <div className="au-body">
          <div className="au-list">
            {loading ? (
              <div className="au-empty">加载中…</div>
            ) : visibleRuns.length === 0 ? (
              <div className="au-empty">
                <div className="au-empty-title">
                  {query ? "没有匹配的运行记录" : "暂无运行记录"}
                </div>
                <div className="au-empty-desc">
                  任务到期自动触发或手动点击「立即运行」后，记录会显示在这里。
                </div>
              </div>
            ) : (
              visibleRuns.map((r) => (
                <div key={r.id} className="au-run-item">
                  <span
                    className={`au-run-dot ${r.status === "success" ? "dot-green" : r.status === "error" ? "dot-red" : "dot-amber"}`}
                  />
                  <div className="au-run-main">
                    <div className="au-run-name">
                      {r.name}
                      <span className={`au-tag ${r.trigger === "manual" ? "au-tag-blue" : "au-tag-dim"}`}>
                        {r.trigger === "manual" ? "手动" : "定时"}
                      </span>
                    </div>
                    <div className="au-run-detail">{r.detail || "—"}</div>
                  </div>
                  <div className="au-run-right">
                    <span
                      className={`au-run-status ${
                        r.status === "success"
                          ? "au-run-ok"
                          : r.status === "error"
                            ? "au-run-fail"
                            : "au-run-ing"
                      }`}
                    >
                      {r.status === "success" ? "成功" : r.status === "error" ? "失败" : "运行中"}
                    </span>
                    <span className="au-run-time">{fmtTime(r.started_at)}</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {modalOpen && (
        <AddAutomationModal
          editing={editing}
          initial={template}
          onClose={() => {
            setModalOpen(false);
            setEditing(null);
            setTemplate(null);
          }}
          onSaved={handleSaved}
        />
      )}
    </main>
  );
}
