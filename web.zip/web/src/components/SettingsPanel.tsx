import type { ReactNode } from "react";
import type { SettingsPageKey } from "../App";

interface Props {
  /** 当前打开的设置子页面（高亮菜单项） */
  activeKey: SettingsPageKey;
  onOpenSettings: (page: Exclude<SettingsPageKey, null>) => void;
}

function Svg({ children }: { children: ReactNode }) {
  return (
    <svg
      width="15"
      height="15"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      {children}
    </svg>
  );
}

const PaletteIcon = () => (
  <Svg>
    <circle cx="13.5" cy="6.5" r="0.9" />
    <circle cx="17.5" cy="10.5" r="0.9" />
    <circle cx="8.5" cy="7.5" r="0.9" />
    <circle cx="6.5" cy="12.5" r="0.9" />
    <path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10c.9 0 1.6-.7 1.6-1.7 0-.4-.2-.8-.4-1.1-.3-.3-.4-.7-.4-1.1a1.6 1.6 0 0 1 1.6-1.6h2c3 0 5.6-2.5 5.6-5.5C21.9 6 17.5 2 12 2z" />
  </Svg>
);

const UserIcon = () => (
  <Svg>
    <circle cx="12" cy="12" r="10" />
    <circle cx="12" cy="10" r="3" />
    <path d="M7 20.66V19a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v1.66" />
  </Svg>
);

const SearchIcon = () => (
  <Svg>
    <circle cx="11" cy="11" r="7" />
    <path d="m20 20-3.5-3.5" />
  </Svg>
);

const DatabaseIcon = () => (
  <Svg>
    <ellipse cx="12" cy="5" rx="8.5" ry="3" />
    <path d="M3.5 5v14c0 1.7 3.8 3 8.5 3s8.5-1.3 8.5-3V5" />
    <path d="M3.5 12c0 1.7 3.8 3 8.5 3s8.5-1.3 8.5-3" />
  </Svg>
);

const BrainIcon = () => (
  <Svg>
    <path d="M12 5a3 3 0 1 0-5.997.125 4 4 0 0 0-2.526 5.77 4 4 0 0 0 .556 6.588A4 4 0 1 0 12 18Z" />
    <path d="M12 5a3 3 0 1 1 5.997.125 4 4 0 0 1 2.526 5.77 4 4 0 0 1-.556 6.588A4 4 0 1 1 12 18Z" />
    <path d="M15 13a4.5 4.5 0 0 1-3-4 4.5 4.5 0 0 1-3 4" />
  </Svg>
);

const SlidersIcon = () => (
  <Svg>
    <line x1="21" y1="5" x2="14" y2="5" />
    <line x1="10" y1="5" x2="3" y2="5" />
    <line x1="21" y1="12" x2="12" y2="12" />
    <line x1="8" y1="12" x2="3" y2="12" />
    <line x1="21" y1="19" x2="16" y2="19" />
    <line x1="12" y1="19" x2="3" y2="19" />
    <line x1="14" y1="3" x2="14" y2="7" />
    <line x1="8" y1="10" x2="8" y2="14" />
    <line x1="16" y1="17" x2="16" y2="21" />
  </Svg>
);

const ActivityIcon = () => (
  <Svg>
    <path d="M22 12h-4l-3 9L9 3l-3 9H2" />
  </Svg>
);

const ServerIcon = () => (
  <Svg>
    <rect x="2" y="3" width="20" height="8" rx="2" />
    <rect x="2" y="13" width="20" height="8" rx="2" />
    <line x1="6" y1="7" x2="6.01" y2="7" />
    <line x1="6" y1="17" x2="6.01" y2="17" />
  </Svg>
);

const BookIcon = () => (
  <Svg>
    <path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20" />
  </Svg>
);

const TimerIcon = () => (
  <Svg>
    <line x1="10" y1="2" x2="14" y2="2" />
    <line x1="12" y1="14" x2="15" y2="11" />
    <circle cx="12" cy="14" r="8" />
  </Svg>
);

const ShieldIcon = () => (
  <Svg>
    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" />
  </Svg>
);

const Chevron = () => (
  <svg
    className="sm-chevron"
    width="14"
    height="14"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.8"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="m9 18 6-6-6-6" />
  </svg>
);

interface MenuItem {
  icon: ReactNode;
  title: string;
  desc: string;
  dot?: boolean;
  /** 对应的设置子页面 key；无则点击无跳转 */
  page?: Exclude<SettingsPageKey, null>;
}

interface Group {
  title: string;
  desc: string;
  items: MenuItem[];
}

export default function SettingsPanel({ activeKey, onOpenSettings }: Props) {
  // 分组顺序严格固定：个性化 → 模型与连接 → 智能体与自动化 → 知识与上下文
  // 分组名、条目名与副标题保持原样，不新增、不调换
  const groups: Group[] = [
    {
      title: "个性化",
      desc: "外观和个人资料",
      items: [
        {
          icon: <PaletteIcon />,
          title: "主题与外观",
          desc: "强调色和背景设置",
          page: "theme",
        },
        {
          icon: <UserIcon />,
          title: "用户资料",
          desc: "用户资料和平台品牌设置",
          page: "profile",
        },
      ],
    },
    {
      title: "模型与连接",
      desc: "LLM 运行环境与服务状态",
      items: [
        {
          icon: <BrainIcon />,
          title: "LLM 配置",
          desc: "网关、角色模型与高级偏好",
          page: "llm",
        },
        {
          icon: <SlidersIcon />,
          title: "运行与存储",
          desc: "自动执行策略、写入工作区之外、磁盘用量",
          page: "storage",
        },
        {
          icon: <ActivityIcon />,
          title: "连接状态",
          desc: "后端服务器连接状态",
          dot: true,
          page: "connection",
        },
      ],
    },
    {
      title: "智能体与自动化",
      desc: "工具、技能和计划任务",
      items: [
        { icon: <ServerIcon />, title: "MCP 服务器", desc: "服务器连接、工具和 mcp.json", page: "mcp" },
        { icon: <BookIcon />, title: "智能体技能", desc: "可复用工作流和本地技能", page: "skills" },
        { icon: <TimerIcon />, title: "计划任务", desc: "自动任务、计划和运行记录", page: "tasks" },
      ],
    },
    {
      title: "知识与上下文",
      desc: "工作区搜索和长期记忆",
      items: [
        { icon: <SearchIcon />, title: "工作区检索", desc: "自动 · 本地", page: "retrieval" },
        { icon: <DatabaseIcon />, title: "记忆", desc: "开启", page: "memory" },
        { icon: <ShieldIcon />, title: "访问安全", desc: "访问令牌与 API 认证", page: "security" },
      ],
    },
  ];

  return (
    <div className="settings-side">
      {groups.map((g) => (
        <section className="sm-group" key={g.title}>
          <div className="sm-group-title">{g.title}</div>
          <div className="sm-group-desc">{g.desc}</div>
          <div className="sm-items">
            {g.items.map((it) => {
              const page = it.page;
              return (
                <button
                  className={`sm-item ${activeKey && activeKey === page ? "active" : ""}`}
                  key={it.title}
                  type="button"
                  onClick={page ? () => onOpenSettings(page) : undefined}
                >
                  <span className="sm-icon">{it.icon}</span>
                  <span className="sm-text">
                    <span className="sm-item-title">{it.title}</span>
                    <span className="sm-item-desc">{it.desc}</span>
                  </span>
                  {it.dot && <span className="status-dot dot-green" />}
                  <Chevron />
                </button>
              );
            })}
          </div>
        </section>
      ))}
    </div>
  );
}
