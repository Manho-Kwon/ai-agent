import { useEffect, useMemo, useState } from "react";
import { api } from "../api";
import type { WorkspaceMeta, WorkspaceStats } from "../types";
import AddWorkspaceModal from "./AddWorkspaceModal";

interface Props {
  onClose: () => void;
}

/* ── 图标（线性风格，与全站一致） ── */

function FolderIcon({ size = 20 }: { size?: number }) {
  return (
    <svg viewBox="0 0 24 24" width={size} height={size} fill="none" stroke="currentColor"
      strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
    </svg>
  );
}

function SearchIcon() {
  return (
    <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor"
      strokeWidth={1.8} strokeLinecap="round" aria-hidden>
      <circle cx="11" cy="11" r="7" />
      <line x1="21" y1="21" x2="16.2" y2="16.2" />
    </svg>
  );
}

function XIcon() {
  return (
    <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor"
      strokeWidth={1.8} strokeLinecap="round" aria-hidden>
      <line x1="6" y1="6" x2="18" y2="18" />
      <line x1="18" y1="6" x2="6" y2="18" />
    </svg>
  );
}

function ChevronUpIcon({ up }: { up: boolean }) {
  return (
    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor"
      strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" aria-hidden
      style={{ transform: up ? "none" : "rotate(180deg)", transition: "transform .15s" }}>
      <polyline points="6 15 12 9 18 15" />
    </svg>
  );
}

function TrashIcon() {
  return (
    <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor"
      strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <polyline points="3 6 5 6 21 6" />
      <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2" />
    </svg>
  );
}

/* 横幅左侧的「知识」图标（书本+闪电，青色） */
function KnowledgeIcon() {
  return (
    <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor"
      strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20V3H6.5A2.5 2.5 0 0 0 4 5.5v14z" />
      <path d="M13 7l-3 4h4l-3 4" />
    </svg>
  );
}

function ConvertIcon() {
  return (
    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor"
      strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <polyline points="17 3 21 7 17 11" />
      <line x1="21" y1="7" x2="9" y2="7" />
      <polyline points="7 13 3 17 7 21" />
      <line x1="3" y1="17" x2="15" y2="17" />
    </svg>
  );
}

function ComposeIcon() {
  return (
    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor"
      strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M12 20h9" />
      <path d="M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4z" />
    </svg>
  );
}

function DatabaseIcon() {
  return (
    <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor"
      strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <ellipse cx="12" cy="5" rx="8" ry="3" />
      <path d="M4 5v6c0 1.66 3.58 3 8 3s8-1.34 8-3V5" />
      <path d="M4 11v6c0 1.66 3.58 3 8 3s8-1.34 8-3v-6" />
    </svg>
  );
}

function RetryIcon() {
  return (
    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor"
      strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <polyline points="23 4 23 10 17 10" />
      <path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10" />
    </svg>
  );
}

function SyncIcon() {
  return (
    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor"
      strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <polyline points="23 4 23 10 17 10" />
      <polyline points="1 20 1 14 7 14" />
      <path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15" />
    </svg>
  );
}

function PulseIcon() {
  return (
    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor"
      strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <polyline points="22 12 18 12 15 21 9 3 6 12 2 12" />
    </svg>
  );
}

function SparkIcon() {
  return (
    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor"
      strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9z" />
      <path d="M19 15l.9 2.1L22 18l-2.1.9L19 21l-.9-2.1L16 18l2.1-.9z" />
    </svg>
  );
}

function RowsIcon() {
  return (
    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor"
      strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <rect x="3" y="4" width="18" height="5" rx="1" />
      <rect x="3" y="13" width="18" height="5" rx="1" />
    </svg>
  );
}

function GaugeIcon() {
  return (
    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor"
      strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M20.5 12A8.5 8.5 0 1 0 12 20.5" />
      <path d="M12 12l4.5-4.5" />
      <circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none" />
    </svg>
  );
}

function ClockIcon() {
  return (
    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor"
      strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <circle cx="12" cy="12" r="9" />
      <polyline points="12 7 12 12 15.5 14" />
    </svg>
  );
}

function ArrowRightIcon() {
  return (
    <svg viewBox="0 0 24 24" width="13" height="13" fill="none" stroke="currentColor"
      strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <line x1="4" y1="12" x2="20" y2="12" />
      <polyline points="14 6 20 12 14 18" />
    </svg>
  );
}

/* ── 工具函数 ── */

function fmtTime(iso: string | null | undefined): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}/${d.getMonth() + 1}/${d.getDate()} ${p(d.getHours())}:${p(d.getMinutes())}:${p(d.getSeconds())}`;
}

function fmtNum(n: number): string {
  return n.toLocaleString("zh-CN");
}

export default function WorkspacePanel({ onClose }: Props) {
  const [workspaces, setWorkspaces] = useState<WorkspaceMeta[]>([]);
  const [stats, setStats] = useState<WorkspaceStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [adding, setAdding] = useState(false);
  const [panelOpen, setPanelOpen] = useState(true);
  const [busy, setBusy] = useState(false);
  // 每日检查本地表单（从 stats 初始化）
  const [dailyEnabled, setDailyEnabled] = useState(false);
  const [dailyHour, setDailyHour] = useState("3");
  const [dailyMinute, setDailyMinute] = useState("0");

  const applyStats = (s: WorkspaceStats) => {
    setStats(s);
    setDailyEnabled(s.daily.enabled);
    setDailyHour(String(s.daily.hour));
    setDailyMinute(String(s.daily.minute));
  };

  const flashNotice = (msg: string) => {
    setNotice(msg);
    setTimeout(() => setNotice((v) => (v === msg ? null : v)), 2600);
  };

  const refresh = async () => {
    try {
      const [list, s] = await Promise.all([api.listWorkspaces(), api.workspaceStats()]);
      setWorkspaces(list.workspaces);
      applyStats(s);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : "加载工作区失败");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refresh();
  }, []);

  const visible = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return workspaces;
    return workspaces.filter(
      (w) =>
        w.name.toLowerCase().includes(q) ||
        w.path.toLowerCase().includes(q) ||
        (w.description || "").toLowerCase().includes(q)
    );
  }, [workspaces, query]);

  const handleSync = async () => {
    if (busy) return;
    setBusy(true);
    try {
      applyStats(await api.syncWorkspaces());
      flashNotice("文件更改同步完成");
    } catch (e) {
      setError(e instanceof Error ? e.message : "同步失败");
    } finally {
      setBusy(false);
    }
  };

  const handleRetry = async () => {
    if (busy) return;
    setBusy(true);
    try {
      const r = await api.retryFailedTasks();
      flashNotice(r.message || `已重试 ${r.retried} 个任务`);
    } catch (e) {
      setError(e instanceof Error ? e.message : "重试失败");
    } finally {
      setBusy(false);
    }
  };

  const handleSaveDaily = async () => {
    const h = Number(dailyHour);
    const m = Number(dailyMinute);
    if (!Number.isInteger(h) || !Number.isInteger(m) || h < 0 || h > 23 || m < 0 || m > 59) {
      setError("时间不合法：小时 0-23，分钟 0-59");
      return;
    }
    try {
      applyStats(await api.setDailyConfig({ enabled: dailyEnabled, hour: h, minute: m }));
      setError(null);
      flashNotice("每日检查设置已保存");
    } catch (e) {
      setError(e instanceof Error ? e.message : "保存失败");
    }
  };

  const handleCreated = async () => {
    setAdding(false);
    flashNotice("工作区已添加");
    await refresh();
  };

  const handleDelete = async (w: WorkspaceMeta) => {
    if (!confirm(`删除工作区「${w.name}」？\n${w.path}\n（仅解除注册，不会删除磁盘上的文件）`)) return;
    try {
      await api.deleteWorkspace(w.id);
      setWorkspaces((prev) => prev.filter((x) => x.id !== w.id));
      // 重新同步统计（文档数等随注册变化）
      applyStats(await api.workspaceStats());
      flashNotice("工作区已删除");
    } catch (e) {
      setError(e instanceof Error ? e.message : "删除失败");
    }
  };

  const openPicker = () => setAdding(true);

  return (
    <main className="library-panel ws-panel">
      <div className="lib-head">
        <div className="lib-title-wrap">
          <div className="lib-title">
            <span className="lib-title-icon">
              <FolderIcon size={17} />
            </span>
            工作区
          </div>
          <div className="lib-sub">将本地文件转换、搜索并编写为个人知识</div>
        </div>
        <button
          className="sb-icon-btn"
          onClick={onClose}
          title="返回对话"
          type="button"
          aria-label="返回对话"
        >
          <XIcon />
        </button>
      </div>

      <div className="ws-body">
        {/* 引导横幅 */}
        <div className="ws-banner">
          <span className="ws-banner-icon">
            <KnowledgeIcon />
          </span>
          <div className="ws-banner-text">
            <div className="ws-banner-title">将本地文件转化为 AI 可用的个人知识</div>
            <div className="ws-banner-desc">
              连接个人本地目录，通过 Convert 将文件整理为 LLM 可理解、可搜索的内容，再使用
              Compose 创建并组织新文档。
            </div>
          </div>
          <div className="ws-banner-actions">
            <button className="ws-btn-ghost" type="button" disabled title="即将上线">
              <ConvertIcon />
              转换文件
            </button>
            <span className="ws-banner-arrow">
              <ArrowRightIcon />
            </span>
            <button className="ws-btn-ghost" type="button" disabled title="即将上线">
              <ComposeIcon />
              编写文档
            </button>
          </div>
        </div>

        {/* 搜索 + 添加 */}
        <div className="ws-toolbar">
          <div className="lib-search">
            <SearchIcon />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="搜索工作区名称或路径..."
              aria-label="搜索工作区"
            />
          </div>
          <button className="ws-add-btn" onClick={openPicker} type="button">
            ＋ 添加工作区
          </button>
        </div>

        {error && (
          <div className="apm-msg apm-msg-error" role="alert">
            {error}
            <button type="button" className="ws-msg-close" onClick={() => setError(null)}>
              <XIcon />
            </button>
          </div>
        )}
        {notice && <div className="apm-msg apm-msg-ok">{notice}</div>}

        {/* 搜索索引面板 */}
        <div className="ws-index">
          <button
            type="button"
            className="ws-index-head"
            onClick={() => setPanelOpen((v) => !v)}
            title={panelOpen ? "收起" : "展开"}
          >
            <span className="ws-index-title">
              <DatabaseIcon />
              工作区搜索索引
            </span>
            <span className="ws-index-badges">
              <span className="ws-badge ws-badge-ok">
                {stats?.search.ready ? "搜索就绪" : "未就绪"}
              </span>
              <span className="ws-badge">{stats?.schema || "SQLite v2 · schema 2"}</span>
              <span className="ws-badge-plain">
                {fmtNum(stats?.documents ?? 0)} 个文档 · {fmtNum(stats?.paragraphs ?? 0)} 个段落
              </span>
            </span>
            <span className="ws-index-collapse">
              {panelOpen ? "收起" : "展开"}
              <ChevronUpIcon up={panelOpen} />
            </span>
          </button>

          {panelOpen && (
            <div className="ws-index-body">
              <div className="ws-index-actions">
                <button
                  className="ws-btn-ghost"
                  type="button"
                  onClick={handleRetry}
                  disabled={busy}
                >
                  <RetryIcon />
                  重试失败任务
                </button>
                <button
                  className="ws-btn-ghost"
                  type="button"
                  onClick={handleSync}
                  disabled={busy}
                >
                  {busy ? <span className="ws-spinner-dark" aria-hidden /> : <SyncIcon />}
                  同步文件更改
                </button>
              </div>

              {/* 五个统计卡 */}
              <div className="ws-stats-row ws-stats-5">
                <div className="ws-stat-card">
                  <span className="ws-stat-label">可检索文档</span>
                  <span className="ws-stat-value">{fmtNum(stats?.documents ?? 0)}</span>
                </div>
                <div className="ws-stat-card">
                  <span className="ws-stat-label">索引段落</span>
                  <span className="ws-stat-value">{fmtNum(stats?.paragraphs ?? 0)}</span>
                </div>
                <div className="ws-stat-card">
                  <span className="ws-stat-label">等待内容同步</span>
                  <span className="ws-stat-value">{fmtNum(stats?.pending_sync ?? 0)}</span>
                </div>
                <div className="ws-stat-card">
                  <span className="ws-stat-label">可重试</span>
                  <span className="ws-stat-value">{fmtNum(stats?.retryable ?? 0)}</span>
                </div>
                <div className="ws-stat-card">
                  <span className="ws-stat-label">需检查的失败</span>
                  <span className="ws-stat-value">{fmtNum(stats?.failed ?? 0)}</span>
                </div>
              </div>

              {/* 四个状态卡 */}
              <div className="ws-stats-row ws-stats-4">
                <div className="ws-info-card">
                  <div className="ws-info-head">
                    <PulseIcon />
                    <span>最近文件同步</span>
                  </div>
                  <div className="ws-info-row">
                    <span>监视器</span>
                    <span>{stats?.monitor || "—"}</span>
                  </div>
                  <div className="ws-info-row">
                    <span>最后文件事件</span>
                    <span>{stats?.last_file_event ? fmtTime(stats.last_file_event) : "无记录"}</span>
                  </div>
                  <div className="ws-info-row">
                    <span>最后同步</span>
                    <span>{fmtTime(stats?.last_sync)}</span>
                  </div>
                </div>

                <div className="ws-info-card">
                  <div className="ws-info-head">
                    <SparkIcon />
                    <span>语义缓存</span>
                    <span className="ws-badge">已禁用</span>
                  </div>
                  <div className="ws-info-row">
                    <span>模型信息不可用</span>
                    <span />
                  </div>
                  <div className="ws-info-row">
                    <span>最新 / 总计</span>
                    <span>
                      {stats?.semantic_cache.latest ?? 0} / {stats?.semantic_cache.total ?? 0}
                    </span>
                  </div>
                  <div className="ws-info-row">
                    <span>覆盖率</span>
                    <span>{stats?.semantic_cache.hit_rate || "0%"}</span>
                  </div>
                </div>

                <div className="ws-info-card">
                  <div className="ws-info-head">
                    <RowsIcon />
                    <span>重排器</span>
                    <span className="ws-badge">已禁用</span>
                  </div>
                  <div className="ws-info-row">
                    <span>{stats?.reranker.mode || "auto"}</span>
                    <span />
                  </div>
                  <div className="ws-info-row">
                    <span>最近 / p95</span>
                    <span>
                      {stats?.reranker.recent_ms ?? 0} ms /{" "}
                      {stats?.reranker.p95_ms != null ? `${stats.reranker.p95_ms} ms` : "—"}
                    </span>
                  </div>
                </div>

                <div className="ws-info-card">
                  <div className="ws-info-head">
                    <GaugeIcon />
                    <span>近期搜索延迟</span>
                  </div>
                  <div className="ws-info-row">
                    <span>p50 / p95</span>
                    <span>
                      {stats?.search.p50 != null ? `${stats.search.p50} ms` : "—"} /{" "}
                      {stats?.search.p95 != null ? `${stats.search.p95} ms` : "—"}
                    </span>
                  </div>
                  <div className="ws-info-row">
                    <span>样本</span>
                    <span>{fmtNum(stats?.search.samples ?? 0)}</span>
                  </div>
                  <div className="ws-info-row">
                    <span>最后搜索</span>
                    <span>
                      {stats?.search.last_search ? fmtTime(stats.search.last_search) : "无记录"}
                    </span>
                  </div>
                </div>
              </div>

              {/* 每日文件更改检查 */}
              <div className="ws-daily">
                <div className="ws-daily-left">
                  <ClockIcon />
                  <span className="ws-daily-label">每日文件更改检查</span>
                  <button
                    type="button"
                    className={`ws-toggle${dailyEnabled ? " on" : ""}`}
                    role="switch"
                    aria-checked={dailyEnabled}
                    aria-label="启用每日文件更改检查"
                    onClick={() => setDailyEnabled((v) => !v)}
                  >
                    <span className="ws-toggle-knob" />
                  </button>
                  <span className="ws-daily-time">
                    <input
                      type="number"
                      min={0}
                      max={23}
                      value={dailyHour}
                      onChange={(e) => setDailyHour(e.target.value)}
                      aria-label="小时"
                    />
                    <i>:</i>
                    <input
                      type="number"
                      min={0}
                      max={59}
                      value={dailyMinute}
                      onChange={(e) => setDailyMinute(e.target.value)}
                      aria-label="分钟"
                    />
                  </span>
                  <button type="button" className="ws-save-btn" onClick={handleSaveDaily}>
                    保存
                  </button>
                </div>
                <span className="ws-daily-right">
                  最后同步 {fmtTime(stats?.last_sync)}
                </span>
              </div>
            </div>
          )}
        </div>

        {/* 工作区列表 */}
        <div className="ws-list">
          {loading ? (
            <div className="ws-empty">
              <span className="ws-empty-icon"><FolderIcon size={30} /></span>
              加载中…
            </div>
          ) : visible.length === 0 ? (
            <div className="ws-empty">
              <span className="ws-empty-icon"><FolderIcon size={30} /></span>
              <div className="ws-empty-title">
                {query ? "没有匹配的工作区" : "尚未注册工作区"}
              </div>
              <div className="ws-empty-desc">
                {query ? "换个关键词试试" : "添加本地目录以开始使用。"}
              </div>
              {!query && (
                <button type="button" className="ws-add-btn" onClick={openPicker}>
                  ＋ 添加工作区
                </button>
              )}
            </div>
          ) : (
            visible.map((w) => (
              <div key={w.id} className="ws-card" title={w.path}>
                <span className="ws-card-icon">
                  <FolderIcon size={18} />
                </span>
                <div className="ws-card-main">
                  <div className="ws-card-name">{w.name}</div>
                  <div className="ws-card-path">{w.path}</div>
                  {w.description && <div className="ws-card-desc">{w.description}</div>}
                </div>
                <div className="ws-card-meta">
                  <span>注册于 {fmtTime(w.created_at)}</span>
                  <button
                    className="lib-del"
                    title="删除工作区"
                    type="button"
                    onClick={() => handleDelete(w)}
                  >
                    <TrashIcon />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {adding && (
        <AddWorkspaceModal onClose={() => setAdding(false)} onCreated={handleCreated} />
      )}
    </main>
  );
}
