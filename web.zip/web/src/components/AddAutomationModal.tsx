import { useEffect, useRef, useState, type KeyboardEvent, type ReactNode } from "react";
import { api, type AutomationPayload } from "../api";
import type { AutomationMeta, WorkspaceMeta } from "../types";

interface Props {
  editing: AutomationMeta | null;
  initial: { name?: string; prompt?: string } | null;
  onClose: () => void;
  onSaved: () => void;
}

const TIER_OPTIONS = [
  { value: "balanced", label: "均衡" },
  { value: "fast", label: "快速" },
  { value: "precision", label: "精准" },
];

const FREQ_OPTIONS = [
  { value: "once", label: "单次" },
  { value: "daily", label: "每天" },
  { value: "weekly", label: "每周" },
];

const VALIDITY_OPTIONS = [
  { value: "permanent", label: "长期有效" },
  { value: "until", label: "截止日期" },
];

const ACCESS_OPTIONS = [
  { value: "full", label: "允许完全访问" },
  { value: "restricted", label: "仅工作区内访问" },
];

const WEEKDAYS = ["周一", "周二", "周三", "周四", "周五", "周六", "周日"];

const VARIABLES = [
  { token: "{{current_date}}", label: "当前日期" },
  { token: "{{workspace_files}}", label: "工作区文件列表" },
  { token: "{{task_name}}", label: "任务名称" },
];

/* ── 图标 ── */

function XIcon() {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor"
      strokeWidth={2} strokeLinecap="round" aria-hidden>
      <line x1="6" y1="6" x2="18" y2="18" />
      <line x1="18" y1="6" x2="6" y2="18" />
    </svg>
  );
}

function ChevronDownIcon() {
  return (
    <svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor"
      strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <polyline points="6 9 12 15 18 9" />
    </svg>
  );
}

function PlusIcon() {
  return (
    <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor"
      strokeWidth={2} strokeLinecap="round" aria-hidden>
      <line x1="12" y1="5" x2="12" y2="19" />
      <line x1="5" y1="12" x2="19" y2="12" />
    </svg>
  );
}

function CheckCircleIcon() {
  return (
    <svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor"
      strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
      <polyline points="22 4 12 14.01 9 11.01" />
    </svg>
  );
}

function FolderIcon() {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor"
      strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z" />
    </svg>
  );
}

function AlertIcon() {
  return (
    <svg viewBox="0 0 24 24" width="17" height="17" fill="none" stroke="currentColor"
      strokeWidth={1.9} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <circle cx="12" cy="12" r="10" />
      <line x1="12" y1="8" x2="12" y2="12" />
      <line x1="12" y1="16" x2="12.01" y2="16" />
    </svg>
  );
}

function InfoIcon() {
  return (
    <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor"
      strokeWidth={1.8} strokeLinecap="round" aria-hidden>
      <circle cx="12" cy="12" r="10" />
      <line x1="12" y1="16" x2="12" y2="12" />
      <line x1="12" y1="8" x2="12.01" y2="8" />
    </svg>
  );
}

/* ── 通用下拉 ── */

interface DDOption {
  value: string;
  label: string;
}

function Dropdown({
  options,
  value,
  onChange,
  icon,
  className = "",
  align = "left",
  ariaLabel,
}: {
  options: DDOption[];
  value: string;
  onChange: (v: string) => void;
  icon?: ReactNode;
  className?: string;
  align?: "left" | "right";
  ariaLabel?: string;
}) {
  const [open, setOpen] = useState(false);
  const current = options.find((o) => o.value === value);
  return (
    <div className={`au-dd-wrap ${className}`}>
      <button
        type="button"
        className="au-dd"
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-label={ariaLabel}
        onClick={() => setOpen((v) => !v)}
      >
        {icon}
        <span className="au-dd-label">{current?.label ?? ""}</span>
        <ChevronDownIcon />
      </button>
      {open && (
        <>
          <div className="au-popover-mask" onClick={() => setOpen(false)} />
          <div className={`au-popover ${align === "right" ? "au-popover-right" : ""}`} role="listbox">
            {options.map((o) => (
              <button
                key={o.value}
                type="button"
                role="option"
                aria-selected={o.value === value}
                className={`au-pop-item${o.value === value ? " checked" : ""}`}
                onClick={() => {
                  onChange(o.value);
                  setOpen(false);
                }}
              >
                {o.label}
                {o.value === value && <span className="au-pop-tick">✓</span>}
              </button>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

function defaultOnceAt(): string {
  const d = new Date(Date.now() + 60 * 60 * 1000);
  d.setMinutes(5, 0, 0);
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}T${p(d.getHours())}:${p(
    d.getMinutes()
  )}`;
}

function defaultUntilDate(): string {
  const d = new Date(Date.now() + 90 * 24 * 60 * 60 * 1000);
  const p = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
}

export default function AddAutomationModal({ editing, initial, onClose, onSaved }: Props) {
  const [name, setName] = useState("");
  const [prompt, setPrompt] = useState("");
  const [tier, setTier] = useState("balanced");
  const [workspaces, setWorkspaces] = useState<WorkspaceMeta[]>([]);
  const [workspaceId, setWorkspaceId] = useState("");
  const [access, setAccess] = useState("full");
  const [freqType, setFreqType] = useState("once");
  const [onceAt, setOnceAt] = useState(defaultOnceAt());
  const [dailyTime, setDailyTime] = useState("09:00");
  const [weekday, setWeekday] = useState(() => String(new Date().getDay() === 0 ? 6 : new Date().getDay() - 1));
  const [validityType, setValidityType] = useState("permanent");
  const [untilDate, setUntilDate] = useState(defaultUntilDate());
  const [pushWechat, setPushWechat] = useState(false);
  const [pushWecom, setPushWecom] = useState(false);
  const [varMenu, setVarMenu] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    api
      .listWorkspaces()
      .then((d) => setWorkspaces(d.workspaces))
      .catch(() => undefined);
    if (editing) {
      setName(editing.name);
      setPrompt(editing.prompt);
      setTier(editing.model_tier);
      setWorkspaceId(editing.workspace_id || "");
      setAccess(editing.access);
      const s = editing.schedule;
      setFreqType(s.type);
      if (s.type === "once") setOnceAt((s.run_at || "").slice(0, 16));
      if (s.type !== "once") {
        setDailyTime(s.time || "09:00");
        if (s.type === "weekly") setWeekday(String(s.weekday ?? 0));
      }
      setValidityType(editing.validity.type);
      if (editing.validity.type === "until" && editing.validity.end) {
        setUntilDate(editing.validity.end);
      }
      setPushWechat(editing.push_wechat);
      setPushWecom(editing.push_wecom);
    } else if (initial) {
      setName(initial.name || "");
      setPrompt(initial.prompt || "");
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const insertVariable = (token: string) => {
    setVarMenu(false);
    const el = textareaRef.current;
    if (!el) {
      setPrompt((p) => `${p}${token}`);
      return;
    }
    const start = el.selectionStart ?? prompt.length;
    const end = el.selectionEnd ?? prompt.length;
    const next = prompt.slice(0, start) + token + prompt.slice(end);
    setPrompt(next);
    requestAnimationFrame(() => {
      el.focus();
      const pos = start + token.length;
      el.setSelectionRange(pos, pos);
    });
  };

  const validate = (): string | null => {
    if (!name.trim()) return "请填写任务名称";
    if (!prompt.trim()) return "请填写提示词";
    if (freqType === "once" && !onceAt) return "请选择单次执行时间";
    if (freqType !== "once" && !dailyTime) return "请选择执行时间";
    if (validityType === "until" && !untilDate) return "请选择有效期截止日期";
    return null;
  };

  const submit = async () => {
    if (submitting) return;
    const err = validate();
    if (err) {
      setError(err);
      return;
    }
    setError(null);
    setSubmitting(true);
    const ws = workspaces.find((w) => w.id === workspaceId);
    const payload: AutomationPayload = {
      name: name.trim(),
      prompt: prompt.trim(),
      model_tier: tier,
      workspace_id: workspaceId,
      workspace_name: ws?.name || "",
      access,
      schedule:
        freqType === "once"
          ? { type: "once", run_at: onceAt, time: null, weekday: null }
          : freqType === "daily"
            ? { type: "daily", run_at: null, time: dailyTime, weekday: null }
            : { type: "weekly", run_at: null, time: dailyTime, weekday: Number(weekday) },
      validity:
        validityType === "permanent"
          ? { type: "permanent", end: null }
          : { type: "until", end: untilDate },
      push_wechat: pushWechat,
      push_wecom: pushWecom,
      status: editing ? editing.status : "active",
    };
    try {
      if (editing) {
        await api.updateAutomation(editing.id, payload);
      } else {
        await api.createAutomation(payload);
      }
      onSaved();
    } catch (e) {
      setError(e instanceof Error ? e.message : "保存失败，请重试");
    } finally {
      setSubmitting(false);
    }
  };

  const onKeyDown = (e: KeyboardEvent) => {
    if (e.key === "Enter" && (e.target as HTMLElement).tagName === "INPUT") {
      e.preventDefault();
      void submit();
    }
  };

  const wsOptions: DDOption[] = [
    { value: "", label: "选择工作空间" },
    ...workspaces.map((w) => ({ value: w.id, label: w.name })),
  ];

  return (
    <div className="lib-modal-mask" onClick={() => !submitting && onClose()}>
      <div
        className="lib-modal au-modal"
        onClick={(e) => e.stopPropagation()}
        onKeyDown={onKeyDown}
      >
        <div className="au-modal-head">
          <span className="au-modal-title">{editing ? "编辑自动化任务" : "添加自动化任务"}</span>
          <button
            type="button"
            className="sb-icon-btn"
            onClick={onClose}
            title="关闭"
            aria-label="关闭"
            disabled={submitting}
          >
            <XIcon />
          </button>
        </div>

        <label className="field au-field">
          <span>名称</span>
          <input
            value={name}
            autoFocus
            onChange={(e) => setName(e.target.value)}
            placeholder="输入任务名称"
            maxLength={80}
          />
        </label>

        <div className="field au-field">
          <span>提示词</span>
          <div className="au-prompt-card">
            <textarea
              ref={textareaRef}
              value={prompt}
              onChange={(e) => setPrompt(e.target.value)}
              placeholder="添加提示词"
              rows={5}
              className="au-prompt-input"
            />
            <div className="au-prompt-bar">
              <div className="au-dd-wrap">
                <button
                  type="button"
                  className="au-plus-btn"
                  title="插入变量"
                  aria-label="插入变量"
                  onClick={() => setVarMenu((v) => !v)}
                >
                  <PlusIcon />
                </button>
                {varMenu && (
                  <>
                    <div className="au-popover-mask" onClick={() => setVarMenu(false)} />
                    <div className="au-popover">
                      {VARIABLES.map((v) => (
                        <button
                          key={v.token}
                          type="button"
                          className="au-pop-item"
                          onClick={() => insertVariable(v.token)}
                        >
                          <span className="au-var-label">{v.label}</span>
                          <code className="au-var-token">{v.token}</code>
                        </button>
                      ))}
                    </div>
                  </>
                )}
              </div>
              <Dropdown
                options={TIER_OPTIONS}
                value={tier}
                onChange={setTier}
                icon={<CheckCircleIcon />}
                align="right"
                ariaLabel="模型档位"
                className="au-tier-dd"
              />
            </div>
            <div className="au-prompt-strip">
              <Dropdown
                options={wsOptions}
                value={workspaceId}
                onChange={setWorkspaceId}
                icon={<FolderIcon />}
                ariaLabel="选择工作空间"
              />
              <Dropdown
                options={ACCESS_OPTIONS}
                value={access}
                onChange={setAccess}
                icon={<AlertIcon />}
                className={access === "full" ? "au-dd-danger" : ""}
                ariaLabel="访问权限"
              />
            </div>
          </div>
        </div>

        <div className="au-form-row">
          <div className="au-form-item">
            <span className="au-form-label">执行频率：</span>
            <Dropdown options={FREQ_OPTIONS} value={freqType} onChange={setFreqType} ariaLabel="执行频率" />
            {freqType === "once" && (
              <input
                type="datetime-local"
                className="au-native-input"
                value={onceAt}
                onChange={(e) => setOnceAt(e.target.value)}
                aria-label="执行时间"
              />
            )}
            {freqType === "daily" && (
              <input
                type="time"
                className="au-native-input au-time-input"
                value={dailyTime}
                onChange={(e) => setDailyTime(e.target.value)}
                aria-label="每日执行时间"
              />
            )}
            {freqType === "weekly" && (
              <>
                <select
                  className="au-native-input"
                  value={weekday}
                  onChange={(e) => setWeekday(e.target.value)}
                  aria-label="星期"
                >
                  {WEEKDAYS.map((w, i) => (
                    <option key={w} value={i}>
                      {w}
                    </option>
                  ))}
                </select>
                <input
                  type="time"
                  className="au-native-input au-time-input"
                  value={dailyTime}
                  onChange={(e) => setDailyTime(e.target.value)}
                  aria-label="执行时间"
                />
              </>
            )}
          </div>
          <div className="au-form-item">
            <span className="au-form-label">有效期：</span>
            <Dropdown
              options={VALIDITY_OPTIONS}
              value={validityType}
              onChange={setValidityType}
              ariaLabel="有效期"
            />
            {validityType === "until" && (
              <input
                type="date"
                className="au-native-input"
                value={untilDate}
                onChange={(e) => setUntilDate(e.target.value)}
                aria-label="截止日期"
              />
            )}
          </div>
        </div>

        <div className="au-push-row">
          <label className="au-push-item">
            <span className="au-push-text">
              推送到 WorkBuddy 微信小程序
              <span className="au-info" title="推送渠道需在服务端配置 Webhook 后生效，当前版本仅保存偏好">
                <InfoIcon />
              </span>
            </span>
            <button
              type="button"
              role="switch"
              aria-checked={pushWechat}
              aria-label="推送到 WorkBuddy 微信小程序"
              className={`au-switch${pushWechat ? " on" : ""}`}
              onClick={() => setPushWechat((v) => !v)}
            >
              <span className="au-switch-knob" />
            </button>
          </label>
          <label className="au-push-item">
            <span className="au-push-text">
              推送到企业微信 bot
              <span className="au-info" title="推送渠道需在服务端配置 Webhook 后生效，当前版本仅保存偏好">
                <InfoIcon />
              </span>
            </span>
            <button
              type="button"
              role="switch"
              aria-checked={pushWecom}
              aria-label="推送到企业微信 bot"
              className={`au-switch${pushWecom ? " on" : ""}`}
              onClick={() => setPushWecom((v) => !v)}
            >
              <span className="au-switch-knob" />
            </button>
          </label>
        </div>

        {error && <div className="apm-msg apm-msg-error">{error}</div>}

        <div className="au-modal-foot">
          <button type="button" className="au-btn-cancel" onClick={onClose} disabled={submitting}>
            取消
          </button>
          <button type="button" className="au-btn-confirm" onClick={submit} disabled={submitting}>
            {submitting ? "处理中…" : "确定"}
          </button>
        </div>
      </div>
    </div>
  );
}
