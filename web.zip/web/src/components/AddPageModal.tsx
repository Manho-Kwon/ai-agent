import { useRef, useState, type KeyboardEvent, type ReactElement } from "react";
import { api } from "../api";
import type { PageMeta } from "../types";

type Tab = "upload" | "path" | "url" | "import" | "folder";

interface Props {
  /** 当前所在文件夹 id（根目录为空串），新建条目会挂到该目录下 */
  parentId: string;
  parentName: string;
  onClose: () => void;
  onCreated: (page: PageMeta) => void;
}

/* 文本类扩展名：前端直接读文本，内容入库；其余按二进制 base64 上传 */
const TEXT_EXTS = [
  ".html", ".htm", ".jsx", ".tsx", ".js", ".mjs", ".ts", ".md", ".markdown",
  ".css", ".json", ".xml", ".csv", ".txt", ".svg", ".log", ".yaml", ".yml",
];
const ACCEPT_ATTR =
  ".html,.htm,.jsx,.tsx,.js,.mjs,.ts,.md,.markdown,.css,.json,.xml,.csv,.txt,.svg,.log,.yaml,.yml,.png,.jpg,.jpeg,.gif,.webp,.ico,.bmp,.avif,.zip";
const MAX_BYTES = 15 * 1024 * 1024;

function extOf(name: string): string {
  const i = name.lastIndexOf(".");
  return i >= 0 ? name.slice(i).toLowerCase() : "";
}

function bytesToBase64(buf: ArrayBuffer): string {
  const bytes = new Uint8Array(buf);
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

function fmtSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 / 1024).toFixed(1)} MB`;
}

function isValidHttpUrl(s: string): boolean {
  try {
    const u = new URL(s);
    return u.protocol === "http:" || u.protocol === "https:";
  } catch {
    return false;
  }
}

/* ── 图标（线性风格，与全站一致） ── */
function UploadIcon() {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor"
      strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M12 16V4" />
      <polyline points="7 9 12 4 17 9" />
      <path d="M4 17v2a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2v-2" />
    </svg>
  );
}

function PathIcon() {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor"
      strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
    </svg>
  );
}

function GlobeIcon() {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor"
      strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <circle cx="12" cy="12" r="9" />
      <path d="M3 12h18" />
      <path d="M12 3a14 14 0 0 1 0 18 14 14 0 0 1 0-18z" />
    </svg>
  );
}

function DownloadIcon() {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor"
      strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M12 4v12" />
      <polyline points="7 11 12 16 17 11" />
      <path d="M4 19h16" />
    </svg>
  );
}

function FolderPlusIcon() {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor"
      strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z" />
      <line x1="12" y1="10" x2="12" y2="15" />
      <line x1="9.5" y1="12.5" x2="14.5" y2="12.5" />
    </svg>
  );
}

function XIcon() {
  return (
    <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor"
      strokeWidth={2} strokeLinecap="round" aria-hidden>
      <line x1="6" y1="6" x2="18" y2="18" />
      <line x1="18" y1="6" x2="6" y2="18" />
    </svg>
  );
}

function CheckIcon() {
  return (
    <svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor"
      strokeWidth={2.2} strokeLinecap="round" strokeLinejoin="round" aria-hidden>
      <polyline points="4 12.5 9.5 18 20 6.5" />
    </svg>
  );
}

const TABS: { key: Tab; label: string; icon: () => ReactElement }[] = [
  { key: "upload", label: "上传", icon: UploadIcon },
  { key: "path", label: "路径", icon: PathIcon },
  { key: "url", label: "URL", icon: GlobeIcon },
  { key: "import", label: "导入", icon: DownloadIcon },
  { key: "folder", label: "文件夹", icon: FolderPlusIcon },
];

const SUBMIT_LABEL: Record<Tab, string> = {
  upload: "上传并注册",
  path: "导入并注册",
  url: "添加书签",
  import: "导入托管页面",
  folder: "创建文件夹",
};

export default function AddPageModal({ parentId, parentName, onClose, onCreated }: Props) {
  const [tab, setTab] = useState<Tab>("upload");
  const [name, setName] = useState("");
  const [desc, setDesc] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [dragOver, setDragOver] = useState(false);
  const [pathVal, setPathVal] = useState("");
  const [urlVal, setUrlVal] = useState("");
  const [hostedUrl, setHostedUrl] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const switchTab = (t: Tab) => {
    setTab(t);
    setError(null);
  };

  const pickFile = (f: File | null | undefined) => {
    setError(null);
    if (!f) return;
    const ext = extOf(f.name);
    const allowed = new Set([...TEXT_EXTS, ".png", ".jpg", ".jpeg", ".gif",
      ".webp", ".ico", ".bmp", ".avif", ".zip"]);
    if (ext && !allowed.has(ext)) {
      setError(`不支持的文件类型：${ext || "无扩展名"}`);
      return;
    }
    if (f.size > MAX_BYTES) {
      setError(`文件超过 15 MB 上限（实际 ${fmtSize(f.size)}）`);
      return;
    }
    setFile(f);
  };

  /** 各 Tab 的输入校验；返回错误信息，null = 通过 */
  const validate = (): string | null => {
    if (tab === "folder" && !name.trim()) return "请填写文件夹名称";
    if (tab === "upload") {
      if (!file) return "请先选择要上传的文件";
    }
    if (tab === "path") {
      if (!pathVal.trim()) return "请输入本地文件的绝对路径";
    }
    if (tab === "url") {
      if (!urlVal.trim()) return "请输入 URL";
      if (!isValidHttpUrl(urlVal.trim())) return "URL 格式不正确，需以 http:// 或 https:// 开头";
    }
    if (tab === "import") {
      if (!hostedUrl.trim()) return "请输入托管页面 URL";
      if (!isValidHttpUrl(hostedUrl.trim()))
        return "URL 格式不正确，需以 http:// 或 https:// 开头";
    }
    return null;
  };

  const submit = async () => {
    if (submitting || done) return;
    const err = validate();
    if (err) {
      setError(err);
      return;
    }
    setError(null);
    setSubmitting(true);
    try {
      let page: PageMeta;
      if (tab === "folder") {
        page = await api.addPageEntry({
          kind: "folder", title: name.trim(), description: desc.trim(), parent_id: parentId,
        });
      } else if (tab === "url") {
        page = await api.addPageEntry({
          kind: "bookmark", url: urlVal.trim(),
          title: name.trim(), description: desc.trim(), parent_id: parentId,
        });
      } else if (tab === "import") {
        page = await api.importPageHosted({
          url: hostedUrl.trim(),
          title: name.trim(), description: desc.trim(), parent_id: parentId,
        });
      } else if (tab === "path") {
        page = await api.importPagePath({
          path: pathVal.trim(),
          title: name.trim(), description: desc.trim(), parent_id: parentId,
        });
      } else {
        // upload
        const f = file as File;
        const fileName = f.name;
        if (TEXT_EXTS.includes(extOf(fileName))) {
          const text = await f.text();
          page = await api.uploadPage({
            file_name: fileName, textContent: text,
            title: name.trim(), description: desc.trim(), parent_id: parentId,
          });
        } else {
          const buf = await f.arrayBuffer();
          page = await api.uploadPage({
            file_name: fileName, contentB64: bytesToBase64(buf),
            title: name.trim(), description: desc.trim(), parent_id: parentId,
          });
        }
      }
      setDone(true);
      // 成功反馈展示片刻后关闭并刷新列表
      setTimeout(() => onCreated(page), 700);
    } catch (e) {
      setError(e instanceof Error ? e.message : "操作失败，请重试");
    } finally {
      setSubmitting(false);
    }
  };

  const onKeyDown = (e: KeyboardEvent) => {
    if (e.key === "Enter" && (e.target as HTMLElement).tagName !== "TEXTAREA") {
      e.preventDefault();
      void submit();
    }
  };

  return (
    <div className="lib-modal-mask" onClick={() => !submitting && onClose()}>
      <div
        className="lib-modal apm-modal"
        onClick={(e) => e.stopPropagation()}
        onKeyDown={onKeyDown}
      >
        <div className="lib-modal-head">
          <div>
            <div className="apm-title">添加页面</div>
            <div className="apm-subtitle">
              添加网页文件、URL 书签或文件夹{parentName ? ` · 保存到「${parentName}」` : ""}
            </div>
          </div>
          <button
            className="sb-icon-btn"
            onClick={onClose}
            title="取消"
            type="button"
            disabled={submitting}
            aria-label="关闭"
          >
            <XIcon />
          </button>
        </div>

        <label className="field">
          <span>名称</span>
          <input
            value={name}
            autoFocus
            onChange={(e) => setName(e.target.value)}
            placeholder="页面或文件夹名称"
          />
        </label>
        <label className="field">
          <span>说明（可选）</span>
          <input
            value={desc}
            onChange={(e) => setDesc(e.target.value)}
            placeholder="简要说明"
          />
        </label>

        <div className="apm-tabs" role="tablist">
          {TABS.map((t) => {
            const Icon = t.icon;
            return (
              <button
                key={t.key}
                type="button"
                role="tab"
                aria-selected={tab === t.key}
                className={`apm-tab${tab === t.key ? " active" : ""}`}
                onClick={() => switchTab(t.key)}
              >
                <Icon />
                <span>{t.label}</span>
              </button>
            );
          })}
        </div>

        <div className="apm-body">
          {tab === "upload" && (
            <>
              <div
                className={`apm-dropzone${dragOver ? " drag" : ""}`}
                onClick={() => fileInputRef.current?.click()}
                onDragOver={(e) => {
                  e.preventDefault();
                  setDragOver(true);
                }}
                onDragLeave={() => setDragOver(false)}
                onDrop={(e) => {
                  e.preventDefault();
                  setDragOver(false);
                  pickFile(e.dataTransfer.files?.[0]);
                }}
                role="button"
                tabIndex={0}
              >
                {file ? (
                  <div className="apm-file-card" onClick={(e) => e.stopPropagation()}>
                    <span className="apm-file-name">{file.name}</span>
                    <span className="apm-file-size">{fmtSize(file.size)}</span>
                    <button
                      type="button"
                      className="apm-file-clear"
                      title="移除文件"
                      onClick={() => setFile(null)}
                    >
                      <XIcon />
                    </button>
                  </div>
                ) : (
                  <>
                    <span className="apm-dz-icon">
                      <UploadIcon />
                    </span>
                    <div className="apm-dz-main">点击选择网页文件，或将文件拖拽到此处</div>
                    <div className="apm-dz-hint">
                      （.html、.jsx、.tsx、.js、.ts、.md、.css、.json、.xml、.csv、.txt、.svg、图片、.zip）
                    </div>
                  </>
                )}
                <input
                  ref={fileInputRef}
                  type="file"
                  accept={ACCEPT_ATTR}
                  hidden
                  onChange={(e) => {
                    pickFile(e.target.files?.[0]);
                    e.target.value = "";
                  }}
                />
              </div>
              <div className="apm-hint">文本类文件内容直接入库可在线查看；图片与 .zip 会上传托管，zip 自动解压。</div>
            </>
          )}

          {tab === "path" && (
            <>
              <label className="field">
                <span>本地文件路径</span>
                <input
                  value={pathVal}
                  onChange={(e) => setPathVal(e.target.value)}
                  placeholder="例如 C:\Users\you\docs\report.html"
                />
              </label>
              <div className="apm-hint">请输入服务器计算机上网页文件的绝对路径。文本类文件内容直接入库，二进制文件自动拷贝托管。</div>
            </>
          )}

          {tab === "url" && (
            <>
              <label className="field">
                <span>URL</span>
                <input
                  value={urlVal}
                  onChange={(e) => setUrlVal(e.target.value)}
                  placeholder="https://example.com 或 http://192.168.1.x:4821/hosted/abc"
                />
              </label>
              <div className="apm-hint">请输入外部 URL，或同一网络中其他 Agent 托管的页面 URL。名称留空时自动使用域名。</div>
            </>
          )}

          {tab === "import" && (
            <>
              <label className="field">
                <span>托管页面 URL</span>
                <input
                  value={hostedUrl}
                  onChange={(e) => setHostedUrl(e.target.value)}
                  placeholder="http://192.168.1.x:4821/hosted/abc12345"
                />
              </label>
              <div className="apm-hint">
                请输入同一网络中其他 Agent 托管的页面 URL。页面直接从源服务器加载，因此 HTML、JavaScript、CSS
                和其他文件都能正常工作，托管方的更改会立即显示。提交时会自动验证连通性。
              </div>
            </>
          )}

          {tab === "folder" && (
            <div className="apm-hint apm-folder-hint">
              创建文件夹来整理页面。文件夹可以嵌套，删除文件夹会一并删除其中的内容。
              {parentName ? `新文件夹将创建在「${parentName}」内。` : "新文件夹将创建在根目录。"}
            </div>
          )}
        </div>

        {error && <div className="apm-msg apm-msg-error">{error}</div>}
        {done && (
          <div className="apm-msg apm-msg-ok">
            <CheckIcon />
            添加成功
          </div>
        )}

        <button
          type="button"
          className="apm-submit"
          onClick={submit}
          disabled={submitting || done}
        >
          {submitting ? (
            <span className="apm-spinner" aria-hidden />
          ) : tab === "folder" ? (
            <FolderPlusIcon />
          ) : tab === "upload" ? (
            <UploadIcon />
          ) : tab === "import" ? (
            <DownloadIcon />
          ) : tab === "path" ? (
            <PathIcon />
          ) : (
            <GlobeIcon />
          )}
          <span>{submitting ? "处理中…" : done ? "已添加" : SUBMIT_LABEL[tab]}</span>
        </button>
      </div>
    </div>
  );
}
