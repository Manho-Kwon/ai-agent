import { useState } from "react";
import { api } from "../api";
import type { McpServer } from "../types";

/* 技能目录：后端暂无技能管理，先以本地演示条目展示 */
const SKILLS = [
  {
    name: "excel-sheet-analyzer",
    desc: "Excel 파일의 특정 시트를 분석하고 다차원 통계를...",
  },
];

interface Props {
  servers: McpServer[];
  onReload: () => void;
  onClose: () => void;
}

export default function ToolPanel({ servers, onReload, onClose }: Props) {
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});
  const [skillOn, setSkillOn] = useState<Record<string, boolean>>(
    Object.fromEntries(SKILLS.map((s) => [s.name, true]))
  );
  const [busy, setBusy] = useState<string | null>(null);

  const toolCount = servers.reduce((n, s) => n + s.tools.length, 0);

  const toggleServer = async (name: string, enabled: boolean) => {
    setBusy(name);
    try {
      await api.setMcpEnabled(name, enabled);
      onReload();
    } catch {
      onReload();
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="tp-wrap">
      <div className="tp-head">
        <span className="tp-title">工具与技能</span>
        <button className="tp-close" onClick={onClose} title="收起" type="button">
          ✕
        </button>
      </div>
      <div className="tp-stats">
        <span>
          {servers.length} 个服务器 / {toolCount} 个工具 / {SKILLS.length} 个技能
        </span>
        <button className="tp-refresh" onClick={onReload} title="刷新状态" type="button">
          <RefreshIcon />
        </button>
      </div>

      <div className="tp-list">
        {servers.length === 0 && (
          <div className="panel-empty">data/mcp.json 中暂无服务器</div>
        )}
        {servers.map((s) => {
          const open = !!expanded[s.name];
          const dotCls =
            s.status === "connected"
              ? "dot-green"
              : s.status === "connecting"
                ? "dot-amber"
                : s.status === "error"
                  ? "dot-red"
                  : "dot-gray";
          return (
            <div key={s.name} className="tp-card">
              <div
                className="tp-card-main"
                onClick={() =>
                  setExpanded((p) => ({ ...p, [s.name]: !p[s.name] }))
                }
              >
                <span className={`status-dot ${dotCls}`} />
                <div className="tp-card-info">
                  <div className="tp-card-name">{s.name}</div>
                  <div className="tp-card-sub">
                    {s.transport} · {s.tools.length} 个工具
                  </div>
                </div>
                <span className={`tp-chevron ${open ? "open" : ""}`}>›</span>
                <Toggle
                  on={s.enabled}
                  disabled={busy === s.name}
                  onClick={() => toggleServer(s.name, !s.enabled)}
                />
              </div>
              {s.error && <div className="server-error">{s.error}</div>}
              {open && (
                <div className="tp-tools">
                  {s.tools.length === 0 && (
                    <div className="panel-empty">（无工具）</div>
                  )}
                  {s.tools.map((t) => (
                    <div key={t.name} className="tp-tool" title={t.description}>
                      {t.short_name}
                    </div>
                  ))}
                </div>
              )}
            </div>
          );
        })}
      </div>

      <div className="tp-skill-label">
        <GridIcon />
        <span>智能体技能</span>
      </div>
      <div className="tp-list">
        {SKILLS.map((k) => (
          <div key={k.name} className="tp-card">
            <div className="tp-card-main">
              <span className="status-dot dot-green" />
              <div className="tp-card-info">
                <div className="tp-card-name">{k.name}</div>
                <div className="tp-skill-desc">{k.desc}</div>
              </div>
              <Toggle
                on={!!skillOn[k.name]}
                onClick={() =>
                  setSkillOn((p) => ({ ...p, [k.name]: !p[k.name] }))
                }
              />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function Toggle({
  on,
  onClick,
  disabled,
}: {
  on: boolean;
  onClick: () => void;
  disabled?: boolean;
}) {
  return (
    <button
      className={`toggle ${on ? "on" : ""}`}
      onClick={(e) => {
        e.stopPropagation();
        onClick();
      }}
      disabled={disabled}
      type="button"
      role="switch"
      aria-checked={on}
    >
      <span className="toggle-knob" />
    </button>
  );
}

function RefreshIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="14"
      height="14"
      fill="none"
      stroke="currentColor"
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <path d="M21 12a9 9 0 1 1-2.64-6.36" />
      <path d="M21 3v6h-6" />
    </svg>
  );
}

function GridIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      width="13"
      height="13"
      fill="none"
      stroke="currentColor"
      strokeWidth={2}
      strokeLinecap="round"
      aria-hidden
    >
      <path d="M9 3.5H5.5A2 2 0 0 0 3.5 5.5V9M15 3.5h3.5a2 2 0 0 1 2 2V9M9 20.5H5.5a2 2 0 0 1-2-2V15M15 20.5h3.5a2 2 0 0 0 2-2V15" />
    </svg>
  );
}
