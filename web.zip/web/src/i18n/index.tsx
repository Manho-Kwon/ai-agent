import {
  createContext,
  useCallback,
  useContext,
  useMemo,
  type ReactNode,
} from "react";
import { zh } from "./zh";
import { ko } from "./ko";
import { en } from "./en";

export type Lang = "zh" | "ko" | "en";

/** 语言下拉选项：显示各语言母语名，value 为后端 settings.ui.language 存值 */
export const LANGS: { code: Lang; label: string }[] = [
  { code: "zh", label: "中文" },
  { code: "ko", label: "한국어" },
  { code: "en", label: "English" },
];

type Dict = Record<string, string>;
const DICTS: Record<Lang, Dict> = { zh, ko, en };

export function isLang(v: unknown): v is Lang {
  return v === "zh" || v === "ko" || v === "en";
}

interface I18nValue {
  lang: Lang;
  setLang: (l: Lang) => void;
  /** 取文案；缺失时回退 zh，再回退 key 本身。vars 用于 {name} 占位插值 */
  t: (key: string, vars?: Record<string, string | number>) => string;
}

const I18nContext = createContext<I18nValue | null>(null);

function interpolate(
  s: string,
  vars?: Record<string, string | number>
): string {
  if (!vars) return s;
  let out = s;
  for (const k of Object.keys(vars)) {
    out = out.split(`{${k}}`).join(String(vars[k]));
  }
  return out;
}

export function I18nProvider({
  lang,
  onLangChange,
  children,
}: {
  lang: Lang;
  onLangChange: (l: Lang) => void;
  children: ReactNode;
}) {
  const t = useCallback(
    (key: string, vars?: Record<string, string | number>) => {
      const dict = DICTS[lang] || zh;
      const raw = dict[key] ?? zh[key] ?? key;
      return interpolate(raw, vars);
    },
    [lang]
  );
  const value = useMemo<I18nValue>(
    () => ({ lang, setLang: onLangChange, t }),
    [lang, onLangChange, t]
  );
  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n(): I18nValue {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error("useI18n 必须在 I18nProvider 内使用");
  return ctx;
}
