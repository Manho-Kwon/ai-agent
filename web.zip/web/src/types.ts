export interface SessionMeta {
  id: string;
  title: string;
  created_at: string;
  updated_at: string;
  message_count: number;
  preview: string;
}

export interface ToolTrace {
  id: string;
  server: string;
  tool: string;
  arguments?: Record<string, unknown>;
  content?: string;
  /** 工具是否报错；老消息无此字段 */
  is_error?: boolean;
  /** 工具执行耗时（毫秒）；被拒绝的调用为 0 */
  ms?: number;
}

/** 聊天附件元数据（与后端 app/attachments.py 的 meta 对应） */
export interface Attachment {
  id: string;
  name: string;
  ext: string;
  kind: "text" | "pdf" | "docx" | "xlsx" | "pptx" | "image";
  size: number;
  status: "ready" | "parse_failed" | "image";
  chars?: number;
  error?: string;
  url?: string;
}

export interface Message {
  id?: string;
  role: "user" | "assistant";
  content: string;
  tool_trace?: ToolTrace[];
  attachments?: Attachment[];
  timestamp?: string;
  /** 思考链路快照，仅 assistant 消息有；改动前的老消息没有该字段 */
  meta?: MessageMeta;
}

export interface McpTool {
  name: string;
  short_name: string;
  description: string;
}

export interface McpServer {
  name: string;
  transport: string;
  command?: string | null;
  args?: string[];
  enabled: boolean;
  status: string;
  error?: string | null;
  connected_at?: string | null;
  tools: McpTool[];
}

/** 设置 → 智能体技能：技能卡信息 */
export interface SkillInfo {
  name: string;
  description: string;
  enabled: boolean;
  scripts: number;
  references: number;
}

/** 设置 → 工作区检索：检索策略状态 */
export interface RetrievalStatus {
  mode: string;
  gate: string;
  documents: number;
  paragraphs: number;
  effective: { k: number; evidence: number; small_corpus: boolean };
  dense: { enabled: boolean; reason: string };
  reranker: { enabled: boolean; reason: string };
  compile: { timeout_s: number; samples: number };
  deep_read: string;
}

/** 设置 → LLM 配置 → 管理模型连接：提供商状态 */
export type ConnStatus =
  | "disconnected"
  | "unverified"
  | "connected"
  | "error"
  | "checking";

/** 自定义 / 自托管模型条目（= config.json providers 中的命名 provider） */
export interface ConnCustomModel {
  id: string;
  label: string;
  model: string;
  base_url: string;
  status: ConnStatus;
  status_text: string;
  last_checked: string | null;
  error: string | null;
  /** 正在使用该模型的角色中文名列表 */
  in_use: string[];
}

/** 模型连接弹窗中的提供商（内置密钥型 + 自定义聚合项） */
export interface ConnProvider {
  key: string;
  title: string;
  kind: "builtin" | "custom";
  status: ConnStatus;
  status_text: string;
  /** 内置：密钥环境变量名 */
  env?: string;
  key_set?: boolean;
  last_checked: string | null;
  error?: string | null;
  note?: string | null;
  /** 自定义聚合项 */
  subtitle?: string;
  connected_count?: number;
  total_count?: number;
  models?: ConnCustomModel[];
}

export interface ConnectionsState {
  providers: ConnProvider[];
  last_checked: string | null;
  /** 模型分配面包屑用的角色中文名（固定顺序） */
  role_order: string[];
}

/** 外观设置（设置 → 主题与外观），持久化于 config.json ui.appearance */
export interface Appearance {
  mode: "light" | "dark";
  tone: "default" | "warm" | "cool";
  /** 靛蓝 / 琥珀 / 蓝色 / 祖母绿 / 紫罗兰 / 玫瑰 / 青色 */
  accent: string;
  /** 85 - 150（百分比） */
  font_scale: number;
  glow: boolean;
  chat_bg_kind: "none" | "custom";
  /** dataURL */
  chat_bg: string;
}

export interface UIConfig {
  title: string;
  subtitle?: string;
  prompt_rules?: string[];
  user_name?: string;
  user_avatar?: string;
  bot_name?: string;
  bot_avatar?: string;
  executor_instructions?: string;
  appearance?: Partial<Appearance>;
}

export interface Settings {
  ui: UIConfig;
  llm: {
    base_url: string;
    model: string;
    temperature: number;
    max_tokens: number;
    max_tool_rounds: number;
    api_key_set: boolean;
  };
  roles: Record<string, { base_url: string; model: string; provider: string }>;
  workflow: { mode: string };
  runtime: { allow_export: boolean };
  yolo_mode: boolean;
  evaluator: { enabled: boolean; max_rework: number };
  memory?: { enabled: boolean; auto_extract: boolean };
}

/** 设置 → LLM 配置 保存请求体 */
export interface SettingsPut {
  base_url?: string;
  model?: string;
  temperature?: number;
  max_tokens?: number;
  max_tool_rounds?: number;
  ui?: Record<string, unknown>;
  roles?: Record<string, { provider?: string; model?: string }>;
  workflow_mode?: string;
  allow_export?: boolean;
  yolo_mode?: boolean;
  evaluator_enabled?: boolean;
  memory_enabled?: boolean;
}

/** 设置 → 运行与存储 磁盘用量分类 */
export interface StorageCategory {
  key: string;
  label: string;
  desc: string;
  files: number;
  bytes: number;
  cleanable: boolean;
  retained: boolean;
}

export interface StorageStats {
  categories: StorageCategory[];
  retained: StorageCategory[];
  workspace_dir: string;
  generated_at: number;
}

/** 资料库条目类型：页面 / 文件夹 / 书签（外部或托管） / 二进制文件 */
export type PageKind = "page" | "folder" | "bookmark" | "file";

/** 资料库页面（列表项 content 为预览片段，详情接口返回全文） */
export interface PageMeta {
  id: string;
  title: string;
  kind: PageKind;
  content?: string;
  description?: string;
  /** 书签/托管页面/上传文件的访问地址 */
  url?: string;
  /** true = 同一网络中其他 Agent 托管的页面（实时从源站加载） */
  hosted?: boolean;
  /** 所在文件夹 id，空串 = 根目录 */
  parent_id?: string;
  file_name?: string;
  file_size?: number;
  size: number;
  source?: string;
  created_at: string;
  updated_at: string;
}

export interface PlanStep {
  id: string;
  tool?: string;
  params?: Record<string, unknown>;
  success?: string;
}

export interface PlanInfo {
  intent?: string;
  goal?: string;
  steps?: PlanStep[];
  tool_hints?: string[];
  acceptance?: string[];
  /** 非空 = 规划器没产出可用计划，这份是启发式兜底模板，值为原因说明 */
  _fallback?: string;
  /** 评估未通过后由规划器携反馈重生 */
  _revised?: boolean;
  /** 命中技能触发词时被绑定为首步的技能名 */
  _skill_bound?: string;
}

/** 计划步骤执行状态（步骤时间线） */
export interface EvalFailure {
  step?: string;
  type?: string;
  detail?: string;
}

export interface EvalInfo {
  passed: boolean;
  feedback: string;
  attempt: number;
  score?: number;
  failures?: EvalFailure[];
  /**
   * 非空 = 这次「通过」不是真实评估结论，而是 fail-open 放行：
   * disabled（评估器已关闭）/ llm_unavailable / exception / parse_failed。
   * UI 必须据此显示「未实际评估」而不是绿色对勾，否则质量门失效时无人察觉。
   */
  fallback?: string | null;
  /** 评估阶段耗时（毫秒） */
  ms?: number;
}

/** 单个流水线阶段的可观测指标 */
export interface StageMetric {
  stage: "planner" | "executor" | "evaluator";
  /** 执行轮次号（仅 executor） */
  round?: number;
  /** 评估次序（仅 evaluator） */
  attempt?: number;
  /**
   * 模型输出字符数。仅 executor 轮有——规划器与评估器的原始输出留在后端内部，
   * 拿不到就不报，不用序列化长度冒充。
   */
  chars?: number;
  ms?: number;
  tool_calls?: number;
  /** 该轮是否产出了最终答案 */
  final?: boolean;
  /** 规划阶段是否为返工修订 */
  revised?: boolean;
  fallback?: string | null;
}

/** 随 assistant 消息落盘的思考链路快照 */
export interface MessageMeta {
  tier?: string | null;
  plan?: PlanInfo | null;
  evals?: EvalInfo[];
  stages?: StageMetric[];
  /** 步骤 id → pending | running | done | failed */
  step_states?: Record<string, string>;
  /** done | paused_human（评估返工预算耗尽转人工） */
  state?: string;
}

export interface PipelineState {
  tier: string | null;
  role: string | null;
  plan: PlanInfo | null;
  evals: EvalInfo[];
  /** 步骤状态映射：step_id → pending | running | done | failed */
  stepStates: Record<string, string>;
  /** 流式期间累积的阶段指标；回合结束后由 message.meta 接管 */
  stages: StageMetric[];
}

export interface ChatEvent {
  type: string;
  content?: string;
  message?: string;
  id?: string;
  server?: string;
  tool?: string;
  arguments?: Record<string, unknown>;
  is_error?: boolean;
  tier?: string;
  role?: string;
  plan?: PlanInfo;
  passed?: boolean;
  feedback?: string;
  attempt?: number;
  score?: number;
  failures?: EvalFailure[];
  step_id?: string;
  state?: string;
  fallback?: string | null;
  ms?: number;
  chars?: number;
  round?: number;
  tool_calls?: number;
  final?: boolean;
  revised?: boolean;
  meta?: MessageMeta;
}

/** danger 高危工具确认请求（前端弹窗人工放行） */
export interface ConfirmRequest {
  callId: string;
  server: string;
  tool: string;
  arguments?: Record<string, unknown>;
}

/** 流式进行中的工具调用（右栏时间线 + 中栏卡片共用） */
export interface InFlightTool {
  id: string;
  server: string;
  tool: string;
  arguments?: Record<string, unknown>;
  content?: string;
  is_error?: boolean;
  startedAt: number;
  endedAt?: number;
}

/** 已注册的本地工作区（AI 代理的本地目录） */
export interface WorkspaceMeta {
  id: string;
  name: string;
  path: string;
  description: string;
  created_at: string;
  updated_at: string;
}

/** 工作区搜索索引统计快照 */
export interface WorkspaceStats {
  workspace_count: number;
  documents: number;
  paragraphs: number;
  pending_sync: number;
  retryable: number;
  failed: number;
  monitor: string;
  last_file_event: string | null;
  last_sync: string | null;
  schema: string;
  daily: {
    enabled: boolean;
    hour: number;
    minute: number;
    last_run: string | null;
  };
  search: {
    ready: boolean;
    p50: number | null;
    p95: number | null;
    samples: number;
    last_search: string | null;
  };
  semantic_cache: {
    enabled: boolean;
    model: string | null;
    latest: number;
    total: number;
    hit_rate: string;
  };
  reranker: {
    enabled: boolean;
    mode: string;
    recent_ms: number;
    p95_ms: number | null;
  };
}

/** 目录浏览结果（添加工作区的文件夹选择器） */
export interface DirBrowse {
  current: string;
  parent: string | null;
  dirs: { name: string; path: string }[];
}

/** 自动化任务调度：单次（run_at）/ 每天（time）/ 每周（weekday+time，0=周一） */
export interface AutomationSchedule {
  type: "once" | "daily" | "weekly";
  run_at?: string | null;
  time?: string | null;
  weekday?: number | null;
}

/** 自动化任务有效期：长期有效 / 截止到某日 */
export interface AutomationValidity {
  type: "permanent" | "until";
  end?: string | null;
}

/** 自动化任务（定时任务） */
export interface AutomationMeta {
  id: string;
  name: string;
  prompt: string;
  /** 模型档位：balanced 均衡 / fast 快速 / precision 精准 */
  model_tier: "balanced" | "fast" | "precision";
  workspace_id: string;
  workspace_name: string;
  /** 访问权限：full 允许完全访问 / restricted 仅工作区内 */
  access: "full" | "restricted";
  schedule: AutomationSchedule;
  validity: AutomationValidity;
  push_wechat: boolean;
  push_wecom: boolean;
  /** active 运行中 / paused 已暂停 / done 已完成（单次任务触发后） */
  status: "active" | "paused" | "done";
  run_count: number;
  last_run_at: string | null;
  created_at: string;
  updated_at: string;
}

/** 自动化运行记录 */
export interface AutomationRun {
  id: string;
  automation_id: string;
  name: string;
  /** manual 手动触发 / schedule 计划触发 */
  trigger: "manual" | "schedule";
  /** success 成功 / error 失败 / running 执行中 */
  status: "success" | "error" | "running";
  started_at: string;
  finished_at: string | null;
  detail: string;
  /** 真实执行的会话 id（可跳转查看完整过程） */
  session_id?: string;
}

/** 访问认证状态（设置 → 访问安全） */
export interface AuthStatus {
  enabled: boolean;
  token_configured: boolean;
}

/** RAG 知识库索引状态 */
export interface RagStatus {
  chunks: number;
  signature: string;
  built_at: string;
  embed_model: string;
  enabled: boolean;
}
