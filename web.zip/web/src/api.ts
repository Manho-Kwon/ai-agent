import type {
  Attachment,
  AutomationMeta,
  AutomationRun,
  AuthStatus,
  ChatEvent,
  ConnectionsState,
  DirBrowse,
  McpServer,
  PageMeta,
  RagStatus,
  RetrievalStatus,
  SessionMeta,
  Settings,
  SettingsPut,
  SkillInfo,
  StorageStats,
  WorkspaceMeta,
  WorkspaceStats,
} from "./types";

/** 访问认证 token（开启认证后由设置页保存到本地） */
export function getAuthToken(): string {
  return localStorage.getItem("auth-token") || "";
}

function authHeaders(): Record<string, string> {
  const token = getAuthToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
}

export async function jsonFetch<T>(url: string, opts?: RequestInit): Promise<T> {
  const resp = await fetch(url, {
    headers: { "Content-Type": "application/json", ...authHeaders() },
    ...opts,
  });
  if (resp.status === 401) {
    throw new Error("需要访问认证：请到 设置 → 访问安全 填入访问令牌");
  }
  if (!resp.ok) {
    let detail = `HTTP ${resp.status}`;
    try {
      const body = await resp.json();
      detail = body.detail || detail;
    } catch {
      /* keep default */
    }
    throw new Error(detail);
  }
  return resp.json() as Promise<T>;
}

/** File → base64（分块转换，避免大文件一次性展开栈溢出） */
async function fileToB64(file: File): Promise<string> {
  const buf = await file.arrayBuffer();
  const bytes = new Uint8Array(buf);
  let binary = "";
  const chunk = 0x2000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode(...bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

export const api = {
  listSessions: () => jsonFetch<SessionMeta[]>("/api/sessions"),
  createSession: (title = "") =>
    jsonFetch<SessionMeta>("/api/sessions", {
      method: "POST",
      body: JSON.stringify({ title }),
    }),
  getSession: (id: string) =>
    jsonFetch<SessionMeta & { messages: unknown[] }>(`/api/sessions/${id}`),
  renameSession: (id: string, title: string) =>
    jsonFetch<SessionMeta>(`/api/sessions/${id}`, {
      method: "PATCH",
      body: JSON.stringify({ title }),
    }),
  deleteSession: (id: string) =>
    jsonFetch<{ ok: boolean }>(`/api/sessions/${id}`, { method: "DELETE" }),
  mcpServers: () =>
    jsonFetch<{
      servers: McpServer[];
      config_error: string | null;
      config_path?: string;
    }>("/api/mcp/servers"),
  mcpReload: () =>
    jsonFetch<Record<string, unknown>>("/api/mcp/reload", { method: "POST" }),
  setMcpEnabled: (name: string, enabled: boolean) =>
    jsonFetch<Record<string, unknown>>(
      `/api/mcp/servers/${encodeURIComponent(name)}/enabled`,
      { method: "POST", body: JSON.stringify({ enabled }) }
    ),
  /** 注册新 MCP 服务器（写入 mcp.json 后热重载） */
  mcpAddServer: (req: {
    name: string;
    transport: string;
    command?: string;
    args?: string[];
    env?: Record<string, string>;
    url?: string;
  }) =>
    jsonFetch<Record<string, unknown>>("/api/mcp/servers", {
      method: "POST",
      body: JSON.stringify(req),
    }),
  /** 在系统文件管理器中打开 mcp.json 所在文件夹 */
  mcpOpenConfigFolder: () =>
    jsonFetch<{ ok: boolean }>("/api/mcp/open-config-folder", {
      method: "POST",
    }),
  getSettings: () => jsonFetch<Settings>("/api/settings"),
  saveSettings: (patch: SettingsPut) =>
    jsonFetch<{ ok: boolean }>("/api/settings", {
      method: "PUT",
      body: JSON.stringify(patch),
    }),
  probeGateway: () =>
    jsonFetch<{
      ok: boolean;
      models?: string[];
      error?: string;
      latency_ms?: number;
      model?: string;
    }>("/api/settings/probe", { method: "POST" }),

  // ── 模型连接（设置 → LLM 配置 → 管理模型连接） ──
  connections: () => jsonFetch<ConnectionsState>("/api/connections"),
  connectionsRefresh: () =>
    jsonFetch<ConnectionsState>("/api/connections/refresh", { method: "POST" }),
  /** 录入内置提供商密钥（内部提供商可顺带更新网关地址），保存后立即验证 */
  connectionSaveKey: (key: string, apiKey: string, baseUrl?: string) =>
    jsonFetch<ConnectionsState>(`/api/connections/${encodeURIComponent(key)}/key`, {
      method: "POST",
      body: JSON.stringify({ api_key: apiKey, base_url: baseUrl ?? null }),
    }),
  customModelAdd: (req: {
    label: string;
    model: string;
    base_url: string;
    api_key: string;
  }) =>
    jsonFetch<ConnectionsState>("/api/connections/custom/models", {
      method: "POST",
      body: JSON.stringify(req),
    }),
  customModelDelete: (id: string) =>
    jsonFetch<{ ok: boolean }>(
      `/api/connections/custom/models/${encodeURIComponent(id)}`,
      { method: "DELETE" }
    ),
  storageStats: () => jsonFetch<StorageStats>("/api/storage"),
  storageClean: (keys: string[]) =>
    jsonFetch<{ ok: boolean; removed: number } & StorageStats>("/api/storage/clean", {
      method: "POST",
      body: JSON.stringify({ keys }),
    }),
  cancelChat: (sessionId: string) =>
    jsonFetch<{ ok: boolean }>("/api/chat/cancel", {
      method: "POST",
      body: JSON.stringify({ session_id: sessionId }),
    }),
  /** danger 高危工具确认门：弹窗结果回传（approved=false / 超时 = 拒绝） */
  confirmTool: (sessionId: string, callId: string, approved: boolean) =>
    jsonFetch<{ ok: boolean }>("/api/chat/confirm", {
      method: "POST",
      body: JSON.stringify({ session_id: sessionId, call_id: callId, approved }),
    }),

  // ── 访问安全（设置 → 访问安全；enable/disable 仅限本机回环调用） ──
  authStatus: () => jsonFetch<AuthStatus>("/api/auth/status"),
  authEnable: (token?: string) =>
    jsonFetch<{ enabled: boolean; token: string }>("/api/auth/enable", {
      method: "POST",
      body: JSON.stringify({ token: token || "" }),
    }),
  authDisable: () =>
    jsonFetch<{ enabled: boolean }>("/api/auth/disable", { method: "POST" }),
  listPages: () => jsonFetch<{ pages: PageMeta[] }>("/api/pages"),
  /** 新建文件夹 / URL 书签 / 手动文本页面（kind 区分） */
  addPageEntry: (req: {
    kind: "page" | "folder" | "bookmark";
    title?: string;
    description?: string;
    url?: string;
    content?: string;
    parent_id?: string;
  }) =>
    jsonFetch<PageMeta>("/api/pages", {
      method: "POST",
      body: JSON.stringify({
        kind: req.kind,
        title: req.title || "",
        description: req.description || "",
        url: req.url || "",
        content: req.content || "",
        parent_id: req.parent_id || "",
      }),
    }),
  /** 上传文件：文本类传 textContent，二进制传 contentB64（base64） */
  uploadPage: (req: {
    title?: string;
    description?: string;
    parent_id?: string;
    file_name: string;
    textContent?: string;
    contentB64?: string;
  }) =>
    jsonFetch<PageMeta>("/api/pages/upload", {
      method: "POST",
      body: JSON.stringify({
        title: req.title || "",
        description: req.description || "",
        parent_id: req.parent_id || "",
        file_name: req.file_name,
        text_content: req.textContent ?? null,
        content_b64: req.contentB64 ?? null,
      }),
    }),
  /** 上传聊天附件（base64，会话级一次性上下文）；返回后端解析后的元数据 */
  uploadChatAttachment: async (
    sessionId: string,
    file: File
  ): Promise<Attachment> =>
    jsonFetch<Attachment>("/api/chat/upload", {
      method: "POST",
      body: JSON.stringify({
        session_id: sessionId,
        file_name: file.name,
        content_b64: await fileToB64(file),
      }),
    }),
  /** 从服务器本机绝对路径导入 */
  importPagePath: (req: {
    path: string;
    title?: string;
    description?: string;
    parent_id?: string;
  }) =>
    jsonFetch<PageMeta>("/api/pages/import-path", {
      method: "POST",
      body: JSON.stringify({
        path: req.path,
        title: req.title || "",
        description: req.description || "",
        parent_id: req.parent_id || "",
      }),
    }),
  /** 导入其他 Agent 托管页面（服务端会先验证连通性） */
  importPageHosted: (req: {
    url: string;
    title?: string;
    description?: string;
    parent_id?: string;
  }) =>
    jsonFetch<PageMeta>("/api/pages/import-hosted", {
      method: "POST",
      body: JSON.stringify({
        url: req.url,
        title: req.title || "",
        description: req.description || "",
        parent_id: req.parent_id || "",
      }),
    }),
  getPage: (id: string) => jsonFetch<PageMeta>(`/api/pages/${id}`),
  deletePage: (id: string) =>
    jsonFetch<{ ok: boolean }>(`/api/pages/${id}`, { method: "DELETE" }),

  // ── 工作区 ──
  listWorkspaces: () =>
    jsonFetch<{ workspaces: WorkspaceMeta[] }>("/api/workspaces"),
  createWorkspace: (req: { name: string; path: string; description?: string }) =>
    jsonFetch<WorkspaceMeta>("/api/workspaces", {
      method: "POST",
      body: JSON.stringify({
        name: req.name,
        path: req.path,
        description: req.description || "",
      }),
    }),
  deleteWorkspace: (id: string) =>
    jsonFetch<{ ok: boolean }>(`/api/workspaces/${id}`, { method: "DELETE" }),
  workspaceStats: () => jsonFetch<WorkspaceStats>("/api/workspaces/stats"),
  syncWorkspaces: () => jsonFetch<WorkspaceStats>("/api/workspaces/sync"),
  retryFailedTasks: () =>
    jsonFetch<{ ok: boolean; retried: number; message: string }>(
      "/api/workspaces/retry-failed",
      { method: "POST" }
    ),
  setDailyConfig: (req: { enabled: boolean; hour: number; minute: number }) =>
    jsonFetch<WorkspaceStats>("/api/workspaces/daily-config", {
      method: "POST",
      body: JSON.stringify(req),
    }),
  browseDirs: (path: string) => {
    const q = path ? `?path=${encodeURIComponent(path)}` : "";
    return jsonFetch<DirBrowse>(`/api/workspaces/browse${q}`);
  },

  // ── 自动化 ──
  listAutomations: () =>
    jsonFetch<{ automations: AutomationMeta[]; runs: AutomationRun[] }>(
      "/api/automations"
    ),
  createAutomation: (req: AutomationPayload) =>
    jsonFetch<AutomationMeta>("/api/automations", {
      method: "POST",
      body: JSON.stringify(req),
    }),
  updateAutomation: (id: string, req: AutomationPayload) =>
    jsonFetch<AutomationMeta>(`/api/automations/${id}`, {
      method: "PATCH",
      body: JSON.stringify(req),
    }),
  toggleAutomation: (id: string, active: boolean) =>
    jsonFetch<AutomationMeta>(`/api/automations/${id}/toggle`, {
      method: "POST",
      body: JSON.stringify({ active }),
    }),
  runAutomation: (id: string) =>
    jsonFetch<AutomationRun>(`/api/automations/${id}/run`, { method: "POST" }),
  deleteAutomation: (id: string) =>
    jsonFetch<{ ok: boolean }>(`/api/automations/${id}`, { method: "DELETE" }),
  batchAutomations: (action: "pause" | "resume" | "delete", ids: string[]) =>
    jsonFetch<{ affected: number }>("/api/automations/batch", {
      method: "POST",
      body: JSON.stringify({ action, ids }),
    }),
  clearAutomationRuns: () =>
    jsonFetch<{ cleared: number }>("/api/automations/runs/clear", {
      method: "POST",
    }),

  // ── 代理技能（设置 → 智能体技能） ──
  listSkills: () => jsonFetch<{ skills: SkillInfo[] }>("/api/skills"),
  createSkill: (req: { name: string; description: string; body?: string }) =>
    jsonFetch<SkillInfo>("/api/skills", {
      method: "POST",
      body: JSON.stringify(req),
    }),
  reloadSkills: () =>
    jsonFetch<{ ok: boolean; count: number }>("/api/skills/reload", {
      method: "POST",
    }),
  setSkillEnabled: (name: string, enabled: boolean) =>
    jsonFetch<SkillInfo>(`/api/skills/${encodeURIComponent(name)}/enabled`, {
      method: "POST",
      body: JSON.stringify({ enabled }),
    }),

  // ── 工作区检索（设置 → 工作区检索） ──
  retrievalStatus: () => jsonFetch<RetrievalStatus>("/api/retrieval/status"),
  setRetrievalMode: (mode: string) =>
    jsonFetch<{ ok: boolean; mode: string }>("/api/retrieval/mode", {
      method: "PUT",
      body: JSON.stringify({ mode }),
    }),
};

/** 自动化任务创建/编辑请求体 */
export interface AutomationPayload {
  name: string;
  prompt: string;
  model_tier: string;
  workspace_id?: string;
  workspace_name?: string;
  access: string;
  schedule: {
    type: string;
    run_at?: string | null;
    time?: string | null;
    weekday?: number | null;
  };
  validity: { type: string; end?: string | null };
  push_wechat: boolean;
  push_wecom: boolean;
  status?: string;
}

/**
 * POST SSE 流式对话（POST 不能用 EventSource，fetch + ReadableStream 手工解析，
 * 原版同款做法）。`: heartbeat` 注释行自动跳过。
 */
export async function* streamChat(
  sessionId: string,
  content: string,
  signal: AbortSignal,
  attachmentIds?: string[]
): AsyncGenerator<ChatEvent> {
  const resp = await fetch("/api/chat/stream", {
    method: "POST",
    headers: { "Content-Type": "application/json", ...authHeaders() },
    body: JSON.stringify({
      session_id: sessionId,
      content,
      attachment_ids: attachmentIds ?? [],
    }),
    signal,
  });
  if (resp.status === 401) {
    throw new Error("需要访问认证：请到 设置 → 访问安全 填入访问令牌");
  }
  if (!resp.ok || !resp.body) {
    let detail = `HTTP ${resp.status}`;
    try {
      const body = await resp.json();
      detail = body.detail || detail;
    } catch {
      /* keep default */
    }
    throw new Error(detail);
  }
  const reader = resp.body.getReader();
  const decoder = new TextDecoder();
  let buf = "";
  while (true) {
    const { done, value } = await reader.read();
    if (done) break;
    buf += decoder.decode(value, { stream: true });
    let idx: number;
    while ((idx = buf.indexOf("\n\n")) >= 0) {
      const raw = buf.slice(0, idx);
      buf = buf.slice(idx + 2);
      for (const line of raw.split("\n")) {
        if (line.startsWith("data: ")) {
          try {
            yield JSON.parse(line.slice(6)) as ChatEvent;
          } catch {
            /* 忽略坏帧 */
          }
        }
      }
    }
  }
}
