import { useCallback, useEffect, useRef, useState } from "react";
import { api, streamChat } from "./api";
import {
  applyAppearance,
  cacheAppearance,
  loadCachedAppearance,
  normalizeAppearance,
} from "./appearance";
import type {
  Appearance,
  Attachment,
  ChatEvent,
  ConfirmRequest,
  EvalInfo,
  InFlightTool,
  McpServer,
  Message,
  PipelineState,
  PlanInfo,
  SessionMeta,
  Settings,
  StageMetric,
} from "./types";
import SessionList from "./components/SessionList";
import ChatArea from "./components/ChatArea";
import LibraryPanel from "./components/LibraryPanel";
import WorkspacePanel from "./components/WorkspacePanel";
import AutomationPanel from "./components/AutomationPanel";
import ToolPanel from "./components/ToolPanel";
import ThemeAppearancePage from "./components/settings/ThemeAppearancePage";
import ProfileBrandPage from "./components/settings/ProfileBrandPage";
import LlmSettingsPage from "./components/settings/LlmSettingsPage";
import RuntimeStoragePage from "./components/settings/RuntimeStoragePage";
import ConnectionStatusPage from "./components/settings/ConnectionStatusPage";
import McpServersPage from "./components/settings/McpServersPage";
import SkillsPage from "./components/settings/SkillsPage";
import ScheduledTasksPage from "./components/settings/ScheduledTasksPage";
import WorkspaceRetrievalPage from "./components/settings/WorkspaceRetrievalPage";
import MemoryPage from "./components/settings/MemoryPage";
import AccessSecurityPage from "./components/settings/AccessSecurityPage";

/** 设置子页面 key（左侧设置菜单 → 主区页面） */
export type SettingsPageKey =
  | "theme"
  | "profile"
  | "llm"
  | "storage"
  | "connection"
  | "mcp"
  | "skills"
  | "tasks"
  | "retrieval"
  | "memory"
  | "security"
  | null;

export default function App() {
  const [sessions, setSessions] = useState<SessionMeta[]>([]);
  const [currentId, setCurrentId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [streaming, setStreaming] = useState<({
    text: string;
    tools: InFlightTool[];
  } & PipelineState) | null>(null);
  const [mcpServers, setMcpServers] = useState<McpServer[]>([]);
  const [settings, setSettings] = useState<Settings | null>(null);
  const [settingsPage, setSettingsPage] = useState<SettingsPageKey>(null);
  const [toolsOpen, setToolsOpen] = useState(false);
  const [leftSettingsOpen, setLeftSettingsOpen] = useState(false);
  const [navOpen, setNavOpen] = useState(false);
  const [libraryOpen, setLibraryOpen] = useState(false);
  const [workspaceOpen, setWorkspaceOpen] = useState(false);
  const [automationOpen, setAutomationOpen] = useState(false);
  const [collapsed, setCollapsed] = useState(
    () => localStorage.getItem("sb-collapsed") === "1"
  );
  // 外观（模式/色调/强调色/字号/光晕/聊天背景）：先取本地缓存保证首屏，再以服务端为准
  const [appearance, setAppearance] = useState<Appearance>(() =>
    loadCachedAppearance()
  );
  const [isMobile, setIsMobile] = useState(
    () => window.matchMedia("(max-width: 720px)").matches
  );
  const [chatError, setChatError] = useState<string | null>(null);
  const [confirmReq, setConfirmReq] = useState<ConfirmRequest | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const streamingRef = useRef(false);
  streamingRef.current = streaming !== null;

  // 外观：落到 <html> 上并写本地缓存
  useEffect(() => {
    applyAppearance(appearance);
    cacheAppearance(appearance);
  }, [appearance]);

  // 侧边栏收起状态持久化（仅桌面端）
  useEffect(() => {
    localStorage.setItem("sb-collapsed", collapsed ? "1" : "0");
  }, [collapsed]);

  // 跟踪移动端断点
  useEffect(() => {
    const mq = window.matchMedia("(max-width: 720px)");
    const fn = (e: MediaQueryListEvent) => setIsMobile(e.matches);
    mq.addEventListener("change", fn);
    return () => mq.removeEventListener("change", fn);
  }, []);

  const theme = appearance.mode;

  /** 更新外观：立即生效并异步持久化到 config.json（ui.appearance） */
  const updateAppearance = useCallback((patch: Partial<Appearance>) => {
    setAppearance((prev) => {
      const next = { ...prev, ...patch };
      api.saveSettings({ ui: { appearance: next } }).catch(() => undefined);
      return next;
    });
  }, []);

  const handleToggleCollapse = () => {
    // 移动端抽屉与桌面端收起共用一个入口按钮
    if (window.matchMedia("(max-width: 720px)").matches) setNavOpen((v) => !v);
    else {
      const next = !collapsed;
      setCollapsed(next);
      // 收起为图标栏时关闭设置面板（设置面板需要完整宽度）
      if (next) setLeftSettingsOpen(false);
    }
  };

  // 桌面端收起后为图标栏（侧边栏仍可见），无需浮动展开按钮
  const showFab = isMobile ? !navOpen : false;

  const refreshSessions = useCallback(async (): Promise<SessionMeta[]> => {
    try {
      const list = await api.listSessions();
      setSessions(list);
      return list;
    } catch {
      return []; /* 服务未就绪时静默 */
    }
  }, []);

  const refreshMcp = useCallback(async () => {
    try {
      const data = await api.mcpServers();
      setMcpServers(data.servers);
    } catch {
      /* ignore */
    }
  }, []);

  /** 离开当前视图：关掉各浮层面板并清除上一轮错误提示 */
  const leaveView = useCallback(() => {
    setChatError(null);
    setLibraryOpen(false);
    setWorkspaceOpen(false);
    setAutomationOpen(false);
    setSettingsPage(null);
  }, []);

  /** 关闭设置弹窗并同步收起侧边栏设置菜单 */
  const closeSettings = useCallback(() => {
    setSettingsPage(null);
    setLeftSettingsOpen(false);
  }, []);

  const openSession = useCallback(
    async (id: string) => {
      setCurrentId(id);
      leaveView();
      try {
        const detail = await api.getSession(id);
        setMessages(detail.messages as Message[]);
      } catch {
        setMessages([]);
      }
    },
    [leaveView]
  );

  /** 草稿态：不建会话，只把界面清成「待发起」状态 */
  const enterDraft = useCallback(() => {
    setCurrentId(null);
    setMessages([]);
    leaveView();
  }, [leaveView]);

  /**
   * 草稿态首次真正发起任务/上传附件时才落地会话。
   * 刻意不刷新侧边栏：条目等 SSE start（后端已接手）再出现，避免空壳记录。
   */
  const ensureSession = useCallback(async (): Promise<string | null> => {
    if (currentId) return currentId;
    try {
      const s = await api.createSession();
      setCurrentId(s.id);
      return s.id;
    } catch {
      setChatError("会话创建失败，请确认服务已启动");
      return null;
    }
  }, [currentId]);

  // 初始化：设置 + 会话 + MCP
  useEffect(() => {
    api
      .getSettings()
      .then((s) => {
        setSettings(s);
        // 服务端外观设置覆盖本地缓存（mode 与本地即时状态一致优先）
        const remote = normalizeAppearance({
          ...s.ui.appearance,
          mode:
            (localStorage.getItem("theme") as "light" | "dark") ||
            s.ui.appearance?.mode ||
            "light",
        });
        setAppearance(remote);
      })
      .catch(() => undefined);
    refreshSessions().then(async (list) => {
      // 无会话时首屏本就是草稿态（currentId=null），不再预建空壳记录
      if (list.length > 0) await openSession(list[0].id);
    });
    refreshMcp();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleNewSession = () => {
    if (streamingRef.current) return;
    setNavOpen(false);
    enterDraft();
  };

  const handleDeleteSession = async (id: string) => {
    if (streamingRef.current && id === currentId) return;
    await api.deleteSession(id);
    const rest = await refreshSessions();
    if (id === currentId) {
      if (rest.length > 0) await openSession(rest[0].id);
      else enterDraft();
    }
  };

  const handleRenameSession = async (id: string, title: string) => {
    await api.renameSession(id, title);
    await refreshSessions();
  };

  const handleSend = async (content: string, attachments?: Attachment[]) => {
    if (streamingRef.current) return;
    // 草稿态在此刻才落地会话；sid 走局部变量贯穿整条流，不依赖 setState 的异步刷新
    const sid = await ensureSession();
    if (!sid) return;
    setChatError(null);
    // 乐观插入用户消息（含附件元数据，chips 立即显示）
    setMessages((prev) => [
      ...prev,
      {
        role: "user",
        content,
        attachments,
        timestamp: new Date().toISOString(),
      },
    ]);
    setStreaming({
      text: "",
      tools: [],
      tier: null,
      role: null,
      plan: null,
      evals: [],
      stepStates: {},
      stages: [],
    });
    const ac = new AbortController();
    abortRef.current = ac;

    const tools: InFlightTool[] = [];
    let text = "";
    let tier: string | null = null;
    let role: string | null = null;
    let plan: PlanInfo | null = null;
    const evals: EvalInfo[] = [];
    const stepStates: Record<string, string> = {};
    const stages: StageMetric[] = [];
    const push = () =>
      setStreaming({
        text,
        tools: [...tools],
        tier,
        role,
        plan,
        evals: [...evals],
        stepStates: { ...stepStates },
        stages: [...stages],
      });
    try {
      for await (const ev of streamChat(
        sid,
        content,
        ac.signal,
        attachments?.map((a) => a.id)
      )) {
        const e = ev as ChatEvent;
        if (e.type === "start") {
          // 后端已接手本回合 → 任务履历此刻才出现条目（草稿态不预建空壳记录）
          refreshSessions();
        } else if (e.type === "delta") {
          text += e.content || "";
          push();
        } else if (e.type === "tool_call") {
          tools.push({
            id: e.id || "",
            server: e.server || "",
            tool: e.tool || "",
            arguments: e.arguments,
            startedAt: Date.now(),
          });
          push();
        } else if (e.type === "tool_result") {
          const t = tools.find((x) => x.id === e.id);
          if (t) {
            t.content = e.content || "";
            t.is_error = e.is_error;
            t.endedAt = Date.now();
          }
          push();
        } else if (e.type === "workflow") {
          tier = e.tier || null;
          push();
        } else if (e.type === "role_active") {
          role = e.role || null;
          push();
        } else if (e.type === "plan") {
          plan = e.plan || null;
          stages.push({
            stage: "planner",
            ms: e.ms,
            revised: e.revised,
            fallback: e.fallback,
          });
          push();
        } else if (e.type === "round") {
          stages.push({
            stage: "executor",
            round: e.round,
            chars: e.chars,
            ms: e.ms,
            tool_calls: e.tool_calls,
            final: e.final,
          });
          push();
        } else if (e.type === "step_update") {
          if (e.step_id) {
            stepStates[e.step_id] = e.state || "pending";
            push();
          }
        } else if (e.type === "confirm_request") {
          setConfirmReq({
            callId: e.id || "",
            server: e.server || "",
            tool: e.tool || "",
            arguments: e.arguments,
          });
        } else if (e.type === "eval") {
          const attempt = e.attempt || evals.length + 1;
          evals.push({
            passed: !!e.passed,
            feedback: e.feedback || "",
            attempt,
            score: e.score,
            failures: e.failures,
            fallback: e.fallback,
            ms: e.ms,
          });
          stages.push({ stage: "evaluator", attempt, ms: e.ms, fallback: e.fallback });
          push();
        } else if (e.type === "error") {
          setChatError(e.message || "未知错误");
        } else if (e.type === "cancelled") {
          break;
        }
        // done 无需在此处理：其 state 与整条链路已由后端写进 message.meta 落盘，
        // 回合结束重载会话后由历史渲染分支接管，比临时 state 更持久
      }
    } catch (err) {
      if ((err as Error).name !== "AbortError") {
        setChatError((err as Error).message);
      }
    } finally {
      abortRef.current = null;
      setStreaming(null);
      setConfirmReq(null);
      // 服务端是消息唯一事实源：完成后回读，顺带取出后端自动概括的会话标题
      await openSession(sid);
      await refreshSessions();
    }
  };

  /** danger 高危工具确认门：弹窗结果回传后端（拒绝 = 不执行） */
  const handleConfirm = useCallback(
    async (callId: string, approved: boolean) => {
      setConfirmReq(null);
      if (!currentId) return;
      await api.confirmTool(currentId, callId, approved).catch(() => undefined);
    },
    [currentId]
  );

  /** YOLO 模式切换：开启后跳过 danger 高危工具确认门 */
  const handleToggleYolo = useCallback(async () => {
    const next = !settings?.yolo_mode;
    try {
      await api.saveSettings({ yolo_mode: next });
      setSettings((prev) => (prev ? { ...prev, yolo_mode: next } : prev));
    } catch {
      /* 忽略瞬时失败 */
    }
  }, [settings?.yolo_mode]);

  const handleStop = () => {
    if (currentId) api.cancelChat(currentId).catch(() => undefined);
  };

  /** 设置子页面保存/变更后刷新全局设置（侧边栏标题、聊天名称即时生效） */
  const refreshSettings = useCallback(async () => {
    try {
      setSettings(await api.getSettings());
    } catch {
      /* 忽略瞬时失败 */
    }
  }, []);

  return (
    <div className="app">
      <div className="app-body">
        <SessionList
          title={settings?.ui.title || "A R C H E"}
          subtitle={settings?.ui.subtitle || "Arche Agent"}
          theme={theme}
          collapsed={collapsed}
          sessions={sessions}
          currentId={currentId}
          disabled={streaming !== null}
          settingsActive={leftSettingsOpen}
          settingsPage={settingsPage}
          onToggleSettings={() => {
            const next = !leftSettingsOpen;
            setLeftSettingsOpen(next);
            // 从收起状态打开设置时自动展开侧边栏
            if (next && collapsed) setCollapsed(false);
          }}
          onOpenSettingsPage={(page) => setSettingsPage(page)}
          navOpen={navOpen}
          onCloseNav={() => setNavOpen(false)}
          onOpenLibrary={() => {
            setLibraryOpen(true);
            setWorkspaceOpen(false);
            setAutomationOpen(false);
            setSettingsPage(null);
            setNavOpen(false);
          }}
          onOpenWorkspace={() => {
            setWorkspaceOpen(true);
            setLibraryOpen(false);
            setAutomationOpen(false);
            setSettingsPage(null);
            setNavOpen(false);
          }}
          onOpenAutomation={() => {
            setAutomationOpen(true);
            setLibraryOpen(false);
            setWorkspaceOpen(false);
            setSettingsPage(null);
            setNavOpen(false);
          }}
          onToggleTheme={() =>
            updateAppearance({ mode: theme === "light" ? "dark" : "light" })
          }
          onToggleCollapse={handleToggleCollapse}
          onSelect={openSession}
          onNew={handleNewSession}
          onDelete={handleDeleteSession}
          onRename={handleRenameSession}
        />
        {libraryOpen ? (
          <LibraryPanel onClose={() => setLibraryOpen(false)} />
        ) : workspaceOpen ? (
          <WorkspacePanel onClose={() => setWorkspaceOpen(false)} />
        ) : automationOpen ? (
          <AutomationPanel onClose={() => setAutomationOpen(false)} />
        ) : settingsPage ? (
          <div className="settings-page-container">
            {settingsPage === "theme" ? (
              <ThemeAppearancePage
                appearance={appearance}
                onChange={updateAppearance}
                onClose={() => setSettingsPage(null)}
              />
            ) : settingsPage === "profile" ? (
              <ProfileBrandPage
                ui={settings?.ui || { title: "" }}
                onClose={() => setSettingsPage(null)}
                onSaved={refreshSettings}
              />
            ) : settingsPage === "llm" ? (
              settings && (
                <LlmSettingsPage
                  settings={settings}
                  onClose={() => setSettingsPage(null)}
                  onSaved={refreshSettings}
                />
              )
            ) : settingsPage === "storage" ? (
              <RuntimeStoragePage
                workflowMode={settings?.workflow?.mode || "auto"}
                allowExport={settings?.runtime?.allow_export || false}
                onClose={() => setSettingsPage(null)}
                onConfigChange={refreshSettings}
              />
            ) : settingsPage === "connection" ? (
              settings && (
                <ConnectionStatusPage
                  settings={settings}
                  onClose={() => setSettingsPage(null)}
                />
              )
            ) : settingsPage === "mcp" ? (
              <McpServersPage
                onClose={() => setSettingsPage(null)}
                onChanged={refreshMcp}
              />
            ) : settingsPage === "skills" ? (
              <SkillsPage onClose={() => setSettingsPage(null)} />
            ) : settingsPage === "tasks" ? (
              <ScheduledTasksPage onClose={() => setSettingsPage(null)} />
            ) : settingsPage === "retrieval" ? (
              <WorkspaceRetrievalPage onClose={() => setSettingsPage(null)} />
            ) : settingsPage === "memory" ? (
              settings && (
                <MemoryPage
                  enabled={settings.memory?.enabled ?? true}
                  onClose={() => setSettingsPage(null)}
                  onSaved={refreshSettings}
                />
              )
            ) : settingsPage === "security" ? (
              <AccessSecurityPage onClose={() => setSettingsPage(null)} />
            ) : null}
          </div>
        ) : (
          <ChatArea
            messages={messages}
            streaming={streaming}
            error={chatError}
            sessions={sessions}
            currentId={currentId}
            ensureSession={ensureSession}
            userName={settings?.ui.user_name || "K哥"}
            botName={settings?.ui.bot_name || "Agent"}
            userAvatar={settings?.ui.user_avatar || ""}
            botAvatar={settings?.ui.bot_avatar || ""}
            confirmReq={confirmReq}
            onConfirm={handleConfirm}
            onSelectSession={openSession}
            onSend={handleSend}
            onStop={handleStop}
            onOpenTools={() => setToolsOpen(true)}
            yoloMode={settings?.yolo_mode ?? false}
            onToggleYolo={handleToggleYolo}
          />
        )}
        {toolsOpen && (
          <>
            <div
              className={`nav-backdrop rs show`}
              onClick={() => setToolsOpen(false)}
            />
            <div className="right-sidebar">
              <ToolPanel
                servers={mcpServers}
                onReload={refreshMcp}
                onClose={() => setToolsOpen(false)}
              />
            </div>
          </>
        )}
      </div>
      <button
        className={`sb-expand-fab${showFab ? " show" : ""}`}
        onClick={handleToggleCollapse}
        title="展开侧边栏"
        type="button"
        aria-label="展开侧边栏"
      >
        <svg
          viewBox="0 0 24 24"
          width="16"
          height="16"
          fill="none"
          stroke="currentColor"
          strokeWidth={1.7}
          strokeLinecap="round"
          strokeLinejoin="round"
          aria-hidden
        >
          <rect x="3" y="4" width="18" height="16" rx="2.5" />
          <line x1="9.5" y1="4" x2="9.5" y2="20" />
          <rect
            x="4.8"
            y="6"
            width="3.2"
            height="12"
            rx="1.2"
            fill="currentColor"
            stroke="none"
          />
        </svg>
      </button>
    </div>
  );
}
